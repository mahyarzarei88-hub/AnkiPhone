// Shared helpers: days, ids, escaping.

export const ROLLOVER_HOURS = 4; // new study day starts at 4am, like Anki

// Absolute local day number (days since 1970-01-01 local, shifted by rollover).
export function dayIndex(ms = Date.now()) {
  const off = new Date(ms).getTimezoneOffset() * 60000;
  return Math.floor((ms - off - ROLLOVER_HOURS * 3600000) / 86400000);
}
export function today() { return dayIndex(Date.now()); }

// ms timestamp of the start (rollover) of a given day index, local time
export function dayStartMs(day) {
  // approximate then correct for DST
  let ms = day * 86400000 + ROLLOVER_HOURS * 3600000;
  ms += new Date(ms).getTimezoneOffset() * 60000;
  return ms;
}

export function dayToISO(day) {
  const d = new Date(dayStartMs(day) + 12 * 3600000);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
export function isoToDay(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return dayIndex(new Date(y, m - 1, d, 12).getTime());
}

let lastId = 0;
// Anki-style millisecond ids, unique within this session
export function newId() {
  let id = Date.now();
  if (id <= lastId) id = lastId + 1;
  lastId = id;
  return id;
}

const GUID_CHARS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&()*+,-./:;<=>?@[]^_`{|}~';
export function newGuid() {
  let s = '';
  const a = new Uint8Array(10);
  globalThis.crypto.getRandomValues(a);
  for (const b of a) s += GUID_CHARS[b % GUID_CHARS.length];
  return s;
}

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function stripHtml(html) {
  return String(html ?? '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<br\s*\/?>/gi, ' ')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

export async function sha1Hex(text) {
  const data = new TextEncoder().encode(text);
  const h = await globalThis.crypto.subtle.digest('SHA-1', data);
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function fmtIvl(days) {
  if (days < 1) {
    const mins = Math.max(1, Math.round(days * 1440));
    if (mins < 60) return mins + 'm';
    return Math.round(mins / 60) + 'h';
  }
  if (days < 30) return Math.round(days) + 'd';
  if (days < 365) return (Math.round(days / 3) / 10).toFixed(1).replace(/\.0$/, '') + 'mo';
  return (Math.round(days / 36.5) / 10).toFixed(1).replace(/\.0$/, '') + 'y';
}

export function fmtSecs(s) {
  s = Math.max(0, Math.round(s));
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
}

export function clamp(x, a, b) { return Math.min(b, Math.max(a, x)); }
