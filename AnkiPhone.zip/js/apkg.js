// Reading and writing Anki packages (.apkg / .colpkg).
// Supports legacy (collection.anki2 / collection.anki21, schema 11 with JSON
// config) and current (collection.anki21b, zstd + schema 18 with protobuf blobs).

import * as P from './proto.js';
import { dayIndex, stripHtml, sha1Hex } from './util.js';

export function defaultConf(id = 1, name = 'Default') {
  return {
    id, name,
    learnSteps: [1, 10], relearnSteps: [10],
    newPerDay: 20, revPerDay: 200,
    initialEase: 2.5, easyMult: 1.3, hardMult: 1.2, lapseMult: 0, ivlMult: 1,
    maxIvl: 36500, minLapseIvl: 1, gradGood: 1, gradEasy: 4,
    desiredRetention: 0.9, fsrsParams: [],
  };
}

const td = new TextDecoder();

// ---------- reading ----------

export async function readPackage(buffer, { SQL, JSZip, zstdDecompress }) {
  const zip = await JSZip.loadAsync(buffer);
  let version = 0;
  const metaFile = zip.file('meta');
  if (metaFile) {
    try { version = P.num(P.decode(await metaFile.async('uint8array')), 1); } catch { version = 0; }
  }
  let colName = null;
  for (const n of ['collection.anki21b', 'collection.anki21', 'collection.anki2']) {
    if (zip.file(n)) { colName = n; break; }
  }
  if (!colName) throw new Error('This file does not contain an Anki collection.');
  const compressed = colName === 'collection.anki21b' || version === 3;
  let colBytes = await zip.file(colName).async('uint8array');
  if (compressed) colBytes = zstdDecompress(colBytes);

  const db = new SQL.Database(colBytes);
  try {
    const pkg = readCollectionDb(db);
    pkg.media = await readMedia(zip, compressed, zstdDecompress);
    return pkg;
  } finally {
    db.close();
  }
}

function rows(db, sql) {
  const res = db.exec(sql);
  if (!res.length) return [];
  const { columns, values } = res[0];
  return values.map((v) => Object.fromEntries(columns.map((c, i) => [c, v[i]])));
}

function hasTable(db, name) {
  return rows(db, `select name from sqlite_master where type='table' and name='${name}'`).length > 0;
}

function bytesOf(v) {
  if (v instanceof Uint8Array) return v;
  if (typeof v === 'string') return new TextEncoder().encode(v);
  return new Uint8Array(0);
}

const r4 = (x) => Math.round(x * 10000) / 10000;

export function readCollectionDb(db) {
  const col = rows(db, 'select * from col')[0];
  if (!col) throw new Error('Collection is empty or damaged.');
  const crt = Number(col.crt) || Math.floor(Date.now() / 1000);
  const modern = hasTable(db, 'notetypes') && rows(db, 'select count(*) n from notetypes')[0].n > 0;

  const pkg = { crt, fsrs: false, notetypes: [], decks: [], dconfs: [], notes: [], cards: [], revlog: [], media: [] };

  if (modern) {
    readModernConfig(db, pkg);
  } else {
    readLegacyConfig(col, pkg);
  }

  // ---- notes
  for (const r of rows(db, 'select id, guid, mid, mod, tags, flds from notes')) {
    pkg.notes.push({
      id: Number(r.id), guid: String(r.guid), mid: Number(r.mid),
      mod: Number(r.mod) * 1000,
      tags: String(r.tags || '').trim().split(/\s+/).filter(Boolean),
      flds: String(r.flds).split('\x1f'),
    });
  }

  // ---- cards
  const crtDay = dayIndex(crt * 1000);
  for (const r of rows(db, 'select * from cards')) {
    pkg.cards.push(normalizeCard(r, crtDay));
  }

  // ---- review history
  for (const r of rows(db, 'select id, cid, ease, ivl, lastIvl, factor, time, type from revlog order by id')) {
    pkg.revlog.push({
      id: Number(r.id), cid: Number(r.cid), ease: Number(r.ease), ivl: Number(r.ivl),
      lastIvl: Number(r.lastIvl), factor: Number(r.factor), time: Number(r.time), type: Number(r.type),
    });
  }
  // last review time per card helps FSRS
  const last = new Map();
  for (const rv of pkg.revlog) last.set(rv.cid, rv.id);
  for (const c of pkg.cards) if (last.has(c.id)) c.lastReview = last.get(c.id);
  return pkg;
}

function normalizeCard(r, crtDay) {
  let did = Number(r.did), due = Number(r.due), queue = Number(r.queue);
  const type = Number(r.type);
  if (Number(r.odid)) { did = Number(r.odid); due = Number(r.odue); }
  // un-bury, and drop the preview queue
  if (queue === -2 || queue === -3 || queue === 4) {
    queue = type === 0 ? 0 : type === 2 ? 2 : (due > 1e9 ? 1 : 3);
  }
  const c = {
    id: Number(r.id), nid: Number(r.nid), did, ord: Number(r.ord),
    mod: Number(r.mod) * 1000,
    type, queue,
    pos: 0, dueAt: 0, dueDay: 0,
    ivl: Number(r.ivl) || 0, factor: Number(r.factor) || 0,
    reps: Number(r.reps) || 0, lapses: Number(r.lapses) || 0,
    left: (Number(r.left) || 0) % 1000,
    flags: (Number(r.flags) || 0) & 7,
    s: null, d: null, lastReview: 0,
  };
  const effQueue = queue === -1 ? (type === 0 ? 0 : type === 2 ? 2 : (due > 1e9 ? 1 : 3)) : queue;
  if (effQueue === 0) c.pos = due;
  else if (effQueue === 1) c.dueAt = due * 1000;
  else c.dueDay = crtDay + due; // review (2) and day-learning (3)
  try {
    const data = r.data ? JSON.parse(r.data) : null;
    if (data && typeof data.s === 'number') { c.s = data.s; c.d = data.d; }
  } catch { /* ignore */ }
  return c;
}

function readLegacyConfig(col, pkg) {
  const models = JSON.parse(col.models || '{}');
  for (const m of Object.values(models)) {
    pkg.notetypes.push({
      id: Number(m.id), name: m.name, kind: Number(m.type) === 1 ? 1 : 0,
      css: m.css || '', sortf: m.sortf || 0,
      flds: [...(m.flds || [])].sort((a, b) => a.ord - b.ord).map((f) => f.name),
      tmpls: [...(m.tmpls || [])].sort((a, b) => a.ord - b.ord).map((t) => ({ name: t.name, qfmt: t.qfmt || '', afmt: t.afmt || '' })),
      mod: (Number(m.mod) || 0) * 1000,
    });
  }
  const decks = JSON.parse(col.decks || '{}');
  for (const d of Object.values(decks)) {
    if (d.dyn) continue; // filtered decks: cards are returned to their home deck
    pkg.decks.push({ id: Number(d.id), name: d.name, confId: Number(d.conf) || 1, desc: d.desc || '' });
  }
  const dconf = JSON.parse(col.dconf || '{}');
  for (const c of Object.values(dconf)) {
    const conf = defaultConf(Number(c.id), c.name);
    if (c.new) {
      if (Array.isArray(c.new.delays) && c.new.delays.length) conf.learnSteps = c.new.delays.map(Number);
      if (Array.isArray(c.new.ints)) { conf.gradGood = c.new.ints[0] || 1; conf.gradEasy = c.new.ints[1] || 4; }
      if (c.new.initialFactor) conf.initialEase = c.new.initialFactor / 1000;
      if (c.new.perDay != null) conf.newPerDay = Number(c.new.perDay);
    }
    if (c.rev) {
      if (c.rev.perDay != null) conf.revPerDay = Number(c.rev.perDay);
      if (c.rev.ease4) conf.easyMult = Number(c.rev.ease4);
      if (c.rev.hardFactor) conf.hardMult = Number(c.rev.hardFactor);
      if (c.rev.maxIvl) conf.maxIvl = Number(c.rev.maxIvl);
      if (c.rev.ivlFct) conf.ivlMult = Number(c.rev.ivlFct);
    }
    if (c.lapse) {
      if (Array.isArray(c.lapse.delays) && c.lapse.delays.length) conf.relearnSteps = c.lapse.delays.map(Number);
      if (c.lapse.mult != null) conf.lapseMult = Number(c.lapse.mult);
      if (c.lapse.minInt) conf.minLapseIvl = Number(c.lapse.minInt);
    }
    if (c.desiredRetention) conf.desiredRetention = Number(c.desiredRetention);
    pkg.dconfs.push(conf);
  }
  try {
    const conf = JSON.parse(col.conf || '{}');
    if (conf.fsrs === true) pkg.fsrs = true;
  } catch { /* ignore */ }
}

function readModernConfig(db, pkg) {
  const fieldRows = rows(db, 'select ntid, ord, name from fields order by ntid, ord');
  const tmplRows = rows(db, 'select ntid, ord, name, config from templates order by ntid, ord');
  for (const r of rows(db, 'select id, name, mtime_secs, config from notetypes')) {
    const cfg = P.decode(bytesOf(r.config));
    const id = Number(r.id);
    pkg.notetypes.push({
      id, name: String(r.name),
      kind: P.num(cfg, 1) === 1 ? 1 : 0,
      css: P.str(cfg, 3),
      sortf: P.num(cfg, 2),
      flds: fieldRows.filter((f) => Number(f.ntid) === id).map((f) => String(f.name)),
      tmpls: tmplRows.filter((t) => Number(t.ntid) === id).map((t) => {
        const tc = P.decode(bytesOf(t.config));
        return { name: String(t.name), qfmt: P.str(tc, 1), afmt: P.str(tc, 2) };
      }),
      mod: Number(r.mtime_secs) * 1000,
    });
  }
  for (const r of rows(db, 'select id, name, kind from decks')) {
    const kind = P.decode(bytesOf(r.kind));
    if (kind.has(2)) continue; // filtered deck
    const normal = P.msg(kind, 1);
    pkg.decks.push({
      id: Number(r.id),
      name: String(r.name).split('\x1f').join('::'),
      confId: P.num(normal, 1) || 1,
      desc: P.str(normal, 4),
    });
  }
  if (hasTable(db, 'deck_config')) {
    for (const r of rows(db, 'select id, name, config from deck_config')) {
      const c = P.decode(bytesOf(r.config));
      const conf = defaultConf(Number(r.id), String(r.name));
      const ls = P.floats(c, 1).map(r4); if (ls.length) conf.learnSteps = ls;
      const rs = P.floats(c, 2).map(r4); if (rs.length) conf.relearnSteps = rs;
      if (P.has(c, 9)) conf.newPerDay = P.num(c, 9);
      if (P.has(c, 10)) conf.revPerDay = P.num(c, 10);
      if (P.has(c, 11)) conf.initialEase = r4(P.float(c, 11)) || 2.5;
      if (P.has(c, 12)) conf.easyMult = r4(P.float(c, 12)) || 1.3;
      if (P.has(c, 13)) conf.hardMult = r4(P.float(c, 13)) || 1.2;
      if (P.has(c, 14)) conf.lapseMult = r4(P.float(c, 14));
      if (P.has(c, 15)) conf.ivlMult = r4(P.float(c, 15)) || 1;
      if (P.has(c, 16)) conf.maxIvl = P.num(c, 16) || 36500;
      if (P.has(c, 17)) conf.minLapseIvl = P.num(c, 17) || 1;
      if (P.has(c, 18)) conf.gradGood = P.num(c, 18) || 1;
      if (P.has(c, 19)) conf.gradEasy = P.num(c, 19) || 4;
      if (P.has(c, 37)) conf.desiredRetention = r4(P.float(c, 37)) || 0.9;
      const f5 = P.floats(c, 5);
      if (f5.length >= 19) conf.fsrsParams = f5.slice(0, 19);
      pkg.dconfs.push(conf);
    }
  }
  if (hasTable(db, 'config')) {
    const fs = rows(db, "select val from config where key = 'fsrs'")[0];
    if (fs) { try { pkg.fsrs = JSON.parse(td.decode(bytesOf(fs.val))) === true; } catch { /* ignore */ } }
  }
}

async function readMedia(zip, compressed, zstdDecompress) {
  const mf = zip.file('media');
  if (!mf) return [];
  let raw = await mf.async('uint8array');
  let entries = [];
  if (compressed) {
    raw = zstdDecompress(raw);
    const m = P.decode(raw);
    entries = P.msgs(m, 1).map((e, i) => ({ zipName: String(i), name: P.str(e, 1) }));
  } else {
    let map = {};
    try { map = JSON.parse(td.decode(raw) || '{}'); } catch { map = {}; }
    entries = Object.entries(map).map(([k, v]) => ({ zipName: k, name: v }));
  }
  const out = [];
  for (const e of entries) {
    if (!e.name || e.name.includes('/') || e.name.includes('\\')) continue;
    const f = zip.file(e.zipName);
    if (!f) continue;
    let data = await f.async('uint8array');
    if (compressed) data = zstdDecompress(data);
    out.push({ name: e.name, data });
  }
  return out;
}

// ---------- writing ----------

const SCHEMA11 = `
CREATE TABLE col (id integer PRIMARY KEY, crt integer NOT NULL, mod integer NOT NULL, scm integer NOT NULL, ver integer NOT NULL, dty integer NOT NULL, usn integer NOT NULL, ls integer NOT NULL, conf text NOT NULL, models text NOT NULL, decks text NOT NULL, dconf text NOT NULL, tags text NOT NULL);
CREATE TABLE notes (id integer PRIMARY KEY, guid text NOT NULL, mid integer NOT NULL, mod integer NOT NULL, usn integer NOT NULL, tags text NOT NULL, flds text NOT NULL, sfld integer NOT NULL, csum integer NOT NULL, flags integer NOT NULL, data text NOT NULL);
CREATE TABLE cards (id integer PRIMARY KEY, nid integer NOT NULL, did integer NOT NULL, ord integer NOT NULL, mod integer NOT NULL, usn integer NOT NULL, type integer NOT NULL, queue integer NOT NULL, due integer NOT NULL, ivl integer NOT NULL, factor integer NOT NULL, reps integer NOT NULL, lapses integer NOT NULL, left integer NOT NULL, odue integer NOT NULL, odid integer NOT NULL, flags integer NOT NULL, data text NOT NULL);
CREATE TABLE revlog (id integer PRIMARY KEY, cid integer NOT NULL, usn integer NOT NULL, ease integer NOT NULL, ivl integer NOT NULL, lastIvl integer NOT NULL, factor integer NOT NULL, time integer NOT NULL, type integer NOT NULL);
CREATE TABLE graves (usn integer NOT NULL, oid integer NOT NULL, type integer NOT NULL);
CREATE INDEX ix_notes_usn ON notes (usn);
CREATE INDEX ix_cards_usn ON cards (usn);
CREATE INDEX ix_revlog_usn ON revlog (usn);
CREATE INDEX ix_cards_nid ON cards (nid);
CREATE INDEX ix_cards_sched ON cards (did, queue, due);
CREATE INDEX ix_revlog_cid ON revlog (cid);
CREATE INDEX ix_notes_csum ON notes (csum);
`;

function legacyModel(nt) {
  return {
    id: nt.id, name: nt.name, type: nt.kind, mod: Math.floor((nt.mod || Date.now()) / 1000), usn: -1,
    sortf: nt.sortf || 0, did: null,
    tmpls: nt.tmpls.map((t, i) => ({ name: t.name, ord: i, qfmt: t.qfmt, afmt: t.afmt, bqfmt: '', bafmt: '', did: null, bfont: '', bsize: 0 })),
    flds: nt.flds.map((f, i) => ({ name: f, ord: i, sticky: false, rtl: false, font: 'Arial', size: 20, media: [] })),
    css: nt.css || '', latexPre: '', latexPost: '', latexsvg: false,
    req: nt.tmpls.map((_, i) => [i, 'any', [0]]), tags: [], vers: [],
  };
}

function legacyDeck(d) {
  return {
    id: d.id, name: d.name, mod: Math.floor(Date.now() / 1000), usn: -1,
    lrnToday: [0, 0], revToday: [0, 0], newToday: [0, 0], timeToday: [0, 0],
    collapsed: false, browserCollapsed: false, desc: d.desc || '', dyn: 0,
    conf: d.confId || 1, extendNew: 0, extendRev: 0,
  };
}

function legacyConf(c) {
  return {
    id: c.id, name: c.name, mod: 0, usn: -1, dyn: false, maxTaken: 60, timer: 0, autoplay: true, replayq: true,
    new: { delays: c.learnSteps, ints: [c.gradGood, c.gradEasy, 0], initialFactor: Math.round(c.initialEase * 1000), perDay: c.newPerDay, order: 1, bury: false, separate: true },
    rev: { perDay: c.revPerDay, ease4: c.easyMult, ivlFct: c.ivlMult, maxIvl: c.maxIvl, bury: false, hardFactor: c.hardMult, fuzz: 0.05, minSpace: 1 },
    lapse: { delays: c.relearnSteps, mult: c.lapseMult, minInt: c.minLapseIvl, leechFails: 8, leechAction: 1 },
  };
}

// col: { meta:{crt}, notetypes:Map, decks:Map, dconfs:Map, notes:Map, cards:Map, revlog:Array }
// opts.deckIds: Set of deck ids to include (with children) — null = everything
// opts.getMedia(name) -> Promise<Uint8Array|null>
export async function writePackage(col, { SQL, JSZip }, opts = {}) {
  const withScheduling = opts.withScheduling !== false;
  const deckIds = opts.deckIds || null;
  const crt = col.meta.crt || Math.floor(Date.now() / 1000);
  const crtDay = dayIndex(crt * 1000);

  const cards = [...col.cards.values()].filter((c) => !deckIds || deckIds.has(c.did));
  const nids = new Set(cards.map((c) => c.nid));
  const notes = [...col.notes.values()].filter((n) => nids.has(n.id));
  const mids = new Set(notes.map((n) => n.mid));
  const usedDecks = new Set(cards.map((c) => c.did));
  // include parents of used decks
  const decks = [...col.decks.values()];
  const byName = new Map(decks.map((d) => [d.name, d]));
  const deckOut = new Map();
  for (const d of decks) {
    if (!usedDecks.has(d.id)) continue;
    const parts = d.name.split('::');
    for (let i = 1; i <= parts.length; i++) {
      const p = byName.get(parts.slice(0, i).join('::'));
      if (p) deckOut.set(p.id, p);
    }
  }
  if (!deckOut.has(1)) deckOut.set(1, { id: 1, name: 'Default', confId: 1 });

  const db = new SQL.Database();
  try {
    db.exec(SCHEMA11);
    const models = {};
    for (const nt of col.notetypes.values()) if (mids.has(nt.id)) models[nt.id] = legacyModel(nt);
    const decksJson = {};
    for (const d of deckOut.values()) decksJson[d.id] = legacyDeck(d);
    const dconfJson = {};
    for (const c of col.dconfs.values()) dconfJson[c.id] = legacyConf(c);
    if (!dconfJson[1]) dconfJson[1] = legacyConf({ ...defaultConfFrom(), id: 1, name: 'Default' });
    const now = Math.floor(Date.now() / 1000);
    const conf = { nextPos: 1 + Math.max(0, ...cards.filter((c) => c.type === 0).map((c) => c.pos || 0)), curDeck: 1, activeDecks: [1], sortType: 'noteFld', sortBackwards: false, schedVer: 2, collapseTime: 1200, estTimes: true, dueCounts: true, newSpread: 0, fsrs: !!col.meta.fsrs };
    db.run('insert into col values (1,?,?,?,11,0,0,0,?,?,?,?,?)', [crt, now * 1000, now * 1000, JSON.stringify(conf), JSON.stringify(models), JSON.stringify(decksJson), JSON.stringify(dconfJson), '{}']);

    const nstmt = db.prepare('insert into notes values (?,?,?,?,?,?,?,?,?,0,\'\')');
    for (const n of notes) {
      const nt = col.notetypes.get(n.mid);
      const sfldRaw = stripHtml(n.flds[(nt && nt.sortf) || 0] || '');
      const csum = parseInt((await sha1Hex(stripHtml(n.flds[0] || ''))).slice(0, 8), 16);
      nstmt.run([n.id, n.guid, n.mid, Math.floor((n.mod || Date.now()) / 1000), -1, n.tags.length ? ` ${n.tags.join(' ')} ` : '', n.flds.join('\x1f'), sfldRaw, csum]);
    }
    nstmt.free();

    const cstmt = db.prepare('insert into cards values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,?,?)');
    let newPos = 1;
    for (const c of cards) {
      let type = c.type, queue = c.queue, due, ivl = c.ivl, factor = c.factor, reps = c.reps, lapses = c.lapses, left = c.left;
      if (!withScheduling) { type = 0; queue = 0; ivl = 0; factor = 0; reps = 0; lapses = 0; left = 0; }
      const effQ = queue === -1 ? (type === 0 ? 0 : type === 2 ? 2 : (c.dueAt ? 1 : 3)) : queue;
      if (type === 0 || effQ === 0) due = withScheduling ? (c.pos || newPos++) : newPos++;
      else if (effQ === 1) due = Math.floor(c.dueAt / 1000);
      else due = c.dueDay - crtDay;
      const data = withScheduling && c.s != null ? JSON.stringify({ s: round4(c.s), d: round4(c.d) }) : '';
      cstmt.run([c.id, c.nid, c.did, c.ord, Math.floor((c.mod || Date.now()) / 1000), -1, type, queue, due, ivl, factor, reps, lapses, left, c.flags || 0, data]);
    }
    cstmt.free();

    if (withScheduling) {
      const cids = new Set(cards.map((c) => c.id));
      const rstmt = db.prepare('insert into revlog values (?,?,-1,?,?,?,?,?,?)');
      for (const r of col.revlog) {
        if (!cids.has(r.cid)) continue;
        rstmt.run([r.id, r.cid, r.ease, r.ivl, r.lastIvl, r.factor, r.time, r.type]);
      }
      rstmt.free();
    }

    const bytes = db.export();
    const zip = new JSZip();
    zip.file('collection.anki21', bytes);
    // Anki 2.1.50+ still opens anki21 packages; also add a stub anki2 so very old versions complain clearly.
    // media
    const mediaNames = new Set();
    if (opts.getMedia) {
      const re = /(?:src=["']?)([^"'>\s]+)|\[sound:([^\]]+)\]/gi;
      for (const n of notes) {
        for (const f of n.flds) {
          let m;
          re.lastIndex = 0;
          while ((m = re.exec(f))) {
            const name = decodeURIComponent((m[1] || m[2] || '').trim());
            if (name && !/^(https?:|data:|blob:)/i.test(name)) mediaNames.add(name);
          }
        }
      }
      for (const nt of col.notetypes.values()) {
        if (!mids.has(nt.id)) continue;
        const re2 = /["'(](_[^"'()]+\.(?:ttf|otf|woff2?|css|js|png|jpe?g|svg|gif|webp))["')]/gi;
        let m;
        const text = nt.css + nt.tmpls.map((t) => t.qfmt + t.afmt).join('');
        while ((m = re2.exec(text))) mediaNames.add(m[1]);
      }
    }
    const map = {};
    let idx = 0;
    for (const name of mediaNames) {
      const data = await opts.getMedia(name);
      if (!data) continue;
      zip.file(String(idx), data);
      map[idx] = name;
      idx++;
    }
    zip.file('media', JSON.stringify(map));
    return await zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } });
  } finally {
    db.close();
  }
}

function defaultConfFrom() { return defaultConf(); }
function round4(x) { return Math.round(x * 10000) / 10000; }
