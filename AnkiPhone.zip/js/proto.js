// Minimal protobuf reader/writer — just enough for Anki's schema-18 blobs.

export function decode(buf) {
  // Returns a map: fieldNumber -> array of raw values.
  // varint fields -> Number (or BigInt-safe Number), length-delimited -> Uint8Array,
  // fixed32 -> {f32: bytes}, fixed64 -> {f64: bytes}.
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf || []);
  const out = new Map();
  let i = 0;
  const readVarint = () => {
    let result = 0, shift = 0, b;
    do {
      if (i >= bytes.length) throw new Error('proto: truncated varint');
      b = bytes[i++];
      // use multiplication to stay safe above 2^31
      result += (b & 0x7f) * Math.pow(2, shift);
      shift += 7;
    } while (b & 0x80);
    return result;
  };
  while (i < bytes.length) {
    const key = readVarint();
    const field = Math.floor(key / 8);
    const wire = key & 7;
    let val;
    if (wire === 0) val = readVarint();
    else if (wire === 2) {
      const len = readVarint();
      val = bytes.subarray(i, i + len);
      i += len;
    } else if (wire === 5) { val = { f32: bytes.subarray(i, i + 4) }; i += 4; }
    else if (wire === 1) { val = { f64: bytes.subarray(i, i + 8) }; i += 8; }
    else throw new Error('proto: unsupported wire type ' + wire);
    if (!out.has(field)) out.set(field, []);
    out.get(field).push(val);
  }
  return out;
}

const td = new TextDecoder();
const te = new TextEncoder();

export function str(m, f, dflt = '') {
  const v = m.get(f);
  return v && v.length ? td.decode(v[v.length - 1]) : dflt;
}
export function num(m, f, dflt = 0) {
  const v = m.get(f);
  if (!v || !v.length) return dflt;
  const x = v[v.length - 1];
  if (typeof x === 'number') return x;
  if (x && x.f32) return new DataView(x.f32.buffer, x.f32.byteOffset, 4).getFloat32(0, true);
  if (x && x.f64) return new DataView(x.f64.buffer, x.f64.byteOffset, 8).getFloat64(0, true);
  return dflt;
}
export function float(m, f, dflt = 0) {
  const v = m.get(f);
  if (!v || !v.length) return dflt;
  const x = v[v.length - 1];
  if (x && x.f32) return new DataView(x.f32.buffer, x.f32.byteOffset, 4).getFloat32(0, true);
  if (x && x.f64) return new DataView(x.f64.buffer, x.f64.byteOffset, 8).getFloat64(0, true);
  return typeof x === 'number' ? x : dflt;
}
// repeated float: may be packed (one length-delimited blob) or unpacked
export function floats(m, f) {
  const v = m.get(f);
  if (!v) return [];
  const res = [];
  for (const x of v) {
    if (x instanceof Uint8Array) {
      const dv = new DataView(x.buffer, x.byteOffset, x.byteLength);
      for (let k = 0; k + 4 <= x.byteLength; k += 4) res.push(dv.getFloat32(k, true));
    } else if (x && x.f32) {
      res.push(new DataView(x.f32.buffer, x.f32.byteOffset, 4).getFloat32(0, true));
    }
  }
  return res;
}
export function msg(m, f) {
  const v = m.get(f);
  return v && v.length ? decode(v[v.length - 1]) : new Map();
}
export function msgs(m, f) {
  return (m.get(f) || []).map((b) => decode(b));
}
export function has(m, f) {
  return m.has(f);
}

// ---- writer ----
export class Writer {
  constructor() { this.parts = []; }
  varint(n) {
    const a = [];
    n = Math.max(0, Math.floor(n));
    while (n >= 0x80) { a.push((n % 128) | 0x80); n = Math.floor(n / 128); }
    a.push(n);
    this.parts.push(Uint8Array.from(a));
  }
  key(field, wire) { this.varint(field * 8 + wire); }
  uint(field, n) { if (n) { this.key(field, 0); this.varint(n); } return this; }
  bool(field, b) { if (b) { this.key(field, 0); this.varint(1); } return this; }
  bytes(field, u8) { this.key(field, 2); this.varint(u8.length); this.parts.push(u8); return this; }
  string(field, s) { if (s) this.bytes(field, te.encode(s)); return this; }
  message(field, w) { return this.bytes(field, w.finish()); }
  finish() {
    let len = 0;
    for (const p of this.parts) len += p.length;
    const out = new Uint8Array(len);
    let o = 0;
    for (const p of this.parts) { out.set(p, o); o += p.length; }
    return out;
  }
}
