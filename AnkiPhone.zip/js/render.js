// Card rendering: Anki template syntax, cloze, image occlusion, media, type-in answers.

import { esc, stripHtml } from './util.js';

const REVEAL_FIELD = /extra|hint|note|mnemonic|comment|personal|lecture|source|additional|explanation/i;

export function isIoNotetype(nt) {
  return nt.tmpls.some((t) => /image-occlusion-container|\{\{cloze:Occlusion\}\}/.test(t.qfmt));
}

// ---------- cloze ----------
// Parse text into nodes: strings and {ords:Set, nodes:[...], hint}
function parseClozes(text) {
  const out = [];
  const stack = [];
  const re = /\{\{c(\d+(?:,\d+)*)::|\}\}/g;
  let last = 0, m;
  const pushText = (t) => {
    if (!t) return;
    if (stack.length) {
      const cur = stack[stack.length - 1];
      if (!t.startsWith('image-occlusion:') && cur.hint == null) {
        const i = t.indexOf('::');
        if (i >= 0) { cur.hint = t.slice(i + 2); t = t.slice(0, i); }
      }
      cur.nodes.push(t);
    } else out.push(t);
  };
  while ((m = re.exec(text))) {
    pushText(text.slice(last, m.index));
    last = re.lastIndex;
    if (m[0] === '}}') {
      if (stack.length) {
        const c = stack.pop();
        (stack.length ? stack[stack.length - 1].nodes : out).push(c);
      } else pushText('}}');
    } else {
      stack.push({ ords: new Set(m[1].split(',').map(Number)), nodes: [], hint: null });
    }
  }
  pushText(text.slice(last));
  // unclosed clozes: flatten back to text
  while (stack.length) {
    const c = stack.pop();
    const flat = `{{c${[...c.ords].join(',')}::` + c.nodes.map((n) => (typeof n === 'string' ? n : '')).join('');
    (stack.length ? stack[stack.length - 1].nodes : out).push(flat);
  }
  return out;
}

function clozeText(nodes) {
  return nodes.map((n) => (typeof n === 'string' ? n : clozeText(n.nodes))).join('');
}

function renderClozeNodes(nodes, ord, question) {
  let s = '';
  for (const n of nodes) {
    if (typeof n === 'string') { s += n; continue; }
    const inner = clozeText(n.nodes);
    if (n.ords.has(ord)) {
      if (inner.startsWith('image-occlusion:')) { s += ''; continue; }
      if (question) {
        s += `<span class="cloze" data-cloze="${esc(inner)}" data-ordinal="${ord}">[${n.hint != null ? esc(n.hint) : '...'}]</span>`;
      } else {
        s += `<span class="cloze" data-ordinal="${ord}">${renderClozeNodes(n.nodes, ord, question)}</span>`;
      }
    } else {
      if (inner.startsWith('image-occlusion:')) continue;
      s += `<span class="cloze-inactive" data-ordinal="${[...n.ords].join(',')}">${renderClozeNodes(n.nodes, ord, question)}</span>`;
    }
  }
  return s;
}

export function clozeOrdinals(text) {
  const ords = new Set();
  const walk = (nodes) => {
    for (const n of nodes) if (typeof n !== 'string') { n.ords.forEach((o) => ords.add(o)); walk(n.nodes); }
  };
  walk(parseClozes(text || ''));
  return [...ords].sort((a, b) => a - b);
}

export function clozeOnly(text, ord) {
  const found = [];
  const walk = (nodes) => {
    for (const n of nodes) if (typeof n !== 'string') {
      if (n.ords.has(ord)) found.push(clozeText(n.nodes));
      walk(n.nodes);
    }
  };
  walk(parseClozes(text));
  return found.join(', ');
}

// ---------- image occlusion ----------
export function parseOcclusions(text) {
  const shapes = [];
  const walk = (nodes) => {
    for (const n of nodes) {
      if (typeof n === 'string') continue;
      const inner = clozeText(n.nodes);
      if (inner.startsWith('image-occlusion:')) {
        const spec = inner.slice('image-occlusion:'.length);
        // split on unescaped ':'
        const parts = [];
        let cur = '';
        for (let i = 0; i < spec.length; i++) {
          if (spec[i] === '\\' && i + 1 < spec.length) { cur += spec[++i]; continue; }
          if (spec[i] === ':') { parts.push(cur); cur = ''; continue; }
          cur += spec[i];
        }
        parts.push(cur);
        const sh = { kind: parts[0], ords: [...n.ords], props: {} };
        for (const p of parts.slice(1)) {
          const k = p.indexOf('=');
          if (k > 0) sh.props[p.slice(0, k)] = p.slice(k + 1);
        }
        shapes.push(sh);
      }
      walk(n.nodes);
    }
  };
  walk(parseClozes(text || ''));
  return shapes;
}

export function serializeOcclusions(shapes) {
  // shapes: [{ord, kind:'rect', left, top, width, height}] with fractions 0..1
  return shapes.map((s) => {
    const f = (x) => (Math.round(x * 10000) / 10000).toString().replace(/^0\./, '.');
    return `{{c${s.ord}::image-occlusion:${s.kind}:left=${f(s.left)}:top=${f(s.top)}:width=${f(s.width)}:height=${f(s.height)}:oi=1}}`;
  }).join('<br>');
}

function renderIO(note, nt, card, side, ctx) {
  const f = (name, idx) => {
    const i = nt.flds.indexOf(name);
    return note.flds[i >= 0 ? i : idx] || '';
  };
  const occl = f('Occlusion', 0);
  const image = f('Image', 1);
  const header = f('Header', 2);
  const backExtra = f('Back Extra', 3);
  const ord = card.ord + 1;
  const shapes = parseOcclusions(occl).map((s) => ({ ...s, active: s.ords.includes(ord) }));
  let html = '';
  if (header) html += `<div class="io-header">${header}</div>`;
  html += `<div class="io" data-side="${side}" data-shapes='${esc(JSON.stringify(shapes))}'>${image}</div>`;
  if (side === 'a') {
    html += '<div class="io-tools"><button type="button" class="io-toggle">Toggle masks</button></div>';
    if (backExtra) html += `<div class="io-extra">${wrapReveal('Back Extra', backExtra, ctx)}</div>`;
  }
  return html;
}

// ---------- type-in answer ----------
export function compareAnswer(expected, typed) {
  const a = stripHtml(expected), b = (typed || '').trim();
  if (!b) return `<code class="typeans"><span class="typeMissed">${esc(a)}</span></code>`;
  if (a === b) return `<code class="typeans"><span class="typeGood">${esc(a)}</span></code>`;
  // LCS diff by characters
  const n = a.length, m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--)
    dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  let i = 0, j = 0, typedOut = '', expOut = '';
  while (i < n && j < m) {
    if (a[i] === b[j]) { typedOut += `<span class="typeGood">${esc(b[j])}</span>`; expOut += `<span class="typeGood">${esc(a[i])}</span>`; i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { expOut += `<span class="typeMissed">${esc(a[i])}</span>`; i++; }
    else { typedOut += `<span class="typeBad">${esc(b[j])}</span>`; j++; }
  }
  while (j < m) typedOut += `<span class="typeBad">${esc(b[j++])}</span>`;
  while (i < n) expOut += `<span class="typeMissed">${esc(a[i++])}</span>`;
  return `<code class="typeans">${typedOut}<br><span class="typearrow">↓</span><br>${expOut}</code>`;
}

function wrapReveal(label, content, ctx) {
  if (!ctx.addons || !ctx.addons.hints || !content || !stripHtml(content) && !/<img/i.test(content)) return content;
  return `<details class="reveal"><summary>${esc(label)}</summary><div>${content}</div></details>`;
}

// ---------- furigana ----------
function furigana(s, mode) {
  return s.replace(/ ?([^ >]+?)\[(.+?)\]/g, (_, base, reading) => {
    if (mode === 'kana') return reading;
    if (mode === 'kanji') return base;
    return `<ruby><rb>${base}</rb><rt>${reading}</rt></ruby>`;
  });
}

// ---------- templates ----------
function fieldMap(note, nt, card, ctx) {
  const map = new Map();
  nt.flds.forEach((name, i) => map.set(name, note.flds[i] ?? ''));
  map.set('Tags', esc(note.tags.join(' ')));
  const deck = ctx.deckName || '';
  map.set('Deck', esc(deck));
  map.set('Subdeck', esc(deck.split('::').pop()));
  map.set('Type', esc(nt.name));
  map.set('Card', esc(nt.kind === 1 ? `Cloze ${card.ord + 1}` : (nt.tmpls[card.ord] || {}).name || ''));
  map.set('CardFlag', card.flags ? `flag${card.flags}` : '');
  return map;
}

function nonEmpty(v) {
  return !!(v && (stripHtml(v) || /<img|\[sound:/i.test(v)));
}

function applyFilters(fieldName, value, filters, st) {
  let v = value;
  // filters apply innermost first: {{a:b:Field}} -> b then a
  for (let i = filters.length - 1; i >= 0; i--) {
    const f = filters[i];
    if (f === 'text') v = esc(stripHtml(v));
    else if (f === 'cloze') v = st.nt.kind === 1 ? renderClozeNodes(parseClozes(v), st.card.ord + 1, st.side === 'q') : v;
    else if (f === 'cloze-only') v = esc(clozeOnly(v, st.card.ord + 1));
    else if (f === 'hint') {
      if (!nonEmpty(v)) { v = ''; continue; }
      v = `<a class="hint" href="#">${esc(fieldName)}</a><div class="hint-body" hidden>${v}</div>`;
    } else if (f === 'type') {
      // handled by caller
    } else if (f === 'furigana' || f === 'kana' || f === 'kanji') v = furigana(v, f);
    // tts, nc, unknown: pass through
  }
  return v;
}

function renderTemplate(tmpl, fields, st) {
  // sections first (supports nesting)
  const sectionRe = /\{\{([#^])\s*([^}]+?)\s*\}\}([\s\S]*?)\{\{\/\s*\2\s*\}\}/;
  let guard = 0;
  while (sectionRe.test(tmpl) && guard++ < 200) {
    tmpl = tmpl.replace(sectionRe, (_, kind, name, body) => {
      const key = name.split(':').pop().trim();
      let val = fields.has(key) ? fields.get(key) : '';
      if (name.startsWith('cloze:') && st.nt.kind === 1) {
        val = clozeOrdinals(val).includes(st.card.ord + 1) ? 'x' : '';
      }
      const show = kind === '#' ? nonEmpty(val) : !nonEmpty(val);
      return show ? body : '';
    });
  }
  return tmpl.replace(/\{\{\s*([^{}]+?)\s*\}\}/g, (whole, inner) => {
    if (inner === 'FrontSide') return st.side === 'a' ? (st.frontHtml || '') : '';
    const parts = inner.split(':');
    const name = parts.pop().trim();
    const filters = parts.map((p) => p.trim());
    if (filters.includes('type')) {
      const raw = fields.has(name) ? fields.get(name) : '';
      const expected = filters.includes('cloze') ? clozeOnly(raw, st.card.ord + 1) : raw;
      st.hasTypeAnswer = true;
      if (st.side === 'q') return '<input type="text" class="typeans-input" id="typeans" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Type answer">';
      return compareAnswer(expected, st.typed);
    }
    if (!fields.has(name)) {
      if (name.startsWith('#') || name.startsWith('/') || name.startsWith('^')) return '';
      return `<span class="missing-field">{unknown field ${esc(name)}}</span>`;
    }
    let v = applyFilters(name, fields.get(name), filters, st);
    if (st.side === 'a' && !filters.length && REVEAL_FIELD.test(name)) v = wrapReveal(name, v, st.ctx);
    return v;
  });
}

function stripFront(html) {
  // Anki removes the type-answer box from {{FrontSide}}
  return html.replace(/<input type="text" class="typeans-input"[^>]*>/g, '');
}

// Replace media references with resolvable URLs.
export function resolveMedia(html, mediaUrl) {
  if (!mediaUrl) return html;
  html = html.replace(/(<(?:img|source|audio|video)\b[^>]*?\bsrc\s*=\s*)(["']?)([^"'\s>]+)\2/gi, (whole, pre, q, name) => {
    if (/^(https?:|data:|blob:)/i.test(name)) return whole;
    let decoded = name;
    try { decoded = decodeURIComponent(name); } catch { /* keep */ }
    const url = mediaUrl(decoded);
    return url ? `${pre}"${url}" data-media="${esc(decoded)}"` : `${pre}"" data-missing-media="${esc(decoded)}"`;
  });
  html = html.replace(/\[sound:([^\]]+)\]/g, (_, name) => {
    const url = mediaUrl(name.trim());
    return url ? `<button type="button" class="play-sound" data-src="${url}" aria-label="Play audio">▶</button>` : '';
  });
  return html;
}

export function resolveCssMedia(css, mediaUrl) {
  if (!mediaUrl) return css;
  return css.replace(/url\(\s*(["']?)([^"')]+)\1\s*\)/gi, (whole, q, name) => {
    if (/^(https?:|data:|blob:)/i.test(name)) return whole;
    const url = mediaUrl(name);
    return url ? `url("${url}")` : whole;
  });
}

// side: 'q' or 'a'. ctx: { deckName, mediaUrl, typed, addons }
export function renderCard(note, nt, card, side, ctx = {}) {
  const st = { nt, card, side: 'q', ctx, typed: ctx.typed, frontHtml: '', hasTypeAnswer: false };
  const tmpl = nt.kind === 1 ? nt.tmpls[0] : nt.tmpls[card.ord] || nt.tmpls[0];
  let qHtml, aHtml;
  if (isIoNotetype(nt)) {
    qHtml = renderIO(note, nt, card, 'q', ctx);
    aHtml = renderIO(note, nt, card, 'a', ctx);
  } else {
    const fields = fieldMap(note, nt, card, ctx);
    qHtml = renderTemplate(tmpl.qfmt, fields, st);
    const typeOnFront = st.hasTypeAnswer;
    if (side === 'a') {
      st.side = 'a';
      st.frontHtml = stripFront(qHtml);
      aHtml = renderTemplate(tmpl.afmt, fields, st);
    }
    st.hasTypeAnswer = typeOnFront;
  }
  let html = side === 'q' ? qHtml : aHtml;
  // scripts don't run inside cards here; drop them to keep the DOM clean
  html = html.replace(/<script[\s\S]*?<\/script>/gi, '');
  html = resolveMedia(html, ctx.mediaUrl);
  const css = resolveCssMedia(nt.css || '', ctx.mediaUrl);
  return { html, css, hasTypeAnswer: st.hasTypeAnswer };
}

// Which card ordinals a note should have.
export function cardOrdsForNote(note, nt) {
  if (nt.kind === 1) {
    const ords = new Set();
    nt.flds.forEach((_, i) => clozeOrdinals(note.flds[i]).forEach((o) => ords.add(o - 1)));
    return [...ords].sort((a, b) => a - b);
  }
  const fields = new Map(nt.flds.map((n, i) => [n, note.flds[i] || '']));
  const res = [];
  nt.tmpls.forEach((t, ord) => {
    // a card exists if its front references at least one non-empty field
    const names = [...t.qfmt.matchAll(/\{\{([^#^/}][^}]*)\}\}/g)].map((m) => m[1].split(':').pop().trim());
    if (names.some((n) => nonEmpty(fields.get(n)))) res.push(ord);
  });
  return res.length ? res : [0];
}
