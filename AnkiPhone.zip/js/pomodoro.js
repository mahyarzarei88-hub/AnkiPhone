// Pomodoro timer: focus blocks and breaks, by clock or by card count.

import { dayIndex } from './util.js';

export const POMO_PRESETS = {
  classic: { focus: 25, short: 5, long: 15, longEvery: 4, label: '25 / 5' },
  long: { focus: 50, short: 10, long: 20, longEvery: 3, label: '50 / 10' },
  cards: { focus: 0, short: 5, long: 15, longEvery: 4, cards: 100, label: '100 cards' },
};

export function defaultPomo() {
  return { mode: 'classic', focus: 25, short: 5, long: 15, longEvery: 4, cards: 100, pauseReviews: true, chime: true, autoStartBreak: true };
}

export class Pomodoro {
  // cfg: settings.pomo; saved: persisted state; onEvent(type) for 'break', 'focus', 'ready', 'tick'
  constructor(cfg, saved, { save, onEvent, clock } = {}) {
    this.cfg = cfg;
    this.save = save || (() => {});
    this.onEvent = onEvent || (() => {});
    this.clock = clock || (() => Date.now());
    this.s = Object.assign(this.fresh(), saved || {});
    if (this.s.day !== dayIndex(this.clock())) this.s = this.fresh();
    this.timer = null;
  }
  fresh() {
    return { phase: 'idle', kind: null, endsAt: 0, pausedLeft: 0, paused: false, block: 1, done: 0, day: dayIndex(this.clock()), stats: { answered: 0, correct: 0, timeMs: 0 }, lastStats: null };
  }
  get byCards() { return this.cfg.mode === 'cards'; }
  focusMs() { return (this.cfg.focus || 25) * 60000; }
  breakMs(kind) { return (kind === 'long' ? this.cfg.long || 15 : this.cfg.short || 5) * 60000; }
  persist() { this.save({ ...this.s }); }

  remainingMs() {
    if (this.s.paused) return this.s.pausedLeft;
    if (this.s.phase === 'idle' || this.s.phase === 'ready') return this.s.phase === 'ready' || !this.byCards ? this.focusMs() : 0;
    if (this.s.phase === 'focus' && this.byCards) return 0;
    return Math.max(0, this.s.endsAt - this.clock());
  }
  cardsLeft() { return Math.max(0, (this.cfg.cards || 100) - this.s.stats.answered); }
  totalMs() {
    if (this.s.phase === 'break') return this.breakMs(this.s.kind);
    return this.focusMs();
  }
  progress() {
    if (this.s.phase === 'focus' && this.byCards) return Math.min(1, this.s.stats.answered / (this.cfg.cards || 100));
    if (this.s.phase === 'idle' || this.s.phase === 'ready') return 0;
    return 1 - this.remainingMs() / this.totalMs();
  }

  startFocus() {
    this.s.phase = 'focus';
    this.s.kind = null;
    this.s.paused = false;
    this.s.stats = { answered: 0, correct: 0, timeMs: 0 };
    this.s.endsAt = this.byCards ? 0 : this.clock() + this.focusMs();
    this.persist();
    this.onEvent('focus');
    this.ensureTicking();
  }
  startBreak() {
    this.s.done += 1;
    this.s.lastStats = { ...this.s.stats };
    const every = this.cfg.longEvery || 4;
    this.s.kind = this.s.done % every === 0 ? 'long' : 'short';
    this.s.phase = 'break';
    this.s.paused = false;
    this.s.endsAt = this.clock() + this.breakMs(this.s.kind);
    this.s.block = this.s.done + 1;
    this.persist();
    this.onEvent('break');
    this.ensureTicking();
  }
  endBreak() {
    this.s.phase = 'ready';
    this.s.endsAt = 0;
    this.persist();
    this.onEvent('ready');
  }
  pause() {
    if (this.s.paused || (this.s.phase !== 'focus' && this.s.phase !== 'break')) return;
    this.s.pausedLeft = this.remainingMs();
    this.s.paused = true;
    this.persist();
    this.onEvent('tick');
  }
  resume() {
    if (!this.s.paused) return;
    this.s.paused = false;
    this.s.endsAt = this.clock() + this.s.pausedLeft;
    this.persist();
    this.ensureTicking();
    this.onEvent('tick');
  }
  toggle() {
    if (this.s.phase === 'idle' || this.s.phase === 'ready') this.startFocus();
    else if (this.s.paused) this.resume();
    else this.pause();
  }
  skip() {
    if (this.s.phase === 'focus') this.startBreak();
    else if (this.s.phase === 'break') { this.endBreak(); this.startFocus(); }
    else this.startFocus();
  }
  reset() {
    const keep = { done: this.s.done, block: this.s.block };
    this.s = Object.assign(this.fresh(), keep);
    this.persist();
    this.onEvent('tick');
  }
  // called after each review
  onAnswer(correct, timeMs) {
    if (this.s.phase !== 'focus') return;
    this.s.stats.answered++;
    if (correct) this.s.stats.correct++;
    this.s.stats.timeMs += timeMs;
    this.persist();
    if (this.byCards && this.s.stats.answered >= (this.cfg.cards || 100)) this.startBreak();
  }
  onUndo(wasCorrect) {
    if (this.s.phase !== 'focus' || !this.s.stats.answered) return;
    this.s.stats.answered--;
    if (wasCorrect && this.s.stats.correct) this.s.stats.correct--;
    this.persist();
  }
  get onBreak() { return this.s.phase === 'break'; }
  get running() { return (this.s.phase === 'focus' || this.s.phase === 'break') && !this.s.paused; }

  ensureTicking() {
    if (this.timer) return;
    this.timer = setInterval(() => this.tick(), 1000);
  }
  tick() {
    if (this.s.day !== dayIndex(this.clock()) && this.s.phase !== 'focus' && this.s.phase !== 'break') {
      this.s = this.fresh();
      this.persist();
    }
    if (!this.running) {
      if (!this.s.paused && this.timer && this.s.phase !== 'focus' && this.s.phase !== 'break') { clearInterval(this.timer); this.timer = null; }
      this.onEvent('tick');
      return;
    }
    if (this.s.endsAt && this.clock() >= this.s.endsAt) {
      if (this.s.phase === 'focus') this.startBreak();
      else if (this.s.phase === 'break') this.endBreak();
      return;
    }
    this.onEvent('tick');
  }
}
