// Adding and editing notes, the image occlusion editor, and deck options.

import * as db from './db.js';
import { app, addon, ensureMedia, mediaUrl, forgetMediaUrl } from './state.js';
import { openSheet, toast, confirmDialog, icon, pickFile } from './ui.js';
import { esc, newId, stripHtml, fmtIvl } from './util.js';
import { cardOrdsForNote, clozeOrdinals, isIoNotetype, parseOcclusions } from './render.js';
import { mimeFor } from './handoff.js';

const STOCK_CSS = `.card {
    font-family: arial;
    font-size: 20px;
    text-align: center;
    color: black;
    background-color: white;
}
`;
const CLOZE_CSS = STOCK_CSS + `
.cloze {
    font-weight: bold;
    color: blue;
}
.nightMode .cloze {
    color: lightblue;
}
`;
const IO_Q = `{{#Header}}<div>{{Header}}</div>{{/Header}}
<div style="display: none">{{cloze:Occlusion}}</div>
<div id="err"></div>
<div id="image-occlusion-container">
    {{Image}}
    <canvas id="image-occlusion-canvas"></canvas>
</div>
<script>
try {
    anki.imageOcclusion.setup();
} catch (exc) {
    document.getElementById("err").innerHTML = \`Error loading image occlusion.<br><br>\${exc}\`;
}
</script>
`;

const STOCK = {
  'Basic': { kind: 0, css: STOCK_CSS, flds: ['Front', 'Back'], tmpls: [{ name: 'Card 1', qfmt: '{{Front}}', afmt: '{{FrontSide}}\n\n<hr id=answer>\n\n{{Back}}' }] },
  'Basic (and reversed card)': { kind: 0, css: STOCK_CSS, flds: ['Front', 'Back'], tmpls: [{ name: 'Card 1', qfmt: '{{Front}}', afmt: '{{FrontSide}}\n\n<hr id=answer>\n\n{{Back}}' }, { name: 'Card 2', qfmt: '{{Back}}', afmt: '{{FrontSide}}\n\n<hr id=answer>\n\n{{Front}}' }] },
  'Cloze': { kind: 1, css: CLOZE_CSS, flds: ['Text', 'Back Extra'], tmpls: [{ name: 'Cloze', qfmt: '{{cloze:Text}}', afmt: '{{cloze:Text}}<br>\n{{Back Extra}}' }] },
  'Image Occlusion': { kind: 1, css: STOCK_CSS, flds: ['Occlusion', 'Image', 'Header', 'Back Extra', 'Comments'], tmpls: [{ name: 'Image Occlusion', qfmt: IO_Q, afmt: IO_Q + '\n<div><button id="toggle">Toggle Masks</button></div>\n{{#Back Extra}}<div>{{Back Extra}}</div>{{/Back Extra}}\n' }] },
};

async function ensureStockNotetype(name) {
  const col = app.col;
  for (const nt of col.notetypes.values()) if (nt.name === name) return nt;
  if (name === 'Image Occlusion') for (const nt of col.notetypes.values()) if (isIoNotetype(nt)) return nt;
  const def = STOCK[name];
  const nt = { id: newId(), name, kind: def.kind, css: def.css, sortf: 0, flds: [...def.flds], tmpls: def.tmpls.map((t) => ({ ...t })), mod: Date.now(), src: 'phone' };
  col.notetypes.set(nt.id, nt);
  await col.persist({ notetypes: [nt] });
  return nt;
}

async function ensureBasicNotetypes() {
  if (app.col.notetypes.size) return;
  for (const n of ['Basic', 'Basic (and reversed card)', 'Cloze']) await ensureStockNotetype(n);
}

// ---------- media ----------
async function sha1Bytes(buf) {
  const h = await crypto.subtle.digest('SHA-1', buf);
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Downscale big photos so the collection stays small; returns {name, blob}
export async function saveImageFile(file, maxDim = 1600) {
  let blob = file;
  let ext = (file.name && file.name.split('.').pop() || 'jpg').toLowerCase();
  if (/^image\/(jpeg|png|webp|heic|heif)$/.test(file.type) || !file.type) {
    try {
      const bmp = await createImageBitmap(file);
      const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
      if (scale < 1 || /heic|heif/.test(file.type)) {
        const c = document.createElement('canvas');
        c.width = Math.round(bmp.width * scale);
        c.height = Math.round(bmp.height * scale);
        c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
        blob = await new Promise((res) => c.toBlob(res, 'image/jpeg', 0.85));
        ext = 'jpg';
      }
    } catch { /* keep original */ }
  }
  const buf = await blob.arrayBuffer();
  const name = `paste-${(await sha1Bytes(buf)).slice(0, 24)}.${ext === 'jpeg' ? 'jpg' : ext}`;
  const stored = new Blob([buf], { type: mimeFor(name) });
  await db.putMedia([{ name, blob: stored }]);
  app.col.mediaNames.add(name);
  forgetMediaUrl(name);
  await ensureMedia([name]);
  return { name, blob: stored };
}

// field html <-> editor html: media names become object URLs while editing
function toEditorHtml(html) {
  return (html || '').replace(/(<img\b[^>]*?\bsrc\s*=\s*)(["']?)([^"'\s>]+)\2/gi, (w, pre, q, name) => {
    if (/^(https?:|data:|blob:)/i.test(name)) return w;
    let n = name; try { n = decodeURIComponent(name); } catch { /* keep */ }
    const url = mediaUrl(n);
    return url ? `${pre}"${url}" data-media="${esc(n)}"` : w;
  });
}
function fromEditorHtml(html) {
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  tmp.querySelectorAll('img[data-media]').forEach((img) => { img.setAttribute('src', img.dataset.media); img.removeAttribute('data-media'); });
  let out = tmp.innerHTML;
  out = out.replace(/<div><br><\/div>$/i, '').replace(/^<br>$/i, '');
  return out.trim();
}

function deckOptions(selected) {
  return [...app.col.decks.values()].sort((a, b) => a.name.localeCompare(b.name)).map((d) => `<option value="${d.id}" ${d.id === selected ? 'selected' : ''}>${esc(d.name)}</option>`).join('');
}

// ---------- note editor ----------
// opts: { note } to edit, or { did, ntId } to add
export async function openNoteEditor(opts = {}) {
  const col = app.col;
  await ensureBasicNotetypes();
  const editing = !!opts.note;
  let note = opts.note || null;
  let nt = editing ? col.notetypes.get(note.mid) : col.notetypes.get(opts.ntId || app.settings.lastNotetype) || [...col.notetypes.values()].find((n) => !isIoNotetype(n)) || [...col.notetypes.values()][0];
  if (editing && isIoNotetype(nt)) return openIOEditor({ note });
  let did = editing ? (col.cardsOfNote(note.id)[0] || {}).did || 1 : opts.did || app.settings.lastDeck || ([...col.decks.values()].find((d) => d.id !== 1) || { id: 1 }).id;
  if (editing) await ensureMedia([...(note.flds.join(' ').matchAll(/src=["']?([^"'>\s]+)/gi))].map((m) => { try { return decodeURIComponent(m[1]); } catch { return m[1]; } }));

  const ntOptions = () => [...col.notetypes.values()].filter((n) => !isIoNotetype(n)).map((n) => `<option value="${n.id}" ${n.id === nt.id ? 'selected' : ''}>${esc(n.name)}</option>`).join('');
  const fieldsHtml = () => nt.flds.map((f, i) => `
    <div class="field">
      <div class="label" id="fl${i}">${esc(f)}</div>
      <div class="rich" contenteditable="true" role="textbox" aria-multiline="true" aria-labelledby="fl${i}" data-f="${i}">${toEditorHtml(editing ? note.flds[i] : '')}</div>
    </div>`).join('');

  const sheet = openSheet({
    title: editing ? 'Edit note' : 'Add',
    fullscreen: true,
    body: `
      <form data-form autocomplete="off" novalidate>
        ${editing ? '' : `<div class="grid2"><div class="field"><label for="ntSel">Type</label><select class="input" id="ntSel">${ntOptions()}</select></div>
          <div class="field"><label for="deckSel">Deck</label><select class="input" id="deckSel">${deckOptions(did)}</select></div></div>`}
        ${editing ? `<div class="field"><label for="deckSel">Deck</label><select class="input" id="deckSel">${deckOptions(did)}</select></div>` : ''}
        ${!editing && addon('occlusion') ? `<button type="button" class="btn secondary block" data-e="io" style="margin-bottom:14px">${icon('image', 18)}Image occlusion from a photo</button>` : ''}
        <div class="field-tools" role="toolbar" aria-label="Formatting" style="margin-bottom:12px">
          <button type="button" data-e="bold" aria-label="Bold"><b>B</b></button>
          <button type="button" data-e="italic" aria-label="Italic"><i>I</i></button>
          <button type="button" data-e="underline" aria-label="Underline"><u>U</u></button>
          <button type="button" data-e="cloze" aria-label="Make cloze">[…] Cloze</button>
          <button type="button" data-e="cloze-same" aria-label="Cloze with the same number">[…] Same #</button>
          <button type="button" data-e="image" aria-label="Insert image">${icon('image', 16)}</button>
        </div>
        <div data-fields>${fieldsHtml()}</div>
        <div class="field"><label for="tagsIn">Tags</label><input class="input" id="tagsIn" type="text" autocapitalize="off" placeholder="space separated" value="${esc(editing ? note.tags.join(' ') : app.settings.lastTags || '')}"></div>
        <div class="row-buttons">
          ${editing ? '<button type="button" class="btn secondary" data-e="delete">Delete note</button>' : ''}
          <button type="submit" class="btn primary">${editing ? 'Save' : 'Add'}</button>
        </div>
        ${editing ? `<h3 class="section-label">Cards</h3><div class="list">${col.cardsOfNote(note.id).map((c) => `<div class="list-row"><span class="grow"><span class="title">${esc(nt.kind === 1 ? 'Cloze ' + (c.ord + 1) : (nt.tmpls[c.ord] || {}).name || 'Card')}</span><br><span class="sub">${c.queue === -1 ? 'Suspended' : c.type === 0 ? 'New' : c.type === 2 ? 'Due ' + (c.dueDay - col.today() <= 0 ? 'today' : 'in ' + fmtIvl(c.dueDay - col.today())) : 'Learning'}</span></span><button type="button" class="btn small secondary" data-e="susp" data-cid="${c.id}">${c.queue === -1 ? 'Unsuspend' : 'Suspend'}</button></div>`).join('')}</div>` : ''}
      </form>`,
    onMount: (body, api) => {
      let lastRange = null;
      let lastField = body.querySelector('.rich');
      body.addEventListener('focusin', (e) => { if (e.target.classList && e.target.classList.contains('rich')) lastField = e.target; });
      document.addEventListener('selectionchange', function onSel() {
        if (!body.isConnected) { document.removeEventListener('selectionchange', onSel); return; }
        const sel = document.getSelection();
        if (sel.rangeCount && body.contains(sel.anchorNode)) lastRange = sel.getRangeAt(0).cloneRange();
      });
      const restore = () => {
        if (lastRange) { const sel = document.getSelection(); sel.removeAllRanges(); sel.addRange(lastRange); }
        else if (lastField) lastField.focus();
      };
      body.addEventListener('paste', (e) => {
        const rich = e.target.closest && e.target.closest('.rich');
        if (!rich) return;
        const files = [...(e.clipboardData.files || [])].filter((f) => f.type.startsWith('image/'));
        e.preventDefault();
        if (files.length) {
          saveImageFile(files[0]).then(({ name }) => insertHtml(`<img src="${mediaUrl(name)}" data-media="${esc(name)}">`));
        } else {
          const text = e.clipboardData.getData('text/plain');
          document.execCommand('insertText', false, text);
        }
      });
      const insertHtml = (html) => { restore(); document.execCommand('insertHTML', false, html); };
      const nextCloze = () => {
        const texts = [...body.querySelectorAll('.rich')].map((r) => r.innerHTML).join(' ');
        const ords = clozeOrdinals(texts);
        return ords.length ? Math.max(...ords) : 0;
      };
      body.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-e]');
        if (!b) return;
        const act = b.dataset.e;
        if (act === 'bold' || act === 'italic' || act === 'underline') { restore(); document.execCommand(act); return; }
        if (act === 'cloze' || act === 'cloze-same') {
          restore();
          const n = act === 'cloze' ? nextCloze() + 1 : Math.max(1, nextCloze());
          const sel = document.getSelection();
          const text = sel.toString();
          document.execCommand('insertText', false, `{{c${n}::${text}}}`);
          if (!text) toast('Type the hidden text between :: and }}');
          return;
        }
        if (act === 'image') {
          const f = await pickFile('image/*');
          if (!f) return;
          const { name } = await saveImageFile(f);
          insertHtml(`<img src="${mediaUrl(name)}" data-media="${esc(name)}">`);
          return;
        }
        if (act === 'io') { api.close(); openIOEditor({ did: Number(body.querySelector('#deckSel').value) }); return; }
        if (act === 'delete') {
          if (await confirmDialog('Delete this note and all of its cards?', { ok: 'Delete', danger: true })) {
            await col.deleteNote(note.id);
            api.close();
            toast('Note deleted');
            app.render();
          }
          return;
        }
        if (act === 'susp') {
          const c = col.cards.get(Number(b.dataset.cid));
          if (c.queue === -1) await col.unsuspend(c); else await col.suspend(c);
          b.textContent = c.queue === -1 ? 'Suspend' : 'Unsuspend';
          toast(c.queue === -1 ? 'Unsuspended' : 'Suspended');
        }
      });
      const ntSel = body.querySelector('#ntSel');
      if (ntSel) ntSel.addEventListener('change', () => {
        const old = [...body.querySelectorAll('.rich')].map((r) => r.innerHTML);
        nt = col.notetypes.get(Number(ntSel.value));
        body.querySelector('[data-fields]').innerHTML = fieldsHtml();
        body.querySelectorAll('.rich').forEach((r, i) => { if (old[i]) r.innerHTML = old[i]; });
      });
      body.querySelector('[data-form]').addEventListener('submit', async (e) => {
        e.preventDefault();
        const flds = [...body.querySelectorAll('.rich')].map((r) => fromEditorHtml(r.innerHTML));
        const tags = body.querySelector('#tagsIn').value.trim().split(/\s+/).filter(Boolean);
        const deckId = Number(body.querySelector('#deckSel').value);
        if (!stripHtml(flds[0]) && !/<img/i.test(flds[0])) { toast(`${nt.flds[0]} is empty`); return; }
        if (nt.kind === 1 && !clozeOrdinals(flds.join(' ')).length) { toast('Add at least one cloze, like {{c1::text}}'); return; }
        if (editing) {
          await col.updateNote(note, flds, tags);
          const cards = col.cardsOfNote(note.id);
          if (cards.some((c) => c.did !== deckId)) await col.moveCards(cards, deckId);
          api.close();
          toast('Saved');
          if (opts.onSaved) await opts.onSaved();
          app.render();
        } else {
          const probe = { flds, tags: [] };
          if (!cardOrdsForNote(probe, nt).length) { toast('This would make no cards'); return; }
          const { cards } = await col.addNote(nt.id, deckId, flds, tags);
          app.settings.lastDeck = deckId; app.settings.lastNotetype = nt.id; app.settings.lastTags = tags.join(' ');
          await db.kvSet('settings', app.settings);
          body.querySelectorAll('.rich').forEach((r) => { r.innerHTML = ''; });
          const first = body.querySelector('.rich');
          if (first) first.focus();
          toast(`Added · ${cards.length} card${cards.length === 1 ? '' : 's'}`);
          app.render();
        }
      });
    },
  });
  return sheet;
}

// ---------- image occlusion editor ----------
export async function openIOEditor(opts = {}) {
  const col = app.col;
  const editing = !!opts.note;
  const note = opts.note || null;
  const nt = editing ? col.notetypes.get(note.mid) : await ensureStockNotetype('Image Occlusion');
  const fidx = (name, d) => { const i = nt.flds.indexOf(name); return i >= 0 ? i : d; };
  let imageName = null;
  let shapes = []; // {ord, left, top, width, height} fractions
  let oi = true;
  let header = '', backExtra = '';
  let did = editing ? (col.cardsOfNote(note.id)[0] || {}).did || 1 : opts.did || app.settings.lastDeck || 1;
  if (editing) {
    const m = (note.flds[fidx('Image', 1)] || '').match(/src=["']?([^"'>\s]+)/i);
    if (m) { try { imageName = decodeURIComponent(m[1]); } catch { imageName = m[1]; } }
    header = note.flds[fidx('Header', 2)] || '';
    backExtra = note.flds[fidx('Back Extra', 3)] || '';
    const parsed = parseOcclusions(note.flds[fidx('Occlusion', 0)]);
    shapes = parsed.filter((s) => s.kind === 'rect').map((s) => ({ ord: s.ords[0], left: +s.props.left, top: +s.props.top, width: +s.props.width, height: +s.props.height }));
    oi = parsed.length ? parsed.every((s) => s.props.oi === '1') : true;
    if (imageName) await ensureMedia([imageName]);
    // pixel coordinates from older Anki versions: convert once the image loads
  }
  let selected = -1;

  const sheet = openSheet({
    title: editing ? 'Edit occlusions' : 'Image occlusion',
    fullscreen: true,
    body: `
      <div data-pick ${imageName ? 'hidden' : ''}>
        <div class="empty"><h2>Pick a slide or diagram</h2><p>Take a photo or choose one from your library, then drag boxes over the labels you want to hide.</p>
        <button type="button" class="btn primary" data-io="pick">${icon('image', 18)}Choose image</button></div>
      </div>
      <div data-editor ${imageName ? '' : 'hidden'}>
        <p class="hint-line" style="margin-bottom:8px">Drag to draw a box. Tap a box to select it.</p>
        <div class="io-wrap"><div class="io-stage" data-stage><img alt="Image to occlude" data-img draggable="false"></div></div>
        <div class="row-buttons" style="margin-top:10px;justify-content:flex-start">
          <button type="button" class="btn small secondary" data-io="delete" disabled>Delete box</button>
          <button type="button" class="btn small secondary" data-io="undo">Undo last box</button>
          <button type="button" class="btn small secondary" data-io="pick">Change image</button>
        </div>
        <div class="field" style="margin-top:14px"><div class="label">What to hide while you answer</div>
          <div class="seg" style="--n:2" role="group" aria-label="Occlusion mode">
            <button type="button" data-io="oi1" aria-pressed="${oi}">Hide all, guess one</button>
            <button type="button" data-io="oi0" aria-pressed="${!oi}">Hide one, guess one</button>
          </div></div>
        <div class="field"><label for="ioHeader">Header</label><input class="input" id="ioHeader" value="${esc(stripHtml(header))}" placeholder="e.g. Simple vs stratified epithelium"></div>
        <div class="field"><label for="ioExtra">Back extra</label><input class="input" id="ioExtra" value="${esc(stripHtml(backExtra))}" placeholder="Shown on the answer side"></div>
        <div class="grid2">
          <div class="field"><label for="ioDeck">Deck</label><select class="input" id="ioDeck">${deckOptions(did)}</select></div>
          <div class="field"><label for="ioTags">Tags</label><input class="input" id="ioTags" autocapitalize="off" value="${esc(editing ? note.tags.join(' ') : app.settings.lastTags || '')}"></div>
        </div>
        <div class="row-buttons"><button type="button" class="btn primary" data-io="save">${editing ? 'Save' : 'Add cards'}</button></div>
      </div>`,
    onMount: (body, api) => {
      const stage = body.querySelector('[data-stage]');
      const img = body.querySelector('[data-img]');
      const delBtn = body.querySelector('[data-io="delete"]');
      const draw = () => {
        stage.querySelectorAll('.io-box').forEach((b) => b.remove());
        shapes.forEach((s, i) => {
          const b = document.createElement('div');
          b.className = 'io-box' + (i === selected ? ' sel' : '');
          b.style.left = s.left * 100 + '%'; b.style.top = s.top * 100 + '%';
          b.style.width = s.width * 100 + '%'; b.style.height = s.height * 100 + '%';
          b.textContent = String(s.ord);
          b.dataset.i = String(i);
          stage.appendChild(b);
        });
        delBtn.disabled = selected < 0;
      };
      const showImage = () => {
        if (!imageName) return;
        img.src = mediaUrl(imageName);
        body.querySelector('[data-pick]').hidden = true;
        body.querySelector('[data-editor]').hidden = false;
      };
      img.addEventListener('load', () => {
        // convert absolute pixel shapes (older Anki) to fractions
        if (shapes.some((s) => s.left > 1 || s.top > 1 || s.width > 1 || s.height > 1)) {
          shapes = shapes.map((s) => ({ ...s, left: s.left / img.naturalWidth, top: s.top / img.naturalHeight, width: s.width / img.naturalWidth, height: s.height / img.naturalHeight }));
        }
        draw();
      });
      showImage();
      let start = null, live = null;
      const frac = (e) => { const r = img.getBoundingClientRect(); return [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))]; };
      stage.addEventListener('pointerdown', (e) => {
        const box = e.target.closest('.io-box');
        if (box) { selected = Number(box.dataset.i); draw(); return; }
        e.preventDefault();
        start = frac(e); stage.setPointerCapture(e.pointerId);
        live = document.createElement('div'); live.className = 'io-box'; stage.appendChild(live);
      });
      stage.addEventListener('pointermove', (e) => {
        if (!start) return;
        const p = frac(e);
        const l = Math.min(start[0], p[0]), t = Math.min(start[1], p[1]);
        live.style.left = l * 100 + '%'; live.style.top = t * 100 + '%';
        live.style.width = Math.abs(p[0] - start[0]) * 100 + '%'; live.style.height = Math.abs(p[1] - start[1]) * 100 + '%';
      });
      const finish = (e) => {
        if (!start) return;
        const p = frac(e);
        const w = Math.abs(p[0] - start[0]), h = Math.abs(p[1] - start[1]);
        if (w > 0.015 && h > 0.015) {
          const ord = shapes.length ? Math.max(...shapes.map((s) => s.ord)) + 1 : 1;
          shapes.push({ ord, left: Math.min(start[0], p[0]), top: Math.min(start[1], p[1]), width: w, height: h });
          selected = -1;
        }
        start = null; if (live) live.remove(); live = null;
        draw();
      };
      stage.addEventListener('pointerup', finish);
      stage.addEventListener('pointercancel', () => { start = null; if (live) live.remove(); live = null; });
      body.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-io]');
        if (!b) return;
        const act = b.dataset.io;
        if (act === 'pick') {
          const f = await pickFile('image/*');
          if (!f) return;
          const saved = await saveImageFile(f, 2000);
          imageName = saved.name;
          if (!editing) shapes = [];
          showImage();
        } else if (act === 'delete' && selected >= 0) {
          shapes.splice(selected, 1); selected = -1;
          // renumber so cloze numbers stay 1..n
          shapes.forEach((s, i) => { s.ord = i + 1; });
          draw();
        } else if (act === 'undo') {
          shapes.pop(); selected = -1; draw();
        } else if (act === 'oi1' || act === 'oi0') {
          oi = act === 'oi1';
          body.querySelector('[data-io="oi1"]').setAttribute('aria-pressed', String(oi));
          body.querySelector('[data-io="oi0"]').setAttribute('aria-pressed', String(!oi));
        } else if (act === 'save') {
          if (!imageName) { toast('Pick an image first'); return; }
          if (!shapes.length) { toast('Draw at least one box'); return; }
          const f = (x) => (Math.round(x * 10000) / 10000).toString().replace(/^0\./, '.');
          const occl = shapes.map((s) => `{{c${s.ord}::image-occlusion:rect:left=${f(s.left)}:top=${f(s.top)}:width=${f(s.width)}:height=${f(s.height)}:oi=${oi ? 1 : 0}}}`).join('<br>');
          const flds = new Array(nt.flds.length).fill('');
          flds[fidx('Occlusion', 0)] = occl;
          flds[fidx('Image', 1)] = `<img src="${esc(imageName)}">`;
          flds[fidx('Header', 2)] = esc(body.querySelector('#ioHeader').value.trim());
          flds[fidx('Back Extra', 3)] = esc(body.querySelector('#ioExtra').value.trim());
          if (editing) flds[fidx('Comments', 4)] = note.flds[fidx('Comments', 4)] || '';
          const tags = body.querySelector('#ioTags').value.trim().split(/\s+/).filter(Boolean);
          const deckId = Number(body.querySelector('#ioDeck').value);
          if (editing) {
            await col.updateNote(note, flds, tags);
            const cards = col.cardsOfNote(note.id);
            if (cards.some((c) => c.did !== deckId)) await col.moveCards(cards, deckId);
            toast('Saved');
            if (opts.onSaved) await opts.onSaved();
          } else {
            const { cards } = await col.addNote(nt.id, deckId, flds, tags);
            app.settings.lastDeck = deckId; app.settings.lastTags = tags.join(' ');
            await db.kvSet('settings', app.settings);
            toast(`Added · ${cards.length} card${cards.length === 1 ? '' : 's'}`);
          }
          api.close();
          app.render();
        }
      });
    },
  });
  return sheet;
}

// ---------- deck options ----------
function stepsToText(steps) {
  return (steps || []).map((m) => (m >= 1440 && m % 1440 === 0 ? m / 1440 + 'd' : m >= 60 && m % 60 === 0 ? m / 60 + 'h' : m + 'm')).join(' ');
}
function parseSteps(text) {
  const out = [];
  for (const tok of text.trim().split(/[\s,]+/).filter(Boolean)) {
    const m = tok.match(/^(\d+(?:\.\d+)?)([smhd]?)$/i);
    if (!m) return null;
    const v = Number(m[1]);
    const unit = (m[2] || 'm').toLowerCase();
    out.push(unit === 's' ? v / 60 : unit === 'h' ? v * 60 : unit === 'd' ? v * 1440 : v);
  }
  return out;
}

export function openDeckOptions(did) {
  const col = app.col;
  const deck = col.decks.get(did);
  const c = col.confFor(did);
  const fsrs = col.fsrs;
  openSheet({
    title: deck.name.split('::').pop(),
    body: `<form data-form novalidate>
      <div class="field"><label for="dName">Deck name</label><input class="input" id="dName" value="${esc(deck.name)}"></div>
      <div class="grid2">
        <div class="field"><label for="dNew">New cards / day</label><input class="input" id="dNew" type="number" inputmode="numeric" min="0" value="${c.newPerDay}"></div>
        <div class="field"><label for="dRev">Max reviews / day</label><input class="input" id="dRev" type="number" inputmode="numeric" min="0" value="${c.revPerDay}"></div>
      </div>
      <div class="grid2">
        <div class="field"><label for="dLs">Learning steps</label><input class="input" id="dLs" value="${stepsToText(c.learnSteps)}"></div>
        <div class="field"><label for="dRs">Relearning steps</label><input class="input" id="dRs" value="${stepsToText(c.relearnSteps)}"></div>
      </div>
      <div class="grid2">
        <div class="field"><label for="dGg">Graduating interval (days)</label><input class="input" id="dGg" type="number" min="1" value="${c.gradGood}"></div>
        <div class="field"><label for="dGe">Easy interval (days)</label><input class="input" id="dGe" type="number" min="1" value="${c.gradEasy}"></div>
      </div>
      ${fsrs ? `<div class="field"><label for="dDr">Desired retention</label><input class="input" id="dDr" type="number" step="0.01" min="0.7" max="0.99" value="${Math.round(c.desiredRetention * 100) / 100}"></div>`
        : `<div class="grid2"><div class="field"><label for="dEase">Starting ease</label><input class="input" id="dEase" type="number" step="0.05" min="1.3" value="${Math.round(c.initialEase * 100) / 100}"></div>
           <div class="field"><label for="dEb">Easy bonus</label><input class="input" id="dEb" type="number" step="0.05" min="1" value="${Math.round(c.easyMult * 100) / 100}"></div></div>`}
      <div class="field"><label for="dMax">Maximum interval (days)</label><input class="input" id="dMax" type="number" min="1" value="${c.maxIvl}"></div>
      <p class="kbd">Steps use m, h or d, e.g. "1m 10m 1d". Changing these here gives this deck its own options.</p>
      <div class="row-buttons"><button type="button" class="btn secondary" data-close>Cancel</button><button type="submit" class="btn primary">Save</button></div>
    </form>`,
    onMount: (body, api) => {
      body.querySelector('[data-form]').addEventListener('submit', async (e) => {
        e.preventDefault();
        const v = (id) => body.querySelector('#' + id);
        const ls = parseSteps(v('dLs').value), rs = parseSteps(v('dRs').value);
        if (!ls || !ls.length || rs == null) { toast('Steps look wrong — use e.g. 1m 10m'); return; }
        const patch = {
          newPerDay: Math.max(0, parseInt(v('dNew').value, 10) || 0),
          revPerDay: Math.max(0, parseInt(v('dRev').value, 10) || 0),
          learnSteps: ls, relearnSteps: rs,
          gradGood: Math.max(1, parseInt(v('dGg').value, 10) || 1),
          gradEasy: Math.max(1, parseInt(v('dGe').value, 10) || 4),
          maxIvl: Math.max(1, parseInt(v('dMax').value, 10) || 36500),
        };
        if (fsrs) patch.desiredRetention = Math.min(0.99, Math.max(0.7, Number(v('dDr').value) || 0.9));
        else { patch.initialEase = Math.max(1.3, Number(v('dEase').value) || 2.5); patch.easyMult = Math.max(1, Number(v('dEb').value) || 1.3); }
        try {
          if (v('dName').value.trim() !== deck.name) await col.renameDeck(did, v('dName').value);
          await col.setDeckConf(did, patch);
          api.close();
          toast('Deck options saved');
          app.render();
        } catch (err) { toast(err.message || String(err)); }
      });
    },
  });
}
