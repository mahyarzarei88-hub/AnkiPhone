// IndexedDB persistence. The whole collection is loaded into memory at start;
// every change is written back immediately.

const DB_NAME = 'ankiphone';
const VERSION = 1;
const STORES = ['kv', 'notetypes', 'decks', 'dconfs', 'notes', 'cards', 'revlog', 'media'];

let dbp = null;

export function openDB() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const s of STORES) {
        if (db.objectStoreNames.contains(s)) continue;
        if (s === 'kv') db.createObjectStore(s);
        else if (s === 'media') db.createObjectStore(s, { keyPath: 'name' });
        else db.createObjectStore(s, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('Database is open in another tab.'));
  });
  return dbp;
}

function done(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
  });
}

function all(store) {
  return openDB().then((db) => new Promise((resolve, reject) => {
    const req = db.transaction(store).objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  }));
}

export async function kvGet(key, dflt = null) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction('kv').objectStore('kv').get(key);
    req.onsuccess = () => resolve(req.result === undefined ? dflt : req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function kvSet(key, val) {
  const db = await openDB();
  const tx = db.transaction('kv', 'readwrite');
  tx.objectStore('kv').put(val, key);
  return done(tx);
}

export async function loadCollection() {
  const [notetypes, decks, dconfs, notes, cards, revlog, meta] = await Promise.all([
    all('notetypes'), all('decks'), all('dconfs'), all('notes'), all('cards'), all('revlog'), kvGet('meta', {}),
  ]);
  revlog.sort((a, b) => a.id - b.id);
  const mediaNames = await mediaKeys();
  return {
    meta: meta || {},
    notetypes: new Map(notetypes.map((x) => [x.id, x])),
    decks: new Map(decks.map((x) => [x.id, x])),
    dconfs: new Map(dconfs.map((x) => [x.id, x])),
    notes: new Map(notes.map((x) => [x.id, x])),
    cards: new Map(cards.map((x) => [x.id, x])),
    revlog,
    mediaNames: new Set(mediaNames),
  };
}

async function mediaKeys() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction('media').objectStore('media').getAllKeys();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// changes: { store: [objects] }, deletes: { store: [keys] }
export async function write(changes = {}, deletes = {}) {
  const stores = [...new Set([...Object.keys(changes), ...Object.keys(deletes)])];
  if (!stores.length) return;
  const db = await openDB();
  const tx = db.transaction(stores, 'readwrite');
  for (const s of stores) {
    const os = tx.objectStore(s);
    for (const o of changes[s] || []) os.put(o);
    for (const k of deletes[s] || []) os.delete(k);
  }
  return done(tx);
}

export async function saveMeta(meta) { return kvSet('meta', meta); }

export async function getMedia(name) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db.transaction('media').objectStore('media').get(name);
    req.onsuccess = () => resolve(req.result ? req.result.blob : null);
    req.onerror = () => reject(req.error);
  });
}

export async function putMedia(items) {
  // items: [{name, blob}]
  if (!items.length) return;
  const db = await openDB();
  // write in chunks so huge decks don't build one giant transaction
  for (let i = 0; i < items.length; i += 200) {
    const tx = db.transaction('media', 'readwrite');
    const os = tx.objectStore('media');
    for (const it of items.slice(i, i + 200)) os.put({ name: it.name, blob: it.blob });
    await done(tx);
  }
}

export async function clearAll() {
  const db = await openDB();
  const tx = db.transaction(STORES, 'readwrite');
  for (const s of STORES) tx.objectStore(s).clear();
  return done(tx);
}

export async function estimate() {
  try {
    if (navigator.storage && navigator.storage.estimate) return await navigator.storage.estimate();
  } catch { /* ignore */ }
  return null;
}

export async function requestPersist() {
  try {
    if (navigator.storage && navigator.storage.persist) return await navigator.storage.persist();
  } catch { /* ignore */ }
  return false;
}
