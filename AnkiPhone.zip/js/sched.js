// Anki-compatible scheduling: SM-2 (Anki's default) and FSRS-5.
// Card state follows Anki: type 0 new, 1 learning, 2 review, 3 relearning;
// queue 0 new, 1 intraday learning (dueAt ms), 2 review / 3 day-learning (dueDay), -1 suspended.

import { clamp } from './util.js';

export const FSRS5_DEFAULT = [0.40255, 1.18385, 3.173, 15.69105, 7.1949, 0.5345, 1.4604, 0.0046, 1.54575, 0.1192, 1.01925, 1.9395, 0.11, 0.29605, 2.2698, 0.2315, 2.9898, 0.51655, 0.6621];
const DECAY = -0.5;
const FACTOR = 19 / 81;

// ---------------- FSRS ----------------
export const fsrs = {
  R(t, s) { return Math.pow(1 + FACTOR * t / s, DECAY); },
  interval(s, r) { return (s / FACTOR) * (Math.pow(r, 1 / DECAY) - 1); },
  s0(w, g) { return Math.max(0.1, w[g - 1]); },
  d0(w, g) { return clamp(w[4] - Math.exp(w[5] * (g - 1)) + 1, 1, 10); },
  nextD(w, d, g) {
    const delta = -w[6] * (g - 3);
    const dp = d + delta * (10 - d) / 9;
    return clamp(w[7] * fsrs.d0(w, 4) + (1 - w[7]) * dp, 1, 10);
  },
  recallS(w, d, s, r, g) {
    const hard = g === 2 ? w[15] : 1;
    const easy = g === 4 ? w[16] : 1;
    return s * (1 + Math.exp(w[8]) * (11 - d) * Math.pow(s, -w[9]) * (Math.exp((1 - r) * w[10]) - 1) * hard * easy);
  },
  forgetS(w, d, s, r) {
    const sf = w[11] * Math.pow(d, -w[12]) * (Math.pow(s + 1, w[13]) - 1) * Math.exp((1 - r) * w[14]);
    return Math.min(sf, s);
  },
  shortS(w, s, g) { return s * Math.exp(w[17] * (g - 3 + w[18])); },
};

function paramsFor(conf) {
  return conf.fsrsParams && conf.fsrsParams.length >= 19 ? conf.fsrsParams : FSRS5_DEFAULT;
}

// Memory state after answering with grade g (1..4).
function nextMemory(card, g, ctx, conf) {
  const w = paramsFor(conf);
  let s = card.s, d = card.d;
  if (s == null || d == null) {
    if (card.type === 0 || card.type === 1) return { s: fsrs.s0(w, g), d: fsrs.d0(w, g) };
    // card reviewed under SM-2 before: estimate a memory state from its interval and ease
    s = Math.max(card.ivl || 1, 0.5);
    const ease = (card.factor || 2500) / 1000;
    d = clamp(10 - ((ease - 1.3) / 1.7) * 9, 1, 10);
  }
  const lastDay = card.lastReview ? ctx.dayOf(card.lastReview) : (card.dueDay && card.ivl ? card.dueDay - card.ivl : ctx.today);
  const elapsed = Math.max(0, ctx.today - lastDay);
  if (elapsed < 1 && card.type !== 2) {
    return { s: Math.max(0.1, fsrs.shortS(w, s, g)), d: fsrs.nextD(w, d, g) };
  }
  const r = fsrs.R(Math.max(elapsed, 0), s);
  const ns = g === 1 ? fsrs.forgetS(w, d, s, r) : fsrs.recallS(w, d, s, r, g);
  return { s: Math.max(0.1, ns), d: fsrs.nextD(w, d, g) };
}

// ---------------- helpers ----------------
function fuzzRange(ivl) {
  if (ivl < 2.5) return [ivl, ivl];
  const delta = 1 + 0.15 * Math.max(0, Math.min(ivl, 7) - 2.5) + 0.1 * Math.max(0, Math.min(ivl, 20) - 7) + 0.05 * Math.max(0, ivl - 20);
  return [Math.max(2, Math.round(ivl - delta)), Math.round(ivl + delta)];
}

// choose final interval in days; ctx.preview -> deterministic, no fuzz
function finalIvl(ivl, minIvl, conf, ctx) {
  ivl = clamp(Math.round(ivl), Math.max(1, minIvl), conf.maxIvl || 36500);
  if (ctx.preview || ivl < 3) return ivl;
  let [lo, hi] = fuzzRange(ivl);
  lo = Math.max(lo, minIvl, 1);
  hi = Math.min(Math.max(hi, lo), conf.maxIvl || 36500);
  if (ctx.loadBalance && ctx.dueCounts) {
    // pick the least-busy day in the fuzz window (ties: nearest to the ideal interval)
    let best = ivl, bestScore = Infinity;
    for (let x = lo; x <= hi; x++) {
      const n = ctx.dueCounts.get(ctx.today + x) || 0;
      const score = n + Math.abs(x - ivl) * 0.01;
      if (score < bestScore) { bestScore = score; best = x; }
    }
    return best;
  }
  return lo + Math.floor(ctx.random() * (hi - lo + 1));
}

function stepsMin(steps) { return (steps && steps.length ? steps : [1]).map(Number); }

// Put a card into a learning step `mins` minutes from now.
function toStep(out, mins, ctx) {
  if (mins >= 1440) {
    out.queue = 3; out.dueAt = 0; out.dueDay = ctx.today + Math.round(mins / 1440);
  } else {
    out.queue = 1; out.dueDay = 0; out.dueAt = ctx.now + Math.round(mins * 60000);
  }
  return mins / 1440;
}

function hardDelay(steps, idx) {
  if (idx === 0) {
    if (steps.length > 1) return (steps[0] + steps[1]) / 2;
    return Math.min(steps[0] * 1.5, steps[0] + 1440);
  }
  return steps[idx];
}

// ---------------- main entry ----------------
// Returns { card, ivlDays, revlog } — card is a new object; the input is not changed.
// ctx = { now, today, dayOf(ms), fsrs:bool, preview:bool, random(), loadBalance:bool, dueCounts: Map }
export function schedule(card, ease, conf, ctx) {
  const out = { ...card, reps: card.reps + 1, mod: ctx.now, lastReview: ctx.now };
  const useFsrs = !!ctx.fsrs;
  const retention = conf.desiredRetention || 0.9;
  let mem = null;
  if (useFsrs) {
    mem = nextMemory(card, ease, ctx, conf);
    out.s = mem.s; out.d = mem.d;
  }
  const fsrsIvl = () => fsrs.interval(mem.s, retention);
  const revType = card.type === 0 || card.type === 1 ? 0 : card.type === 2 ? 1 : 2;
  const lastIvl = card.type === 2 || card.type === 3 ? card.ivl : (card.type === 1 && card.queue === 1 ? -Math.round(((card.dueAt || ctx.now) - (card.lastReview || ctx.now)) / 1000) : 0);
  let ivlDays;

  const graduate = (days) => {
    out.type = 2; out.queue = 2; out.left = 0;
    if (card.type === 0 || card.type === 1) out.factor = Math.round((conf.initialEase || 2.5) * 1000);
    out.ivl = days; out.dueDay = ctx.today + days; out.dueAt = 0;
    return days;
  };

  if (card.type === 0 || card.type === 1) {
    const steps = stepsMin(conf.learnSteps);
    const idx = card.type === 0 ? 0 : clamp(steps.length - (card.left || steps.length), 0, steps.length - 1);
    out.type = 1;
    if (ease === 1) {
      out.left = steps.length;
      ivlDays = toStep(out, steps[0], ctx);
    } else if (ease === 2) {
      out.left = card.type === 0 ? steps.length : card.left || steps.length;
      ivlDays = toStep(out, hardDelay(steps, idx), ctx);
    } else if (ease === 3) {
      if (idx + 1 < steps.length) {
        out.left = steps.length - (idx + 1);
        ivlDays = toStep(out, steps[idx + 1], ctx);
      } else {
        const good = useFsrs ? finalIvl(fsrsIvl(), 1, conf, ctx) : finalIvl(conf.gradGood || 1, 1, conf, ctx);
        ivlDays = graduate(good);
      }
    } else {
      const goodGuess = useFsrs ? fsrsIvl() : conf.gradGood || 1;
      const easy = useFsrs ? finalIvl(Math.max(fsrsIvl(), goodGuess + 1), 1, conf, ctx) : finalIvl(conf.gradEasy || 4, 1, conf, ctx);
      ivlDays = graduate(easy);
    }
  } else if (card.type === 2) {
    const factor = card.factor || 2500;
    const delay = Math.max(0, ctx.today - (card.dueDay || ctx.today));
    const ivl = Math.max(1, card.ivl || 1);
    const mult = conf.ivlMult || 1;
    if (ease === 1) {
      out.lapses = card.lapses + 1;
      if (!useFsrs) out.factor = Math.max(1300, factor - 200);
      const lapsed = useFsrs ? Math.max(conf.minLapseIvl || 1, Math.round(fsrsIvl())) : Math.max(conf.minLapseIvl || 1, Math.round(ivl * (conf.lapseMult || 0)));
      out.ivl = clamp(lapsed, 1, conf.maxIvl || 36500);
      const rsteps = conf.relearnSteps || [];
      if (rsteps.length) {
        out.type = 3; out.left = rsteps.length;
        ivlDays = toStep(out, rsteps[0], ctx);
      } else {
        out.queue = 2; out.dueDay = ctx.today + out.ivl; out.dueAt = 0;
        ivlDays = out.ivl;
      }
    } else {
      let hardI, goodI, easyI;
      if (useFsrs) {
        // memory states for the other grades, to keep the buttons in order
        const mh = nextMemory(card, 2, ctx, conf), mg = nextMemory(card, 3, ctx, conf), me = nextMemory(card, 4, ctx, conf);
        hardI = Math.max(1, fsrs.interval(mh.s, retention));
        goodI = Math.max(hardI + 1, fsrs.interval(mg.s, retention));
        easyI = Math.max(goodI + 1, fsrs.interval(me.s, retention));
        hardI = Math.min(hardI, goodI); // hard never above good
      } else {
        const hardMult = conf.hardMult || 1.2;
        hardI = Math.max(ivl + 1, ivl * hardMult * mult);
        if (hardMult <= 1) hardI = ivl * hardMult * mult;
        goodI = Math.max(hardI + 1, (ivl + delay / 2) * factor / 1000 * mult);
        easyI = Math.max(goodI + 1, (ivl + delay) * factor / 1000 * (conf.easyMult || 1.3) * mult);
      }
      let target = ease === 2 ? hardI : ease === 3 ? goodI : easyI;
      const floor = ease === 2 ? 1 : ease === 3 ? Math.round(hardI) + 1 : Math.round(goodI) + 1;
      const minIvl = Math.min(Math.round(target), floor);
      const days = finalIvl(target, minIvl, conf, ctx);
      if (!useFsrs) {
        if (ease === 2) out.factor = Math.max(1300, factor - 150);
        if (ease === 4) out.factor = factor + 150;
      }
      out.type = 2; out.queue = 2; out.ivl = days; out.dueDay = ctx.today + days; out.dueAt = 0; out.left = 0;
      ivlDays = days;
    }
  } else {
    // relearning
    const steps = stepsMin(conf.relearnSteps && conf.relearnSteps.length ? conf.relearnSteps : [10]);
    const idx = clamp(steps.length - (card.left || steps.length), 0, steps.length - 1);
    if (ease === 1) {
      out.left = steps.length;
      ivlDays = toStep(out, steps[0], ctx);
    } else if (ease === 2) {
      ivlDays = toStep(out, hardDelay(steps, idx), ctx);
    } else if (ease === 3 && idx + 1 < steps.length) {
      out.left = steps.length - (idx + 1);
      ivlDays = toStep(out, steps[idx + 1], ctx);
    } else {
      let days = Math.max(1, card.ivl || 1);
      if (useFsrs) days = Math.max(1, Math.round(fsrsIvl()));
      if (ease === 4) days += 1;
      days = finalIvl(days, 1, conf, ctx);
      out.type = 2; out.queue = 2; out.ivl = days; out.dueDay = ctx.today + days; out.dueAt = 0; out.left = 0;
      ivlDays = days;
    }
  }

  if (out.queue !== 0) out.pos = card.pos;
  const revIvl = out.queue === 1 ? -Math.round((out.dueAt - ctx.now) / 1000) : out.queue === 3 ? out.dueDay - ctx.today : out.ivl;
  const revlog = {
    id: ctx.now, cid: card.id, ease, ivl: revIvl, lastIvl,
    factor: out.factor || 0, time: Math.min(60000, Math.round(ctx.timeTaken || 0)), type: revType,
  };
  return { card: out, ivlDays, revlog };
}

// Interval labels for the four buttons.
export function previewIntervals(card, conf, ctx) {
  const p = { ...ctx, preview: true };
  return [1, 2, 3, 4].map((e) => schedule(card, e, conf, p).ivlDays);
}

// Forget: reset to new.
export function resetCard(card, pos, now) {
  return { ...card, type: 0, queue: 0, pos, dueAt: 0, dueDay: 0, ivl: 0, factor: 0, reps: 0, lapses: 0, left: 0, s: null, d: null, mod: now };
}
