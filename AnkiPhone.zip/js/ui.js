// Small UI helpers: sheets, toasts, confirm dialogs, haptics, sounds, icons.

import { esc } from './util.js';

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

// ---------- icons (stroke SVG) ----------
const P = {
  today: '<circle cx="12" cy="12" r="8"></circle><circle cx="12" cy="12" r="3"></circle>',
  decks: '<rect x="4" y="5" width="16" height="5" rx="1.5"></rect><rect x="4" y="14" width="16" height="5" rx="1.5"></rect>',
  browse: '<circle cx="11" cy="11" r="6.5"></circle><path d="M16 16l4 4"></path>',
  stats: '<path d="M5 20V10"></path><path d="M12 20V4"></path><path d="M19 20v-7"></path>',
  settings: '<circle cx="12" cy="12" r="3"></circle><path d="M12 2.5v3M12 18.5v3M4.2 6.5l2.6 1.5M17.2 16l2.6 1.5M4.2 17.5l2.6-1.5M17.2 8l2.6-1.5"></path>',
  plus: '<path d="M12 5v14"></path><path d="M5 12h14"></path>',
  import: '<path d="M12 4v11"></path><path d="M7 10l5 5 5-5"></path><path d="M5 20h14"></path>',
  upload: '<path d="M12 20V9"></path><path d="M7 14l5-5 5 5"></path><path d="M5 4h14"></path>',
  close: '<path d="M6 6l12 12"></path><path d="M18 6L6 18"></path>',
  undo: '<path d="M9 14L4 9l5-5"></path><path d="M4 9h10a6 6 0 0 1 0 12h-3"></path>',
  flag: '<path d="M5 21V4"></path><path d="M5 4h12l-2 4 2 4H5"></path>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16v4z"></path>',
  more: '<circle cx="5" cy="12" r="1.2"></circle><circle cx="12" cy="12" r="1.2"></circle><circle cx="19" cy="12" r="1.2"></circle>',
  pen: '<path d="M3 17c3-6 5-6 6-3s2 4 4-1 4-6 6-3"></path><path d="M4 21h16"></path>',
  timer: '<circle cx="12" cy="13" r="8"></circle><path d="M12 9v4l2.5 2"></path><path d="M9 2h6"></path>',
  chevron: '<path d="M9 6l6 6-6 6"></path>',
  chevronDown: '<path d="M6 9l6 6 6-6"></path>',
  back: '<path d="M15 5l-7 7 7 7"></path>',
  calendar: '<rect x="4" y="5" width="16" height="15" rx="2"></rect><path d="M4 10h16"></path><path d="M9 3v4"></path><path d="M15 3v4"></path>',
  sync: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8"></path><path d="M4 4v4h4"></path><path d="M4 13a8 8 0 0 0 14.3 4.9L20 16"></path><path d="M20 20v-4h-4"></path>',
  trash: '<path d="M4 7h16"></path><path d="M9 7V4h6v3"></path><path d="M6 7l1 13h10l1-13"></path>',
  play: '<path d="M7 5l12 7-12 7z"></path>',
  pause: '<path d="M8 5v14"></path><path d="M16 5v14"></path>',
  skip: '<path d="M5 5l9 7-9 7z"></path><path d="M18 5v14"></path>',
  reset: '<path d="M4 12a8 8 0 1 0 2.3-5.7L4 8.5"></path><path d="M4 4v4.5h4.5"></path>',
  image: '<rect x="3" y="5" width="18" height="14" rx="2"></rect><circle cx="9" cy="10" r="2"></circle><path d="M21 16l-5-5-8 8"></path>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"></path>',
  eraser: '<path d="M8 20h12"></path><path d="M5 15l8-8 5 5-6 6H8z"></path>',
  cloud: '<path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"></path>',
};
export function icon(name, size = 22, cls = '') {
  return `<svg class="ic ${cls}" aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${P[name] || ''}</svg>`;
}

// ---------- toast ----------
let toastTimer = null;
export function toast(msg, ms = 2600) {
  let el = $('#toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), ms);
}

// ---------- sheets ----------
const sheetStack = [];
// opts: {title, body (html), onMount(el), wide, fullscreen, onClose}
export function openSheet(opts) {
  const wrap = document.createElement('div');
  wrap.className = 'sheet-wrap' + (opts.fullscreen ? ' full' : '');
  wrap.innerHTML = `
    <div class="sheet-backdrop" data-close></div>
    <section class="sheet" role="dialog" aria-modal="true" aria-label="${esc(opts.title || '')}">
      ${opts.title != null ? `<header class="sheet-head"><h2>${esc(opts.title)}</h2><button type="button" class="icon-btn" data-close aria-label="Close">${icon('close', 20)}</button></header>` : ''}
      <div class="sheet-body">${opts.body || ''}</div>
    </section>`;
  document.body.appendChild(wrap);
  const api = {
    el: wrap,
    body: wrap.querySelector('.sheet-body'),
    close: () => {
      if (!wrap.isConnected) return;
      wrap.classList.remove('open');
      const i = sheetStack.indexOf(api);
      if (i >= 0) sheetStack.splice(i, 1);
      setTimeout(() => wrap.remove(), 220);
      if (opts.onClose) opts.onClose();
    },
  };
  wrap.addEventListener('click', (e) => {
    if (e.target.closest('[data-close]')) { e.preventDefault(); api.close(); }
  });
  sheetStack.push(api);
  requestAnimationFrame(() => wrap.classList.add('open'));
  if (opts.onMount) opts.onMount(api.body, api);
  return api;
}
export function closeTopSheet() {
  const s = sheetStack[sheetStack.length - 1];
  if (s) { s.close(); return true; }
  return false;
}

export function confirmDialog(message, { ok = 'OK', cancel = 'Cancel', danger = false, title = '' } = {}) {
  return new Promise((resolve) => {
    let answered = false;
    const s = openSheet({
      title: title || null,
      body: `<p class="dialog-msg">${message}</p>
        <div class="row-buttons">
          <button type="button" class="btn secondary" data-ans="0">${esc(cancel)}</button>
          <button type="button" class="btn ${danger ? 'danger' : 'primary'}" data-ans="1">${esc(ok)}</button>
        </div>`,
      onClose: () => { if (!answered) resolve(false); },
      onMount: (body) => body.addEventListener('click', (e) => {
        const b = e.target.closest('[data-ans]');
        if (!b) return;
        answered = true;
        resolve(b.dataset.ans === '1');
        s.close();
      }),
    });
  });
}

export function promptDialog(message, value = '', { ok = 'Save', placeholder = '' } = {}) {
  return new Promise((resolve) => {
    let answered = false;
    const s = openSheet({
      title: message,
      body: `<form class="prompt-form"><input class="input" type="text" value="${esc(value)}" placeholder="${esc(placeholder)}" aria-label="${esc(message)}">
        <div class="row-buttons"><button type="button" class="btn secondary" data-close>Cancel</button><button class="btn primary" type="submit">${esc(ok)}</button></div></form>`,
      onClose: () => { if (!answered) resolve(null); },
      onMount: (body) => {
        const input = body.querySelector('input');
        setTimeout(() => input.focus(), 50);
        body.querySelector('form').addEventListener('submit', (e) => {
          e.preventDefault();
          answered = true;
          resolve(input.value);
          s.close();
        });
      },
    });
  });
}

// Action list sheet: items [{label, action, danger}]
export function actionSheet(title, items) {
  return new Promise((resolve) => {
    let answered = false;
    const s = openSheet({
      title,
      body: `<div class="action-list">${items.map((it, i) => `<button type="button" class="action-item ${it.danger ? 'danger' : ''}" data-i="${i}">${it.icon ? icon(it.icon, 20) : ''}<span>${esc(it.label)}</span></button>`).join('')}</div>`,
      onClose: () => { if (!answered) resolve(null); },
      onMount: (body) => body.addEventListener('click', (e) => {
        const b = e.target.closest('[data-i]');
        if (!b) return;
        answered = true;
        resolve(items[+b.dataset.i].action);
        s.close();
      }),
    });
  });
}

// ---------- haptics ----------
// iOS Safari has no Vibration API; toggling a native switch control gives a light tap on iOS 18+.
let hapticLabel = null;
export function haptic(enabled) {
  if (!enabled) return;
  try {
    if (navigator.vibrate) { navigator.vibrate(10); return; }
    if (!hapticLabel) {
      hapticLabel = document.createElement('label');
      hapticLabel.setAttribute('aria-hidden', 'true');
      hapticLabel.style.cssText = 'position:fixed;left:-100px;top:-100px;opacity:0;pointer-events:none';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.setAttribute('switch', '');
      input.tabIndex = -1;
      hapticLabel.appendChild(input);
      document.body.appendChild(hapticLabel);
    }
    hapticLabel.click();
  } catch { /* ignore */ }
}

// ---------- sounds ----------
let audioCtx = null;
export function unlockAudio() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
  } catch { /* ignore */ }
}
export function beep(kind = 'tap') {
  try {
    unlockAudio();
    if (!audioCtx) return;
    const t = audioCtx.currentTime;
    const notes = kind === 'chime' ? [[880, 0], [1175, 0.18], [1568, 0.36]] : kind === 'again' ? [[330, 0]] : [[660, 0]];
    for (const [f, dt] of notes) {
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      const dur = kind === 'chime' ? 0.5 : 0.07;
      g.gain.setValueAtTime(0.0001, t + dt);
      g.gain.exponentialRampToValueAtTime(kind === 'chime' ? 0.25 : 0.08, t + dt + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dt + dur);
      o.connect(g).connect(audioCtx.destination);
      o.start(t + dt);
      o.stop(t + dt + dur + 0.05);
    }
  } catch { /* ignore */ }
}

// ---------- files ----------
export function pickFile(accept) {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    if (accept) input.accept = accept;
    input.style.display = 'none';
    input.addEventListener('change', () => { resolve(input.files[0] || null); input.remove(); });
    document.body.appendChild(input);
    input.click();
  });
}

// Share a file (iOS share sheet: Save to Files / AirDrop), or download it.
export async function shareFile(blob, filename, title) {
  const file = new File([blob], filename, { type: blob.type || 'application/octet-stream' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title });
      return 'shared';
    } catch (e) {
      if (e && e.name === 'AbortError') return 'cancelled';
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return 'downloaded';
}

export function timeAgo(ms) {
  if (!ms) return 'never';
  const s = Math.round((Date.now() - ms) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return Math.round(s / 60) + ' min ago';
  if (s < 86400) return Math.round(s / 3600) + ' h ago';
  return Math.round(s / 86400) + ' days ago';
}
