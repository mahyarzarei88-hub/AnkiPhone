// Importing .apkg files, exporting, backups and the desktop hand-off.

import * as db from './db.js';
import { readPackage, writePackage } from './apkg.js';
import { app, getLibs, saveSettings, forgetMediaUrl } from './state.js';
import { openSheet, toast, shareFile, pickFile, confirmDialog, icon } from './ui.js';
import { esc } from './util.js';

const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', mp3: 'audio/mpeg', m4a: 'audio/mp4', ogg: 'audio/ogg', wav: 'audio/wav', mp4: 'video/mp4', webm: 'video/webm', ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff', woff2: 'font/woff2', css: 'text/css' };
export function mimeFor(name) { return MIME[(name.split('.').pop() || '').toLowerCase()] || 'application/octet-stream'; }

function progressSheet(title) {
  const s = openSheet({ title, body: '<div class="field"><p class="dialog-msg" data-msg>Reading file…</p></div><div class="progress-line"><div data-bar></div></div>' });
  return {
    set(msg, frac) {
      const m = s.body.querySelector('[data-msg]'); if (m) m.textContent = msg;
      const b = s.body.querySelector('[data-bar]'); if (b && frac != null) b.style.width = Math.round(frac * 100) + '%';
    },
    close: () => s.close(),
  };
}

export async function importFlow({ fromDesktop = false, replace = false } = {}) {
  if (fromDesktop && app.col.unsentCount() > 0) {
    const send = await confirmDialog(`You have <b>${app.col.unsentCount()}</b> reviews on this phone that desktop Anki hasn't received yet. Send them first so nothing is lost?`, { ok: 'Send first', cancel: 'Get anyway' });
    if (send) { await sendToDesktop(); return; }
  }
  // no accept filter: iOS greys out .apkg files when an extension list is given
  const file = await pickFile(null);
  if (!file) return;
  await importFile(file, { fromDesktop, replace });
}

export async function importFile(file, { fromDesktop = false, replace = false } = {}) {
  if (/\.json$/i.test(file.name)) {
    toast('That is a progress file for desktop Anki. Open it there with the AnkiPhone add-on.', 4000);
    return;
  }
  const p = progressSheet(fromDesktop ? 'Getting from desktop' : 'Importing');
  try {
    p.set('Loading tools…', 0.05);
    const libs = await getLibs();
    p.set('Reading ' + file.name + '…', 0.15);
    const buf = await file.arrayBuffer();
    const pkg = await readPackage(buf, libs);
    if (replace) {
      p.set('Clearing old collection…', 0.3);
      const settings = app.settings;
      await db.clearAll();
      await db.kvSet('settings', settings);
      for (const k of ['notetypes', 'decks', 'dconfs', 'notes', 'cards']) app.col[k].clear();
      app.col.revlog.length = 0;
      app.col.meta = {};
      app.col.undoStack = [];
      if (!app.col.decks.has(1)) app.col.decks.set(1, { id: 1, name: 'Default', confId: 1 });
    }
    p.set(`Saving ${pkg.media.length} media files…`, 0.4);
    const items = pkg.media.map((m) => ({ name: m.name, blob: new Blob([m.data], { type: mimeFor(m.name) }) }));
    await db.putMedia(items);
    pkg.media.forEach((m) => { app.col.mediaNames.add(m.name); forgetMediaUrl(m.name); });
    p.set(`Merging ${pkg.cards.length} cards…`, 0.6);
    const sum = await app.col.merge(pkg, { onProgress: (f) => p.set(`Merging cards… ${Math.round(f * 100)}%`, 0.6 + f * 0.35) });
    if (fromDesktop) { app.settings.lastReceived = Date.now(); await saveSettings(); }
    await db.requestPersist();
    p.close();
    const lines = [];
    if (sum.cardsAdded) lines.push(`${sum.cardsAdded} new cards`);
    if (sum.cardsUpdated) lines.push(`${sum.cardsUpdated} cards updated`);
    if (sum.notesUpdated) lines.push(`${sum.notesUpdated} notes edited`);
    if (sum.revlogAdded) lines.push(`${sum.revlogAdded} reviews of history`);
    if (pkg.media.length) lines.push(`${pkg.media.length} images and sounds`);
    let msg = lines.length ? lines.join(' · ') : 'Everything was already up to date.';
    if (sum.conflicts) msg += ` · ${sum.conflicts} cards were changed on both devices; the newer change was kept.`;
    openSheet({ title: fromDesktop ? 'Up to date with desktop' : 'Import finished', body: `<p class="dialog-msg">${esc(msg)}</p><div class="row-buttons"><button type="button" class="btn primary" data-close>Done</button></div>` });
    app.render();
  } catch (e) {
    p.close();
    console.error(e);
    openSheet({ title: 'Could not import', body: `<p class="dialog-msg">${esc(e.message || String(e))}</p><p class="dialog-msg muted">Make sure it's an .apkg or .colpkg file exported from Anki.</p><div class="row-buttons"><button type="button" class="btn primary" data-close>OK</button></div>` });
  }
}

async function getMediaBytes(name) {
  const blob = await db.getMedia(name);
  return blob ? new Uint8Array(await blob.arrayBuffer()) : null;
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}

export async function exportDeck(did = null) {
  const p = progressSheet('Exporting');
  try {
    p.set('Loading tools…', 0.1);
    const libs = await getLibs();
    p.set('Packing cards and media…', 0.4);
    const deckIds = did == null ? null : app.col.deckFamily(did);
    const bytes = await writePackage(app.col, libs, { deckIds, getMedia: getMediaBytes });
    p.close();
    const name = did == null ? 'All decks' : app.col.decks.get(did).name.replace(/::/g, ' - ');
    const res = await shareFile(new Blob([bytes], { type: 'application/octet-stream' }), `${name.replace(/[\\/:*?"<>|]/g, '_')}.apkg`, name);
    if (res !== 'cancelled') toast('Exported with your progress');
  } catch (e) {
    p.close();
    toast('Export failed: ' + (e.message || e), 4000);
  }
}

export async function backupNow() {
  const p = progressSheet('Backing up');
  try {
    const libs = await getLibs();
    p.set('Packing your whole collection…', 0.4);
    const bytes = await writePackage(app.col, libs, { getMedia: getMediaBytes });
    p.close();
    const res = await shareFile(new Blob([bytes], { type: 'application/octet-stream' }), `AnkiPhone-backup-${stamp()}.apkg`, 'AnkiPhone backup');
    if (res !== 'cancelled') {
      app.settings.lastBackup = Date.now();
      await saveSettings();
      toast('Backup saved. Pick iCloud Drive in "Save to Files" to keep it off the phone.', 4000);
      app.render();
    }
  } catch (e) {
    p.close();
    toast('Backup failed: ' + (e.message || e), 4000);
  }
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] || '');
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

export async function sendToDesktop() {
  const prog = app.col.buildProgress();
  if (!prog.cards.length && !prog.notes.length && !prog.revlog.length && !prog.deletedNotes.length) {
    toast('Nothing new to send — desktop already has everything.');
    return;
  }
  // media used by notes made on the phone
  const names = app.col.mediaReferencedBy(prog.notes.filter((n) => n.isNew || n.mod > (app.col.meta.lastSent || 0)));
  for (const name of names) {
    const blob = await db.getMedia(name);
    if (blob) prog.media.push({ name, data: await blobToBase64(blob) });
  }
  const json = JSON.stringify(prog);
  const fname = `AnkiPhone-progress-${stamp()}.json`;
  const res = await shareFile(new Blob([json], { type: 'application/json' }), fname, 'Progress for desktop Anki');
  if (res === 'cancelled') return;
  await app.col.markSent(prog);
  openSheet({
    title: 'Sent to desktop',
    body: `<p class="dialog-msg">${prog.revlog.length} reviews and ${prog.notes.length} edited or new notes are in <b>${esc(fname)}</b>.</p>
      <p class="dialog-msg muted">Save it in your <b>AnkiPhone</b> folder in iCloud Drive (or AirDrop it to your Mac). Desktop Anki applies it the next time it opens, then syncs to AnkiWeb as usual.</p>
      <div class="row-buttons"><button type="button" class="btn primary" data-close>Done</button></div>`,
  });
  app.render();
}

export function desktopHelp() {
  openSheet({
    title: 'Use with desktop Anki',
    body: `
      <p class="dialog-msg">Desktop Anki stays your main app and keeps syncing with AnkiWeb. This phone app swaps files with it through a folder in iCloud Drive.</p>
      <h3 class="section-label">One-time setup</h3>
      <ol class="steps">
        <li>On your computer, install the <b>AnkiPhone Companion</b> add-on: in Anki, Tools → Add-ons → Install from file, and pick <code class="path">ankiphone_companion.ankiaddon</code>.</li>
        <li>Restart Anki. It creates an <b>AnkiPhone</b> folder in iCloud Drive and saves your collection there whenever you close Anki.</li>
        <li>On Windows, install iCloud for Windows so iCloud Drive appears in File Explorer.</li>
      </ol>
      <h3 class="section-label">Each time</h3>
      <ol class="steps">
        <li><b>Desktop → phone:</b> close Anki on your computer, then here tap <b>Get from desktop</b> and pick <code class="path">AnkiPhone-desktop.apkg</code> in the AnkiPhone folder.</li>
        <li><b>Phone → desktop:</b> tap <b>Send to desktop</b>, choose <b>Save to Files</b>, and save into the AnkiPhone folder. Desktop Anki picks it up the next time it opens.</li>
        <li>Study on one device at a time between hand-offs. If a card changed on both, the newer change wins.</li>
      </ol>
      <div class="row-buttons"><button type="button" class="btn primary" data-close>Got it</button></div>`,
  });
}

export async function resetEverything() {
  const ok = await confirmDialog('This deletes every deck, card, review and image stored in this app. Back up first if you might want them.', { ok: 'Delete everything', danger: true, title: 'Reset app?' });
  if (!ok) return;
  await db.clearAll();
  location.reload();
}

export { icon };
