// The review screen (Layout B): card, answer buttons, timer pill, gestures,
// scratchpad, speed focus, type-in answers, undo, flags, break screen.

import { app, addon, prepareCardMedia, mountCard } from './state.js';
import { icon, toast, actionSheet, confirmDialog, promptDialog, haptic, beep, unlockAudio, openSheet } from './ui.js';
import { fmtIvl, fmtSecs, esc, stripHtml, dayToISO } from './util.js';
import { compareAnswer, clozeOnly, isIoNotetype } from './render.js';
import { openNoteEditor } from './editor.js';

const FLAGS = [
  { n: 1, name: 'Red', color: '#D83A2E' }, { n: 2, name: 'Orange', color: '#E8871E' }, { n: 3, name: 'Green', color: '#2E9E4F' },
  { n: 4, name: 'Blue', color: '#2F6FD6' }, { n: 5, name: 'Pink', color: '#D6408F' }, { n: 6, name: 'Turquoise', color: '#1FA3A3' }, { n: 7, name: 'Purple', color: '#7B4FD6' },
];
export { FLAGS };

let R = null; // current review state

export function reviewOpen() { return !!R; }

export async function openReview(did = null) {
  if (R) return;
  unlockAudio();
  const col = app.col;
  const session = col.startSession(did);
  const el = document.createElement('div');
  el.className = 'review';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-label', 'Review');
  el.innerHTML = `
    <header class="review-head">
      <button type="button" class="icon-btn" data-r="close" aria-label="End session">${icon('close', 18)}</button>
      <div class="progress">
        <div class="bar" role="progressbar" aria-label="Session progress" aria-valuemin="0" aria-valuemax="100"><div data-bar style="width:0%"></div></div>
        <div class="meta"><span data-counts></span><span data-deck></span></div>
      </div>
      <button type="button" class="pill" data-r="pomo" aria-label="Focus timer">${icon('timer', 16)}<span data-pomo>--:--</span></button>
    </header>
    <div class="speedbar" aria-hidden="true"><div data-speed></div></div>
    <article class="card-frame" data-frame>
      <div class="card-scroll" data-scroll><div id="cardHost"></div></div>
      <canvas class="scratch" data-scratch aria-label="Scratchpad"></canvas>
      <div class="scratch-tools" data-scratch-tools>
        <button type="button" class="icon-btn" data-r="scratch-clear" aria-label="Clear drawing">${icon('eraser', 18)}</button>
        <button type="button" class="icon-btn" data-r="scratch" aria-label="Close scratchpad">${icon('close', 18)}</button>
      </div>
      <div class="swipe-hint left" data-sh="left">Again</div>
      <div class="swipe-hint right" data-sh="right">Good</div>
      <div class="swipe-hint up" data-sh="up">Easy</div>
    </article>
    <div class="tools" role="toolbar" aria-label="Card actions" data-tools>
      <button type="button" class="icon-btn" data-r="undo" aria-label="Undo">${icon('undo', 20)}</button>
      <button type="button" class="icon-btn" data-r="flag" aria-label="Flag card">${icon('flag', 20)}</button>
      <button type="button" class="icon-btn" data-r="edit" aria-label="Edit note">${icon('edit', 20)}</button>
      ${addon('scratch') ? `<button type="button" class="icon-btn" data-r="scratch" aria-label="Scratchpad: draw on the card" aria-pressed="false">${icon('pen', 20)}</button>` : ''}
      <button type="button" class="icon-btn" data-r="more" aria-label="More: suspend, bury, card info">${icon('more', 20)}</button>
    </div>
    <p class="hint-line" data-hintline></p>
    <footer data-footer></footer>`;
  document.body.appendChild(el);
  document.body.style.overflow = 'hidden';
  R = { el, session, did, card: null, note: null, nt: null, side: 'q', shownAt: 0, typed: '', speedTimer: null, speedStart: 0, waitTimer: null, scratchOn: false };
  el.addEventListener('click', onClick);
  setupGestures();
  setupScratch();
  document.addEventListener('keydown', onKey);
  updatePomo();
  if (app.pomo && app.settings.pomo.pauseReviews && app.pomo.onBreak) showBreak();
  await showNext();
}

export function closeReview() {
  if (!R) return;
  clearTimers();
  document.removeEventListener('keydown', onKey);
  R.el.remove();
  R = null;
  document.body.style.overflow = '';
  const br = document.querySelector('.break');
  if (br) br.remove();
  app.render();
}

function clearTimers() {
  if (!R) return;
  clearInterval(R.speedTimer); R.speedTimer = null;
  clearTimeout(R.waitTimer); R.waitTimer = null;
  const sb = R.el.querySelector('[data-speed]');
  if (sb) sb.style.width = '0';
}

function q(sel) { return R.el.querySelector(sel); }

function updateHeader() {
  const rem = app.col.remaining(R.session);
  const left = rem.n + rem.l + rem.r;
  const done = R.session.answered;
  const pct = left + done ? Math.round((done / (left + done)) * 100) : 100;
  q('[data-bar]').style.width = pct + '%';
  q('.bar').setAttribute('aria-valuenow', String(pct));
  q('[data-counts]').innerHTML = `<span class="counts"><span class="c-new">${rem.n}</span><span class="c-learn">${rem.l}</span><span class="c-due">${rem.r}</span></span>`;
  const deck = R.card ? app.col.decks.get(R.card.did) : null;
  q('[data-deck]').textContent = deck ? deck.name.split('::').pop() : '';
}

export function updatePomo() {
  if (!R || !app.pomo) return;
  const p = app.pomo;
  const pill = q('[data-r="pomo"]');
  const label = q('[data-pomo]');
  if (p.s.phase === 'idle' || p.s.phase === 'ready') {
    pill.classList.add('idle');
    label.classList.remove('mono');
    label.textContent = p.s.phase === 'ready' ? `Start ${p.s.block}` : 'Start';
  } else {
    pill.classList.remove('idle');
    label.classList.add('mono');
    if (p.s.phase === 'focus' && p.byCards) label.textContent = `${p.cardsLeft()} left`;
    else label.textContent = (p.s.paused ? '❚❚ ' : '') + fmtSecs(p.remainingMs() / 1000);
  }
}

async function showNext() {
  clearTimers();
  closeScratch();
  const col = app.col;
  const next = col.nextCard(R.session);
  R.card = null;
  if (!next) return showDone();
  if (next.wait) return showWait(next.wait);
  R.card = next;
  R.note = col.notes.get(next.nid);
  R.nt = R.note ? col.notetypes.get(R.note.mid) : null;
  if (!R.note || !R.nt) {
    // orphaned card: skip it this session
    R.session.mixed = R.session.mixed.filter((id) => id !== next.id);
    return showNext();
  }
  await prepareCardMedia(R.note, R.nt);
  showQuestion();
}

function frameReset() {
  const host = q('#cardHost');
  q('[data-scroll]').scrollTop = 0;
  return host;
}

function showQuestion() {
  R.side = 'q';
  R.typed = '';
  const host = frameReset();
  const { root } = mountCard(host, R.note, R.nt, R.card, 'q', { typeBox: addon('typein') && !isIoNotetype(R.nt) });
  R.root = root;
  const input = root.getElementById ? root.getElementById('typeans') : root.querySelector('#typeans');
  if (input) {
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); flip(); } });
  }
  R.shownAt = Date.now();
  updateHeader();
  q('[data-footer]').innerHTML = `<button type="button" class="show-btn" data-r="flip">Show answer</button>`;
  q('[data-hintline]').textContent = addon('gestures') ? 'Tap the card to flip' : '';
  startSpeed('q');
  autoplay(root);
}

function expectedTyped() {
  const nt = R.nt, note = R.note;
  if (nt.kind === 1) {
    for (let i = 0; i < nt.flds.length; i++) {
      const s = clozeOnly(note.flds[i] || '', R.card.ord + 1);
      if (s) return stripHtml(s);
    }
    return '';
  }
  return stripHtml(note.flds[1] ?? '');
}

function flip() {
  if (!R || R.side !== 'q' || !R.card) return;
  const input = R.root && R.root.querySelector('#typeans');
  const typed = input ? input.value : '';
  R.typed = typed;
  R.side = 'a';
  const host = q('#cardHost');
  let typeCompare = '';
  // only when the box was our add-on box (template type: fields compare themselves)
  if (input && input.placeholder === 'Type your answer' && typed.trim()) typeCompare = compareAnswer(expectedTyped(), typed);
  const { root } = mountCard(host, R.note, R.nt, R.card, 'a', { typed, typeCompare });
  R.root = root;
  const answerEl = root.querySelector('#answer');
  if (answerEl) {
    const scroll = q('[data-scroll]');
    const top = answerEl.getBoundingClientRect().top - scroll.getBoundingClientRect().top + scroll.scrollTop - 20;
    if (top > scroll.clientHeight * 0.4) scroll.scrollTop = top;
  }
  const ivls = app.col.intervalsFor(R.card);
  const names = ['Again', 'Hard', 'Good', 'Easy'];
  q('[data-footer]').innerHTML = `<div class="answer-row">${names.map((n, i) => `<button type="button" class="ease e${i + 1}" data-ease="${i + 1}"><b>${n}</b><span>${fmtIvl(ivls[i])}</span></button>`).join('')}</div>`;
  q('[data-hintline]').textContent = addon('gestures') ? 'Swipe ← Again · → Good · ↑ Easy' : '';
  startSpeed('a');
  autoplay(root);
}

function autoplay(root) {
  const first = root.querySelector('.play-sound');
  if (first) { const a = new Audio(first.dataset.src); a.play().catch(() => {}); }
}

async function answer(ease) {
  if (!R || R.side !== 'a' || !R.card || R.busy) return;
  R.busy = true;
  clearTimers();
  const taken = Date.now() - R.shownAt;
  try {
    haptic(addon('haptics'));
    if (addon('haptics')) beep(ease === 1 ? 'again' : 'tap');
    await app.col.answer(R.session, R.card, ease, taken, { loadBalance: addon('balance') });
    if (app.pomo) app.pomo.onAnswer(ease > 1, Math.min(60000, taken));
  } finally {
    R && (R.busy = false);
  }
  if (!R) return;
  if (app.pomo && app.settings.pomo.pauseReviews && app.pomo.onBreak) { showBreak(); return; }
  await showNext();
}

function showDone() {
  const t = app.col.totals();
  updateHeaderEmpty();
  const more = t.n + t.r + t.l;
  const host = q('#cardHost');
  const root = host.shadowRoot || host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>:host{display:block}</style><div style="padding:48px 24px;text-align:center;color:var(--ink)">
    <div style="font-size:44px;line-height:1">✓</div>
    <h2 style="margin:12px 0 6px;font-size:24px">Done for now</h2>
    <p style="margin:0;color:var(--muted)">${R.session.answered} cards in ${Math.round(R.session.timeMs / 60000)} min · ${R.session.answered ? Math.round((R.session.correct / R.session.answered) * 100) : 0}% correct</p>
    ${more && R.did != null ? `<p style="margin:12px 0 0;color:var(--muted)">${more} cards still due in other decks.</p>` : ''}
  </div>`;
  q('[data-footer]').innerHTML = `<button type="button" class="show-btn" data-r="close">Back to Today</button>`;
  q('[data-hintline]').textContent = '';
}

function updateHeaderEmpty() {
  q('[data-bar]').style.width = '100%';
  q('[data-counts]').innerHTML = '<span class="counts"><span class="c-zero">0</span><span class="c-zero">0</span><span class="c-zero">0</span></span>';
}

function showWait(ms) {
  updateHeader();
  const host = q('#cardHost');
  const root = host.shadowRoot || host.attachShadow({ mode: 'open' });
  const mins = Math.max(1, Math.round(ms / 60000));
  root.innerHTML = `<div style="padding:48px 24px;text-align:center;color:var(--ink)">
    <h2 style="margin:0 0 6px;font-size:22px">Learning cards coming up</h2>
    <p style="margin:0;color:var(--muted)">The next one is due in about ${mins} min. Stay here and it will appear, or come back later.</p></div>`;
  q('[data-footer]').innerHTML = `<button type="button" class="show-btn" data-r="close">Back to Today</button>`;
  R.waitTimer = setTimeout(() => { if (R && !R.card) showNext(); }, Math.min(ms + 500, 60000));
}

// ---------- speed focus ----------
function startSpeed(side) {
  if (!addon('speed')) return;
  const secs = side === 'q' ? Number(app.settings.speed.q) || 0 : Number(app.settings.speed.a) || 0;
  if (!secs) return;
  const bar = q('[data-speed]');
  R.speedStart = Date.now();
  R.speedTimer = setInterval(() => {
    if (!R) return;
    const f = (Date.now() - R.speedStart) / (secs * 1000);
    bar.style.width = Math.min(100, f * 100) + '%';
    if (f >= 1) {
      clearTimers();
      if (side === 'q') flip();
      else if (app.settings.speed.action === 'again') { toast('Too slow — marked Again'); answer(1); }
      else { haptic(addon('haptics')); toast('Time is up — pick an answer'); }
    }
  }, 200);
}

// ---------- events ----------
async function onClick(e) {
  const easeBtn = e.target.closest('[data-ease]');
  if (easeBtn) return answer(Number(easeBtn.dataset.ease));
  const b = e.target.closest('[data-r]');
  if (!b) return;
  const act = b.dataset.r;
  if (act === 'close') return closeReview();
  if (act === 'flip') return flip();
  if (act === 'undo') return undo();
  if (act === 'flag') return flagMenu();
  if (act === 'edit') return editNote();
  if (act === 'more') return moreMenu();
  if (act === 'scratch') return toggleScratch();
  if (act === 'scratch-clear') return clearScratch();
  if (act === 'pomo') {
    if (app.pomo) { unlockAudio(); app.pomo.toggle(); updatePomo(); }
  }
}

function onKey(e) {
  if (!R || document.querySelector('.sheet-wrap')) return;
  const tag = (e.target && e.target.tagName) || '';
  if (tag === 'INPUT' || tag === 'TEXTAREA') return;
  if (e.key === 'Escape') { closeReview(); return; }
  if (R.side === 'q' && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); flip(); return; }
  if (R.side === 'a') {
    if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); answer(3); return; }
    if (['1', '2', '3', '4'].includes(e.key)) { answer(Number(e.key)); return; }
  }
  if (e.key === 'u' || (e.key === 'z' && (e.metaKey || e.ctrlKey))) undo();
}

async function undo() {
  const last = app.col.undoStack[app.col.undoStack.length - 1];
  const prev = await app.col.undo(R.session);
  if (!prev) { toast('Nothing to undo'); return; }
  if (last && last.kind === 'answer' && app.pomo) app.pomo.onUndo(last.ease > 1);
  clearTimers();
  R.card = app.col.cards.get(prev.id);
  R.note = app.col.notes.get(R.card.nid);
  R.nt = app.col.notetypes.get(R.note.mid);
  await prepareCardMedia(R.note, R.nt);
  showQuestion();
  toast('Undone');
}

async function flagMenu() {
  if (!R.card) return;
  const items = FLAGS.map((f) => ({ label: (R.card.flags === f.n ? '✓ ' : '') + f.name, action: f.n, icon: 'flag' }));
  items.push({ label: 'No flag', action: 0 });
  const pick = await actionSheet('Flag card', items);
  if (pick == null) return;
  R.card = pick === 0 ? await app.col.updateCard(R.card, { flags: 0 }, false) : await app.col.updateCard(R.card, { flags: pick }, false);
  toast(pick ? `Flagged ${FLAGS[pick - 1].name.toLowerCase()}` : 'Flag removed');
}

async function editNote() {
  if (!R.note) return;
  clearTimers();
  await openNoteEditor({ note: R.note, onSaved: async () => {
    if (!R) return;
    R.note = app.col.notes.get(R.note.id);
    await prepareCardMedia(R.note, R.nt);
    if (R.side === 'q') showQuestion(); else { R.side = 'q'; flip(); }
  } });
}

async function moreMenu() {
  if (!R.card) return;
  const pick = await actionSheet('This card', [
    { label: 'Card info', action: 'info' },
    { label: 'Bury until tomorrow', action: 'bury' },
    { label: 'Suspend card', action: 'suspend' },
    { label: 'Set due date…', action: 'due' },
    { label: 'Forget (reset to new)', action: 'forget' },
    { label: 'Delete note', action: 'delete', danger: true },
  ]);
  if (!pick) return;
  const col = app.col;
  if (pick === 'info') return cardInfo(R.card);
  if (pick === 'bury') { await col.bury(R.card); toast('Buried until tomorrow'); return skipCurrent(); }
  if (pick === 'suspend') { await col.suspend(R.card); toast('Card suspended'); return skipCurrent(); }
  if (pick === 'forget') { await col.forget(R.card); toast('Card reset to new'); return skipCurrent(); }
  if (pick === 'due') {
    const v = await promptDialog('Due in how many days?', '1', { ok: 'Set' });
    const n = parseInt(v, 10);
    if (!isNaN(n) && n >= 0) { await col.setDueDate(R.card, n); toast(n === 0 ? 'Due today' : `Due in ${n} days`); return skipCurrent(); }
    return;
  }
  if (pick === 'delete') {
    if (await confirmDialog('Delete this note and all of its cards?', { ok: 'Delete', danger: true })) {
      await col.deleteNote(R.note.id);
      toast('Note deleted');
      return skipCurrent();
    }
  }
}

async function skipCurrent() {
  if (!R) return;
  R.session.mixed = R.session.mixed.filter((id) => id !== (R.card && R.card.id));
  await showNext();
}

export function cardInfo(card) {
  const col = app.col;
  const deck = col.decks.get(card.did);
  const revs = col.revlog.filter((r) => r.cid === card.id);
  const type = ['New', 'Learning', 'Review', 'Relearning'][card.type] || '';
  const due = card.queue === -1 ? 'Suspended' : card.type === 0 ? `New #${card.pos}` : card.queue === 1 ? new Date(card.dueAt).toLocaleString() : dayToISO(card.dueDay);
  const rows = [
    ['Deck', deck ? deck.name : '—'], ['State', type], ['Due', due], ['Interval', card.ivl ? fmtIvl(card.ivl) : '—'],
    [col.fsrs ? 'Memory' : 'Ease', col.fsrs && card.s != null ? `stability ${card.s.toFixed(1)}d · difficulty ${card.d.toFixed(1)}` : card.factor ? (card.factor / 10).toFixed(0) + '%' : '—'],
    ['Reviews', String(card.reps)], ['Lapses', String(card.lapses)],
  ];
  const hist = revs.slice(-12).reverse().map((r) => `<div class="list-row"><span class="grow">${new Date(r.id).toLocaleDateString()}</span><span class="value" style="color:var(--${['', 'again', 'hard', 'good', 'easy'][r.ease] || 'muted'})">${['', 'Again', 'Hard', 'Good', 'Easy'][r.ease] || r.ease}</span><span class="value">${r.ivl < 0 ? fmtIvl(-r.ivl / 86400) : fmtIvl(r.ivl)}</span></div>`).join('');
  openSheet({
    title: 'Card info',
    body: `<div class="list">${rows.map(([k, v]) => `<div class="list-row"><span class="grow sub">${esc(k)}</span><span class="value">${esc(v)}</span></div>`).join('')}</div>
      ${hist ? `<h3 class="section-label">Recent reviews</h3><div class="list">${hist}</div>` : ''}`,
  });
}

// ---------- gestures ----------
function setupGestures() {
  const frame = q('[data-frame]');
  let sx = 0, sy = 0, tracking = false, moved = false;
  frame.addEventListener('pointerdown', (e) => {
    if (R.scratchOn || e.pointerType === 'mouse' && e.button !== 0) return;
    sx = e.clientX; sy = e.clientY; tracking = true; moved = false;
  });
  frame.addEventListener('pointermove', (e) => {
    if (!tracking || !addon('gestures') || R.side !== 'a') return;
    const dx = e.clientX - sx, dy = e.clientY - sy;
    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
    showSwipeHint(dx, dy);
  });
  const end = (e) => {
    if (!tracking) return;
    tracking = false;
    hideSwipeHints();
    const dx = e.clientX - sx, dy = e.clientY - sy;
    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
    if (R.side === 'a' && addon('gestures')) {
      if (dx < -80 && Math.abs(dx) > Math.abs(dy)) return answer(1);
      if (dx > 80 && Math.abs(dx) > Math.abs(dy)) return answer(3);
      if (dy < -90 && Math.abs(dy) > Math.abs(dx)) return answer(4);
    }
    if (!moved && R.side === 'q' && addon('gestures')) {
      // tap to flip, unless the tap landed on something interactive inside the card
      const path = e.composedPath ? e.composedPath() : [];
      const interactive = path.some((n) => n && n.tagName && /^(A|BUTTON|INPUT|TEXTAREA|SELECT|SUMMARY|DETAILS|AUDIO|VIDEO)$/.test(n.tagName));
      if (!interactive) flip();
    }
  };
  frame.addEventListener('pointerup', end);
  frame.addEventListener('pointercancel', () => { tracking = false; hideSwipeHints(); });
}
function showSwipeHint(dx, dy) {
  const set = (k, v) => { const h = q(`[data-sh="${k}"]`); if (h) h.style.opacity = String(v); };
  const horiz = Math.abs(dx) > Math.abs(dy);
  set('left', horiz && dx < 0 ? Math.min(1, -dx / 80) : 0);
  set('right', horiz && dx > 0 ? Math.min(1, dx / 80) : 0);
  set('up', !horiz && dy < 0 ? Math.min(1, -dy / 90) : 0);
}
function hideSwipeHints() { R && R.el.querySelectorAll('.swipe-hint').forEach((h) => { h.style.opacity = '0'; }); }

// ---------- scratchpad ----------
function setupScratch() {
  const cv = q('[data-scratch]');
  let drawing = false, last = null;
  const pos = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  cv.addEventListener('pointerdown', (e) => { drawing = true; last = pos(e); cv.setPointerCapture(e.pointerId); });
  cv.addEventListener('pointermove', (e) => {
    if (!drawing) return;
    const ctx = cv.getContext('2d');
    const p = pos(e);
    const dpr = window.devicePixelRatio || 1;
    ctx.strokeStyle = document.documentElement.dataset.theme === 'dark' ? '#F08A5D' : '#B04A18';
    ctx.lineWidth = (e.pressure && e.pointerType === 'pen' ? 1.5 + e.pressure * 4 : 3) * dpr;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.moveTo(last[0] * dpr, last[1] * dpr); ctx.lineTo(p[0] * dpr, p[1] * dpr); ctx.stroke();
    last = p;
  });
  const stop = () => { drawing = false; };
  cv.addEventListener('pointerup', stop);
  cv.addEventListener('pointercancel', stop);
}
function toggleScratch() {
  R.scratchOn = !R.scratchOn;
  const cv = q('[data-scratch]');
  if (R.scratchOn) {
    const r = cv.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(r.width * dpr) || 300;
    cv.height = Math.round(r.height * dpr) || 300;
    const fr = q('[data-frame]').getBoundingClientRect();
    if (!r.width) { cv.width = Math.round(fr.width * dpr); cv.height = Math.round(fr.height * dpr); }
  }
  cv.classList.toggle('on', R.scratchOn);
  q('[data-scratch-tools]').classList.toggle('on', R.scratchOn);
  const b = R.el.querySelector('.tools [data-r="scratch"]');
  if (b) b.setAttribute('aria-pressed', String(R.scratchOn));
}
function clearScratch() { const cv = q('[data-scratch]'); cv.getContext('2d').clearRect(0, 0, cv.width, cv.height); }
function closeScratch() { if (R && R.scratchOn) { clearScratch(); toggleScratch(); } }

// ---------- break screen ----------
export function showBreak() {
  let br = document.querySelector('.break');
  if (!br) {
    br = document.createElement('div');
    br.className = 'break';
    br.setAttribute('role', 'dialog');
    br.setAttribute('aria-label', 'Break');
    document.body.appendChild(br);
    br.addEventListener('click', (e) => {
      const b = e.target.closest('[data-b]');
      if (!b) return;
      if (b.dataset.b === 'next') { br.remove(); app.pomo.skip(); if (R) showNext(); }
      if (b.dataset.b === 'start') { br.remove(); app.pomo.startFocus(); if (R) showNext(); }
      if (b.dataset.b === 'end') { br.remove(); if (R) closeReview(); }
      if (b.dataset.b === 'hide') { br.remove(); }
    });
  }
  updateBreak();
}

export function updateBreak() {
  const br = document.querySelector('.break');
  if (!br || !app.pomo) return;
  const p = app.pomo;
  const every = app.settings.pomo.longEvery || 4;
  const doneInCycle = p.s.done % every || (p.s.done ? every : 0);
  const blocks = Array.from({ length: every }, (_, i) => `<span class="${i < doneInCycle ? 'done' : ''}"></span>`).join('');
  const st = p.s.lastStats || { answered: 0, correct: 0, timeMs: 0 };
  const pct = st.answered ? Math.round((st.correct / st.answered) * 100) + '%' : '—';
  const per = st.answered ? Math.round(st.timeMs / st.answered / 1000) + 's' : '—';
  if (p.s.phase === 'break') {
    br.innerHTML = `
      <div class="blocks" style="--n:${every}" aria-label="${doneInCycle} of ${every} blocks done">${blocks}</div>
      <div class="center">
        <span style="font-size:15px;font-weight:600;color:#9AA3B0">${p.s.kind === 'long' ? 'Long break' : 'Break'} · block ${p.s.done} done</span>
        <span class="clock mono">${fmtSecs(p.remainingMs() / 1000)}</span>
        <p style="margin:0;max-width:280px;font-size:16px;line-height:24px;color:#C4CAD3">Stand up, get water, look at something far away. Reviews are paused.</p>
      </div>
      <div class="tiles">
        <div class="tile"><b class="num">${st.answered}</b><span>Cards this block</span></div>
        <div class="tile"><b class="num">${pct}</b><span>Correct</span></div>
        <div class="tile"><b class="num">${per}</b><span>Per card</span></div>
      </div>
      <button type="button" class="primary-light" data-b="next">Start block ${p.s.block} early</button>
      <button type="button" class="ghost" data-b="end">${R ? 'End session' : 'Close'}</button>`;
  } else if (p.s.phase === 'ready') {
    br.innerHTML = `
      <div class="blocks" style="--n:${every}">${blocks}</div>
      <div class="center">
        <span class="clock mono" style="font-size:44px;line-height:52px">Break's over</span>
        <p style="margin:0;font-size:16px;color:#C4CAD3">Ready for block ${p.s.block}?</p>
      </div>
      <button type="button" class="primary-light" data-b="start">Start block ${p.s.block}</button>
      <button type="button" class="ghost" data-b="hide">Not yet</button>`;
  } else {
    br.remove();
  }
}
