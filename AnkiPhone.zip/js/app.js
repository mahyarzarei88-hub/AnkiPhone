// App shell: boot, tabs (Today, Decks, Browse, Stats, Settings), focus timer.

import * as db from './db.js';
import { Collection } from './col.js';
import { app, addon, saveSettings, defaultSettings, applyTheme, ADDONS } from './state.js';
import { Pomodoro, POMO_PRESETS, defaultPomo } from './pomodoro.js';
import { icon, toast, openSheet, actionSheet, confirmDialog, promptDialog, beep, haptic, timeAgo, unlockAudio, closeTopSheet } from './ui.js';
import { openReview, reviewOpen, updatePomo, showBreak, updateBreak, FLAGS } from './review.js';
import { openNoteEditor, openIOEditor, openDeckOptions } from './editor.js';
import { importFlow, importFile, exportDeck, backupNow, sendToDesktop, desktopHelp, resetEverything } from './handoff.js';
import { esc, fmtSecs, dayToISO, isoToDay, stripHtml, fmtIvl, dayIndex } from './util.js';
import { isIoNotetype } from './render.js';

const VERSION = '1.0.0';
const TABS = [
  { id: 'today', label: 'Today', icon: 'today' },
  { id: 'decks', label: 'Decks', icon: 'decks' },
  { id: 'browse', label: 'Browse', icon: 'browse' },
  { id: 'stats', label: 'Stats', icon: 'stats' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
];
const TINTS = [
  ['#F6E7F0', '#8A2A63'], ['#E6F0EC', '#2F6B5E'], ['#ECE9F8', '#5B4BB7'], ['#FCEBE2', '#9A3F12'], ['#E3ECFA', '#1F4F99'], ['#F4EED9', '#6B5310'],
];
const TINTS_DARK = [
  ['#3A2232', '#F0B6D6'], ['#1E332C', '#9ED4C3'], ['#2A2640', '#C5BBF5'], ['#3A2A20', '#F3B999'], ['#1E2A3D', '#A9C4F2'], ['#332D18', '#E8D38E'],
];

const ui = { browseQuery: '', browseLimit: 100, statsRange: 7, timerSheet: null };

// ---------------- boot ----------------
async function boot() {
  const root = document.getElementById('app');
  try {
    await db.openDB();
  } catch (e) {
    root.innerHTML = `<div class="screen"><div class="empty"><h2>Storage is unavailable</h2><p>${esc(e.message || e)}. Private browsing can block storage — open this app normally.</p></div></div>`;
    return;
  }
  const saved = await db.kvGet('settings', null);
  const d = defaultSettings();
  app.settings = saved ? { ...d, ...saved, addons: { ...d.addons, ...(saved.addons || {}) }, pomo: { ...d.pomo, ...(saved.pomo || {}) }, speed: { ...d.speed, ...(saved.speed || {}) } } : d;
  const data = await db.loadCollection();
  app.col = new Collection(data, { persist: db.write, saveMeta: db.saveMeta });
  applyTheme();
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { applyTheme(); render(); });

  app.pomo = new Pomodoro(app.settings.pomo, await db.kvGet('pomoState', null), {
    save: (s) => db.kvSet('pomoState', s),
    onEvent: onPomoEvent,
  });
  if (app.pomo.s.phase === 'focus' || app.pomo.s.phase === 'break') app.pomo.ensureTicking();

  app.render = render;
  root.addEventListener('click', onClick);
  root.addEventListener('input', onInput);
  root.addEventListener('change', onChange);
  root.addEventListener('submit', (e) => e.preventDefault());
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !reviewOpen()) closeTopSheet(); });

  // drag and drop .apkg (handy on iPad / desktop browsers)
  document.addEventListener('dragover', (e) => { e.preventDefault(); });
  document.addEventListener('drop', (e) => {
    e.preventDefault();
    const f = e.dataTransfer && e.dataTransfer.files[0];
    if (f) importFile(f);
  });

  let lastDay = dayIndex();
  setInterval(() => {
    if (dayIndex() !== lastDay) { lastDay = dayIndex(); app.col.unburyIfNewDay(); if (!reviewOpen()) render(); }
  }, 60000);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') { app.pomo.tick(); if (!reviewOpen() && !document.querySelector('.sheet-wrap')) render(); }
  });
  render();
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}

function onPomoEvent(type) {
  if (type === 'break' || type === 'ready') {
    if (app.settings.pomo.chime) beep('chime');
    haptic(addon('haptics'));
    if (type === 'break') {
      if (reviewOpen() && app.settings.pomo.pauseReviews) showBreak();
      else toast(app.pomo.s.kind === 'long' ? 'Long break time' : 'Break time — step away for a few minutes', 4000);
    } else {
      updateBreak();
      if (!document.querySelector('.break')) toast(`Break's over — ready for block ${app.pomo.s.block}`, 4000);
    }
  }
  updatePomo();
  updateBreak();
  updateTimerViews();
  if ((type === 'break' || type === 'ready' || type === 'focus') && !reviewOpen() && !document.querySelector('.sheet-wrap')) render();
}

// ---------------- rendering ----------------
function render() {
  const root = document.getElementById('app');
  let html = '';
  if (app.tab === 'today') html = renderToday();
  else if (app.tab === 'decks') html = renderDecks();
  else if (app.tab === 'browse') html = renderBrowse();
  else if (app.tab === 'stats') html = renderStats();
  else html = renderSettings();
  const scrollY = window.scrollY;
  root.innerHTML = html + `<nav class="tabbar" aria-label="Main">${TABS.map((t) => `<button type="button" data-act="tab" data-tab="${t.id}" ${app.tab === t.id ? 'aria-current="page"' : ''}>${icon(t.icon, 22)}${t.label}</button>`).join('')}</nav>`;
  if (app.tab === ui.lastTab) window.scrollTo(0, scrollY);
  ui.lastTab = app.tab;
  if (app.tab === 'browse') renderBrowseResults();
}

function tint(i) {
  const dark = document.documentElement.dataset.theme === 'dark';
  return (dark ? TINTS_DARK : TINTS)[i % TINTS.length];
}

function plural(n, w) { return `${n} ${w}${n === 1 ? '' : 's'}`; }

function countSpan(n, cls) { return `<span class="${n ? cls : 'c-zero'}">${n}</span>`; }

function avgSecsPerReview() {
  const r = app.col.revlog;
  const slice = r.slice(-500);
  if (!slice.length) return 10;
  return Math.max(4, Math.min(40, slice.reduce((a, x) => a + x.time, 0) / slice.length / 1000));
}

function ring(value, max, size = 74, stroke = 7, color = 'var(--hero-btn)', track = 'rgba(255,255,255,0.18)') {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const f = Math.min(1, max ? value / max : 0);
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" aria-hidden="true"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${track}" stroke-width="${stroke}"></circle><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${c.toFixed(2)}" stroke-dashoffset="${(c * (1 - f)).toFixed(2)}"></circle></svg>`;
}

function renderToday() {
  const col = app.col;
  const now = new Date();
  const weekday = now.toLocaleDateString(undefined, { weekday: 'long' });
  const has = col.cards.size > 0;
  let html = `<main class="screen" aria-labelledby="h-today">
    <header class="screen-head">
      <div><div class="eyebrow">${esc(weekday)}</div><h1 id="h-today">Today</h1></div>
      <div style="display:flex;gap:8px">
        <button type="button" class="icon-btn" data-act="add" aria-label="Add a card">${icon('plus', 20)}</button>
        <button type="button" class="btn secondary" data-act="import">${icon('import', 18)}Import</button>
      </div>
    </header>`;
  if (!has) {
    html += `<section class="panel empty">
        <h2>Bring in your decks</h2>
        <p>Import an .apkg file from Files, iCloud Drive, AirDrop or Mail. Images, sounds, cloze and image occlusion come with it.</p>
        <button type="button" class="btn primary" data-act="import">${icon('import', 18)}Import .apkg</button>
        <button type="button" class="btn secondary" data-act="get-desktop">${icon('sync', 18)}Get from desktop Anki</button>
        <button type="button" class="btn secondary" data-act="add">${icon('plus', 18)}Start from scratch</button>
      </section>
      <p class="kbd" style="text-align:center">Tip: in Safari, tap Share → Add to Home Screen so this opens like an app and works offline.</p>
    </main>`;
    return html;
  }
  const t = col.totals();
  const st = col.stats();
  const total = t.n + t.l + t.r;
  const mins = Math.max(1, Math.round(((t.r + t.l + t.n * 3) * avgSecsPerReview()) / 60));
  const goal = app.settings.dailyGoal || 150;
  html += `<section class="hero" aria-label="Due today">
      <div class="hero-row">
        <div style="flex:1 1 auto;display:flex;flex-direction:column;gap:2px">
          <span class="big">${total}</span>
          <span class="sub">${plural(t.r, 'review')} · ${t.n} new · ${t.l} learning${total ? ` · about ${mins} min` : ''}</span>
        </div>
        ${addon('goal') ? `<div class="ring" role="img" aria-label="Daily goal: ${st.todayCount} of ${goal} cards">${ring(st.todayCount, goal)}<div class="label"><b class="num">${st.todayCount}</b>of ${goal}</div></div>` : ''}
      </div>
      <button type="button" class="hero-btn" data-act="study" ${total ? '' : 'disabled'}>${total ? 'Study all' : 'All caught up for today'}</button>
    </section>`;
  html += focusPanel();
  if (addon('exam')) html += examNotice();
  const unsent = col.unsentCount();
  html += `<section class="panel" aria-label="Desktop Anki">
      <div class="panel-head"><h2>Desktop Anki</h2><button type="button" class="btn small secondary" data-act="desktop-help">How it works</button></div>
      <p class="kbd" style="margin:0 0 10px">From desktop ${timeAgo(app.settings.lastReceived)} · ${unsent ? `<b style="color:var(--hard)">${unsent} reviews not sent yet</b>` : 'everything sent'}</p>
      <div class="grid2">
        <button type="button" class="btn compact secondary" data-act="get-desktop">${icon('import', 18)}Get from desktop</button>
        <button type="button" class="btn compact ${unsent ? 'primary' : 'secondary'}" data-act="send-desktop">${icon('upload', 18)}Send to desktop</button>
      </div>
    </section>`;
  if (addon('backup')) {
    const every = (app.settings.backupEvery || 7) * 86400000;
    if (Date.now() - (app.settings.lastBackup || 0) > every) {
      html += `<div class="notice warn" role="status">${icon('cloud', 20)}<span style="flex:1 1 auto">${app.settings.lastBackup ? `Last backup ${timeAgo(app.settings.lastBackup)}.` : 'No backup yet.'} Save a copy to iCloud Drive.</span><button type="button" class="btn small secondary" data-act="backup">Back up</button></div>`;
    }
  }
  const counts = col.allCounts();
  const roots = col.deckTree();
  html += `<h2 class="section-label">Decks</h2><div style="display:flex;flex-direction:column;gap:8px">`;
  roots.forEach((node, i) => {
    const d = node.deck;
    const c = counts.get(d.id) || { n: 0, l: 0, r: 0 };
    const [bg, ink] = tint(i);
    html += `<button type="button" class="deck-card" data-act="study-deck" data-did="${d.id}">
        <span class="badge" style="background:${bg};color:${ink}" aria-hidden="true">${esc((d.name[0] || '?').toUpperCase())}</span>
        <span class="grow"><span class="name">${esc(d.name)}</span><span class="sub">${c.n} new · ${c.l} learning</span></span>
        <span class="due" aria-label="${c.r} reviews due">${c.r}</span>
      </button>`;
  });
  html += `</div></main>`;
  return html;
}

function focusPanel() {
  const p = app.pomo;
  const cfg = app.settings.pomo;
  const every = cfg.longEvery || 4;
  const doneInCycle = p.s.done % every;
  const cur = p.s.phase === 'focus' ? doneInCycle : -1;
  const bars = Array.from({ length: every }, (_, i) => {
    if (i < doneInCycle) return '<span class="done"></span>';
    if (i === cur) return `<span class="now" style="--p:${Math.round(p.progress() * 100)}%"></span>`;
    return '<span></span>';
  }).join('');
  let status, btn;
  if (p.s.phase === 'focus') {
    status = p.byCards ? `Block ${p.s.block} · <span data-timer>${p.cardsLeft()} cards left</span>` : `Block ${p.s.block} · <span class="mono" data-timer>${fmtSecs(p.remainingMs() / 1000)}</span> left${p.s.paused ? ' (paused)' : ''}`;
    btn = `<button type="button" class="btn pomo" data-act="pomo-toggle">${p.s.paused ? 'Resume' : 'Pause'}</button>`;
  } else if (p.s.phase === 'break') {
    status = `${p.s.kind === 'long' ? 'Long break' : 'Break'} · <span class="mono" data-timer>${fmtSecs(p.remainingMs() / 1000)}</span>`;
    btn = `<button type="button" class="btn pomo" data-act="pomo-skip">Skip break</button>`;
  } else {
    status = `${p.s.done} of ${every} done today`;
    btn = `<button type="button" class="btn pomo" data-act="pomo-toggle">Start block ${p.s.block}</button>`;
  }
  const preset = POMO_PRESETS[cfg.mode] || POMO_PRESETS.classic;
  const label = cfg.mode === 'cards' ? `${cfg.cards} cards · ${cfg.short} min break` : `${cfg.focus} / ${cfg.short} · long break after ${every}`;
  return `<section class="panel" aria-label="Focus blocks">
      <div class="panel-head"><button type="button" data-act="timer" style="background:none;border:none;padding:0;text-align:left;color:var(--ink);display:flex;align-items:center;gap:8px">${icon('timer', 20)}<h2>Focus blocks</h2></button><span class="kbd">${esc(label || preset.label)}</span></div>
      <div class="blocks" style="--n:${every}" aria-hidden="true">${bars}</div>
      <div style="display:flex;align-items:center;gap:10px;margin-top:12px">
        <span style="flex:1 1 auto;font-size:14px;color:var(--muted)" data-focus-status>${status}</span>
        ${btn}
      </div>
    </section>`;
}

function examNotice() {
  const s = app.settings;
  if (!s.examDate) return `<button type="button" class="notice" data-act="exam" style="border:none;text-align:left;width:100%">${icon('calendar', 20)}<span style="flex:1 1 auto">Add an exam date to see what's due before it</span>${icon('chevron', 18)}</button>`;
  const day = isoToDay(s.examDate);
  const load = app.col.examLoad(day);
  if (load.days < 0) return `<button type="button" class="notice warn" data-act="exam" style="border:none;text-align:left;width:100%">${icon('calendar', 20)}<span style="flex:1 1 auto">${esc(s.examName || 'Exam')} date has passed — set the next one</span></button>`;
  return `<button type="button" class="notice" data-act="exam" style="border:none;text-align:left;width:100%">${icon('calendar', 20)}<span style="flex:1 1 auto"><b>${esc(s.examName || 'Exam')} in ${load.days} day${load.days === 1 ? '' : 's'}</b> · ${load.reviews} reviews + ${load.news} new cards before it</span></button>`;
}

// ---------------- decks ----------------
function renderDecks() {
  const col = app.col;
  const counts = col.allCounts();
  const collapsed = app.settings.collapsed || {};
  let rows = '';
  const walk = (node, depth) => {
    const d = node.deck;
    const c = counts.get(d.id) || { n: 0, l: 0, r: 0 };
    const hasKids = node.children.length > 0;
    const open = !collapsed[d.id];
    rows += `<div class="tree-row" style="padding-left:${4 + depth * 18}px">
      <div style="display:flex;align-items:center;min-width:0">
        ${hasKids ? `<button type="button" class="tog" data-act="collapse" data-did="${d.id}" aria-expanded="${open}" aria-label="${open ? 'Collapse' : 'Expand'} ${esc(d.name)}">${icon('chevron', 16)}</button>` : '<span style="width:32px;flex:0 0 auto"></span>'}
        <button type="button" class="name-btn" data-act="study-deck" data-did="${d.id}"><span class="label" style="font-weight:${depth ? 400 : 600}">${esc(d.name.split('::').pop())}</span></button>
      </div>
      <span class="n">${countSpan(c.n, 'c-new')}</span><span class="n">${countSpan(c.l, 'c-learn')}</span><span class="n">${countSpan(c.r, 'c-due')}</span>
      <button type="button" class="opt" data-act="deck-menu" data-did="${d.id}" aria-label="Options for ${esc(d.name)}">${icon('more', 20)}</button>
    </div>`;
    if (open) node.children.forEach((ch) => walk(ch, depth + 1));
  };
  col.deckTree().forEach((n) => walk(n, 0));
  const st = col.stats();
  return `<main class="screen" aria-labelledby="h-decks">
    <header class="screen-head"><h1 id="h-decks">Decks</h1>
      <div style="display:flex;gap:8px">
        <button type="button" class="icon-btn" data-act="new-deck" aria-label="Create deck">${icon('plus', 20)}</button>
        <button type="button" class="btn secondary" data-act="import">${icon('import', 18)}Import</button>
      </div></header>
    <div class="list">
      <div class="tree-head" aria-hidden="true"><span>Deck</span><span>New</span><span>Lrn</span><span>Due</span><span></span></div>
      ${rows || '<div class="empty"><p>No decks yet. Import an .apkg or create a deck.</p></div>'}
    </div>
    <p class="kbd" style="text-align:center">Studied ${plural(st.todayCount, 'card')} in ${Math.round(st.todayTime / 60000)} min today</p>
    <div class="drop">Drop in an .apkg — open it from Files, AirDrop or Mail and choose this app, or tap Import.</div>
  </main>`;
}

async function deckMenu(did) {
  const col = app.col;
  const d = col.decks.get(did);
  const items = [
    { label: 'Study now', action: 'study' },
    { label: 'Add cards', action: 'add' },
    { label: 'Options', action: 'options' },
    { label: 'Rename', action: 'rename' },
    { label: 'Add subdeck', action: 'sub' },
  ];
  if (addon('vacation')) items.push({ label: 'Skip a day for this deck', action: 'skip' });
  if (addon('export')) items.push({ label: 'Export .apkg with progress', action: 'export' });
  items.push({ label: 'Delete deck', action: 'delete', danger: true });
  const pick = await actionSheet(d.name, items);
  if (!pick) return;
  if (pick === 'study') return openReview(did);
  if (pick === 'add') return openNoteEditor({ did });
  if (pick === 'options') return openDeckOptions(did);
  if (pick === 'export') return exportDeck(did);
  if (pick === 'rename') {
    const name = await promptDialog('Rename deck', d.name);
    if (name) { try { await col.renameDeck(did, name); render(); } catch (e) { toast(e.message); } }
  }
  if (pick === 'sub') {
    const name = await promptDialog('Subdeck name', '');
    if (name) { await col.ensureDeck(d.name + '::' + name); render(); }
  }
  if (pick === 'skip') {
    const n = await col.skipDay(did);
    toast(n ? `${n} due cards spread over the next 3 days` : 'Nothing due today in this deck');
    render();
  }
  if (pick === 'delete') {
    const n = [...col.cards.values()].filter((c) => col.deckFamily(did).has(c.did)).length;
    if (await confirmDialog(`Delete <b>${esc(d.name)}</b> and its ${n} cards? This can't be undone.`, { ok: 'Delete', danger: true })) {
      await col.deleteDeck(did);
      toast('Deck deleted');
      render();
    }
  }
}

// ---------------- browse ----------------
function renderBrowse() {
  const chips = [['is:due', 'Due'], ['is:new', 'New'], ['is:suspended', 'Suspended'], ['-flag:0', 'Flagged'], ['added:1', 'Added today'], ['rated:1', 'Studied today']];
  return `<main class="screen" aria-labelledby="h-browse">
    <header class="screen-head"><h1 id="h-browse">Browse</h1>
      <button type="button" class="btn primary" data-act="add">${icon('plus', 18)}Add</button></header>
    <label class="search">${icon('browse', 18)}<span class="sr-only">Search cards</span>
      <input type="search" data-browse-q placeholder="Search, or deck: tag: is:due" value="${esc(ui.browseQuery)}" autocapitalize="off" autocorrect="off" spellcheck="false"></label>
    <div style="display:flex;gap:6px;flex-wrap:wrap">${chips.map(([q, l]) => `<button type="button" class="chip" data-act="browse-chip" data-q="${esc(q)}" style="border:none;min-height:32px">${l}</button>`).join('')}</div>
    <p class="kbd" data-browse-count></p>
    <div class="list" data-browse-list></div>
    <div data-browse-more></div>
  </main>`;
}

function rowText(note) {
  const nt = app.col.notetypes.get(note.mid);
  let txt = note.flds[(nt && nt.sortf) || 0] || note.flds[0] || '';
  if (nt && isIoNotetype(nt)) txt = stripHtml(note.flds[nt.flds.indexOf('Header')] || '') || 'Image occlusion';
  txt = txt.replace(/\{\{c\d+::(.*?)(::.*?)?\}\}/g, '$1');
  return stripHtml(txt) || (/<img/i.test(note.flds.join('')) ? '[image]' : '(empty)');
}

function renderBrowseResults() {
  const list = document.querySelector('[data-browse-list]');
  if (!list) return;
  const col = app.col;
  const cards = col.search(ui.browseQuery);
  // one row per note
  const seen = new Set();
  const rows = [];
  for (const c of cards.sort((a, b) => b.nid - a.nid)) {
    if (seen.has(c.nid)) continue;
    seen.add(c.nid);
    rows.push(c);
  }
  document.querySelector('[data-browse-count]').textContent = `${rows.length} note${rows.length === 1 ? '' : 's'} · ${cards.length} card${cards.length === 1 ? '' : 's'}`;
  const t = col.today();
  list.innerHTML = rows.slice(0, ui.browseLimit).map((c) => {
    const n = col.notes.get(c.nid);
    const d = col.decks.get(c.did);
    const due = c.queue === -1 ? 'Suspended' : c.type === 0 ? 'New' : c.queue === 1 ? 'Learning' : c.dueDay <= t ? 'Due' : 'Due in ' + fmtIvl(c.dueDay - t);
    const flag = c.flags ? `<span class="flag-dot" style="background:${FLAGS[c.flags - 1].color}" aria-label="${FLAGS[c.flags - 1].name} flag"></span>` : '';
    return `<button type="button" class="browse-row" data-act="edit-note" data-nid="${c.nid}">
      <span class="q">${esc(rowText(n))}</span>
      <span class="m">${flag}<span>${esc(d ? d.name.split('::').pop() : '')}</span><span>${due}</span>${n.tags.length ? `<span>${esc(n.tags.slice(0, 3).join(' '))}</span>` : ''}</span>
    </button>`;
  }).join('') || '<div class="empty"><p>No cards match.</p></div>';
  document.querySelector('[data-browse-more]').innerHTML = rows.length > ui.browseLimit ? `<button type="button" class="btn secondary block" data-act="browse-more">Show more</button>` : '';
}

// ---------------- stats ----------------
function renderStats() {
  const col = app.col;
  const st = col.stats();
  const t = col.today();
  let heat = '';
  if (addon('heatmap')) {
    const weeks = 18;
    // align columns to weeks ending today
    const start = t - (weeks * 7 - 1) - ((new Date().getDay() + 6) % 7 === 6 ? 0 : 0);
    const cells = [];
    const max = Math.max(1, ...[...st.byDay.values()]);
    for (let d = start; d <= t; d++) {
      const n = st.byDay.get(d) || 0;
      const lvl = n === 0 ? 0 : Math.min(4, 1 + Math.floor((n / max) * 3.999));
      cells.push(`<span class="h${lvl}" title="${dayToISO(d)}: ${n} reviews"></span>`);
    }
    heat = `<section class="panel"><div class="panel-head"><h2>Review heatmap</h2><span class="kbd">Last ${weeks} weeks</span></div>
      <div class="heatmap" role="img" aria-label="Reviews per day for the last ${weeks} weeks">${cells.join('')}</div>
      <div class="heat-legend">Less <i style="background:var(--heat0)"></i><i style="background:var(--heat1)"></i><i style="background:var(--heat2)"></i><i style="background:var(--heat3)"></i><i style="background:var(--heat4)"></i> More</div></section>`;
  }
  const range = ui.statsRange;
  const fc = st.forecast.slice(0, range);
  const fmax = Math.max(1, ...fc);
  const dayNames = fc.map((_, i) => {
    const dt = new Date(Date.now() + i * 86400000);
    return range <= 7 ? (i === 0 ? 'Today' : dt.toLocaleDateString(undefined, { weekday: 'short' })) : (i % 5 === 0 ? `+${i}` : '');
  });
  const forecast = `<section class="panel"><div class="panel-head"><h2>Due ahead</h2>
      <div class="seg" style="--n:2;width:150px" role="group" aria-label="Range"><button type="button" data-act="stats-range" data-r="7" aria-pressed="${range === 7}">7 days</button><button type="button" data-act="stats-range" data-r="30" aria-pressed="${range === 30}">30 days</button></div></div>
      <div class="bars" style="--n:${range}" role="img" aria-label="Cards due per day">${fc.map((n) => `<div class="col">${range <= 7 ? `<span>${n}</span>` : ''}<i style="height:${Math.round((n / fmax) * 80)}px"></i></div>`).join('')}</div>
      <div class="bar-labels" style="--n:${range}">${dayNames.map((x) => `<span>${x}</span>`).join('')}</div></section>`;
  let weak = '';
  if (addon('tagstats')) {
    const items = st.weak.slice(0, 8);
    weak = `<section class="panel"><div class="panel-head"><h2>Weak spots by tag</h2><span class="kbd">Last 30 days</span></div>
      ${items.length ? items.map((w) => {
        const pct = Math.round(w.pct * 100);
        const color = pct >= 90 ? 'var(--good)' : pct >= 80 ? 'var(--heat3)' : 'var(--pomo)';
        return `<div class="weak-row"><div class="top"><span>${esc(w.tag)}</span><span><b>${pct}%</b> <span class="muted">· ${w.n} reviews</span></span></div><div class="meter"><i style="width:${pct}%;background:${color}"></i></div></div>`;
      }).join('') : '<p class="kbd" style="margin:0">Review a few tagged cards and the tags you miss most show up here.</p>'}</section>`;
  }
  const c = st.counts;
  const goal = app.settings.dailyGoal || 150;
  return `<main class="screen" aria-labelledby="h-stats">
    <header class="screen-head"><h1 id="h-stats">Stats</h1></header>
    <div class="tiles3" style="--cols:${(addon('heatmap') ? 1 : 0) + 2 + (addon('goal') ? 1 : 0) === 4 ? 2 : 3}">
      ${addon('heatmap') ? `<div class="tile"><b>${st.streak} day${st.streak === 1 ? '' : 's'}</b><span>Streak</span></div>` : ''}
      <div class="tile"><b>${st.retention == null ? '—' : Math.round(st.retention * 100) + '%'}</b><span>Retention · 30 days</span></div>
      <div class="tile"><b>${st.todayCount}</b><span>Today · ${Math.round(st.todayTime / 60000)} min</span></div>
      ${addon('goal') ? `<div class="tile"><b>${Math.min(100, Math.round((st.todayCount / goal) * 100))}%</b><span>Daily goal (${goal})</span></div>` : ''}
    </div>
    ${heat}${forecast}${weak}
    <section class="panel"><h2 style="margin-bottom:8px">Cards</h2>
      <div class="list" style="border:none">
        ${[['New', c.new, 'var(--new)'], ['Learning', c.learn, 'var(--learn)'], ['Young (under 21 days)', c.young, 'var(--heat2)'], ['Mature', c.mature, 'var(--due)'], ['Suspended', c.suspended, 'var(--muted)']].map(([k, v, col2]) => `<div class="list-row" style="padding:8px 0"><span class="flag-dot" style="background:${col2}"></span><span class="grow">${k}</span><span class="value num">${v}</span></div>`).join('')}
      </div></section>
  </main>`;
}

// ---------------- settings ----------------
function sw(key, on, title, desc = '', attr = 'data-set') {
  return `<button type="button" class="switch-row" ${attr}="${key}" aria-pressed="${!!on}"><span class="grow"><span class="t">${esc(title)}</span>${desc ? `<span class="d">${esc(desc)}</span>` : ''}</span><span class="toggle" aria-hidden="true"></span></button>`;
}
function numField(id, label, value, attrs = '') {
  return `<div class="field"><label for="${id}">${esc(label)}</label><input class="input" id="${id}" type="number" inputmode="numeric" value="${esc(value)}" data-num="${id}" ${attrs}></div>`;
}

function renderSettings() {
  const s = app.settings;
  const col = app.col;
  const groups = {};
  for (const a of ADDONS) (groups[a.group] = groups[a.group] || []).push(a);
  const p = s.pomo;
  let html = `<main class="screen" aria-labelledby="h-settings"><header class="screen-head"><h1 id="h-settings">Settings</h1></header>`;
  // study
  html += `<h2 class="section-label">Scheduling</h2>
    <section class="panel">
      <div class="field"><div class="label">Scheduler</div>
        <div class="seg" style="--n:2" role="group" aria-label="Scheduler">
          <button type="button" data-act="sched" data-v="sm2" aria-pressed="${!col.fsrs}">SM-2 (Anki default)</button>
          <button type="button" data-act="sched" data-v="fsrs" aria-pressed="${col.fsrs}">FSRS</button>
        </div></div>
      <p class="kbd" style="margin:0">Match what you use in desktop Anki. Per-deck limits and steps are under each deck's options.</p>
      ${addon('goal') ? `<div style="margin-top:14px">${numField('dailyGoal', 'Daily goal (cards)', s.dailyGoal, 'min="10" step="10"')}</div>` : ''}
      ${addon('exam') ? `<div class="grid2"><div class="field"><label for="examName">Exam name</label><input class="input" id="examName" data-text="examName" value="${esc(s.examName)}" placeholder="e.g. OCS 1A block exam"></div>
        <div class="field"><label for="examDate">Exam date</label><input class="input" id="examDate" type="date" data-text="examDate" value="${esc(s.examDate)}"></div></div>` : ''}
      ${addon('vacation') ? `<button type="button" class="btn secondary block" data-act="skip-day">Skip today (spread today's reviews over 3 days)</button>` : ''}
    </section>`;
  // timer
  html += `<h2 class="section-label">Focus timer</h2>
    <section class="panel">
      <div class="field"><div class="label">Rhythm</div>
        <div class="seg" style="--n:3" role="group" aria-label="Pomodoro rhythm">
          ${Object.entries(POMO_PRESETS).map(([k, v]) => `<button type="button" data-act="pomo-mode" data-v="${k}" aria-pressed="${p.mode === k}">${v.label}</button>`).join('')}
        </div></div>
      <div class="grid2">
        ${p.mode === 'cards' ? numField('pomoCards', 'Cards per block', p.cards, 'min="10"') : numField('pomoFocus', 'Focus (min)', p.focus, 'min="1"')}
        ${numField('pomoShort', 'Short break (min)', p.short, 'min="1"')}
        ${numField('pomoLong', 'Long break (min)', p.long, 'min="1"')}
        ${numField('pomoEvery', 'Long break every', p.longEvery, 'min="2"')}
      </div>
      <div class="list" style="margin-top:4px">
        ${sw('pauseReviews', p.pauseReviews, 'Pause reviews during breaks', 'Shows the break screen instead of the next card.', 'data-pomo-set')}
        ${sw('chime', p.chime, 'Chime when time is up', '', 'data-pomo-set')}
      </div>
    </section>`;
  if (addon('speed')) {
    html += `<h2 class="section-label">Speed focus</h2><section class="panel">
      <div class="grid2">${numField('speedQ', 'Seconds to flip (0 = off)', s.speed.q, 'min="0"')}${numField('speedA', 'Seconds to answer (0 = off)', s.speed.a, 'min="0"')}</div>
      <div class="field"><div class="label">When answer time runs out</div><div class="seg" style="--n:2" role="group" aria-label="Answer timeout action">
        <button type="button" data-act="speed-action" data-v="again" aria-pressed="${s.speed.action === 'again'}">Mark Again</button>
        <button type="button" data-act="speed-action" data-v="nudge" aria-pressed="${s.speed.action !== 'again'}">Just remind me</button></div></div></section>`;
  }
  if (addon('themes')) {
    html += `<h2 class="section-label">Appearance</h2><section class="panel">
      <div class="field"><div class="label">Theme</div><div class="seg" style="--n:4" role="group" aria-label="Theme">
        ${['auto', 'light', 'dark', 'sepia'].map((t) => `<button type="button" data-act="theme" data-v="${t}" aria-pressed="${s.theme === t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div></div>
      <div class="field"><label for="textScale">Card text size · ${Math.round((s.textScale || 1) * 100)}%</label><input id="textScale" type="range" min="0.8" max="1.8" step="0.1" value="${s.textScale || 1}" data-range="textScale"></div></section>`;
  }
  // add-ons
  html += `<h2 class="section-label">Add-ons</h2>`;
  for (const [g, items] of Object.entries(groups)) {
    html += `<p class="kbd" style="margin:4px 4px 0;font-weight:600">${esc(g)}</p><div class="list">${items.map((a) => sw(a.key, s.addons[a.key], a.name, a.desc, 'data-addon')).join('')}</div>`;
  }
  // desktop
  html += `<h2 class="section-label">Desktop Anki</h2><section class="panel">
      <p class="kbd" style="margin:0 0 10px">Last received ${timeAgo(s.lastReceived)} · last sent ${timeAgo(col.meta.lastSent)}</p>
      <div class="grid2"><button type="button" class="btn compact secondary" data-act="get-desktop">${icon('import', 18)}Get from desktop</button><button type="button" class="btn compact secondary" data-act="send-desktop">${icon('upload', 18)}Send to desktop</button></div>
      <button type="button" class="btn secondary block" data-act="desktop-help" style="margin-top:10px">Set up the desktop companion</button></section>`;
  if (addon('backup')) {
    html += `<h2 class="section-label">Backup</h2><section class="panel">
      <p class="kbd" style="margin:0 0 10px">Last backup ${timeAgo(s.lastBackup)}. Backups are .apkg files — save them to iCloud Drive with "Save to Files".</p>
      <div class="grid2"><button type="button" class="btn primary" data-act="backup">${icon('cloud', 18)}Back up now</button><button type="button" class="btn secondary" data-act="restore">Restore…</button></div>
      ${numField('backupEvery', 'Remind me every (days)', s.backupEvery, 'min="1"')}</section>`;
  }
  html += `<h2 class="section-label">Data</h2><div class="list">
      <button type="button" class="list-row" data-act="import"><span class="grow title">Import .apkg</span>${icon('chevron', 18)}</button>
      ${addon('export') ? `<button type="button" class="list-row" data-act="export-all"><span class="grow title">Export everything as .apkg</span>${icon('chevron', 18)}</button>` : ''}
      <div class="list-row"><span class="grow title">Stored on this phone</span><span class="value" data-storage>${col.cards.size} cards</span></div>
      <button type="button" class="list-row" data-act="reset" style="color:var(--danger)"><span class="grow title">Reset app…</span></button>
    </div>
    <p class="kbd" style="text-align:center">AnkiPhone ${VERSION} · works offline · your cards stay on this device<br>Uses sql.js, JSZip and fzstd (open-source licenses in the vendor folder).</p>
  </main>`;
  setTimeout(showStorage, 0);
  return html;
}

async function showStorage() {
  const el = document.querySelector('[data-storage]');
  if (!el) return;
  const est = await db.estimate();
  if (est && est.usage != null) el.textContent = `${app.col.cards.size} cards · ${(est.usage / 1048576).toFixed(1)} MB`;
}

// ---------------- timer sheet ----------------
function openTimerSheet() {
  ui.timerSheet = openSheet({
    title: 'Focus timer',
    body: `<div data-timer-body></div>`,
    onClose: () => { ui.timerSheet = null; },
    onMount: (body) => {
      body.addEventListener('click', (e) => {
        const b = e.target.closest('[data-t]');
        if (!b) return;
        unlockAudio();
        const p = app.pomo;
        if (b.dataset.t === 'toggle') p.toggle();
        if (b.dataset.t === 'skip') p.skip();
        if (b.dataset.t === 'reset') p.reset();
        updateTimerViews();
        render();
      });
    },
  });
  updateTimerViews();
}

function updateTimerViews() {
  const p = app.pomo;
  // today panel live text
  const st = document.querySelector('[data-focus-status] [data-timer]');
  if (st) st.textContent = p.byCards && p.s.phase === 'focus' ? `${p.cardsLeft()} cards left` : fmtSecs(p.remainingMs() / 1000);
  const nowBar = document.querySelector('.blocks span.now');
  if (nowBar) nowBar.style.setProperty('--p', Math.round(p.progress() * 100) + '%');
  if (!ui.timerSheet) return;
  const body = ui.timerSheet.body.querySelector('[data-timer-body]');
  if (!body) return;
  const cfg = app.settings.pomo;
  const every = cfg.longEvery || 4;
  const r = 100, c = 2 * Math.PI * r;
  const f = p.progress();
  const phaseLabel = p.s.phase === 'break' ? (p.s.kind === 'long' ? 'Long break' : 'Break') : p.s.phase === 'focus' ? `Focus · block ${p.s.block} of ${every}` : `Ready · block ${p.s.block}`;
  const big = p.s.phase === 'focus' && p.byCards ? String(p.cardsLeft()) : fmtSecs(p.remainingMs() / 1000);
  const dots = Array.from({ length: every }, (_, i) => `<span style="width:12px;height:12px;border-radius:6px;${i < p.s.done % every ? 'background:var(--pomo)' : 'border:2px solid var(--line)'}"></span>`).join('');
  const main = p.s.phase === 'idle' || p.s.phase === 'ready' ? 'Start' : p.s.paused ? 'Resume' : 'Pause';
  body.innerHTML = `
    <div class="timer-ring"><svg width="220" height="220" viewBox="0 0 220 220" role="img" aria-label="${esc(phaseLabel)}, ${esc(big)} ${p.byCards && p.s.phase === 'focus' ? 'cards' : ''} left"><circle cx="110" cy="110" r="${r}" fill="none" stroke="var(--pomo-soft)" stroke-width="12"></circle><circle cx="110" cy="110" r="${r}" fill="none" stroke="var(--pomo)" stroke-width="12" stroke-linecap="round" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${(c * (1 - f)).toFixed(1)}"></circle></svg>
      <div class="inner"><span class="t mono">${big}</span><span class="kbd" style="font-size:14px">${p.byCards && p.s.phase === 'focus' ? 'cards left · ' : ''}${esc(phaseLabel)}</span></div></div>
    <div style="display:flex;gap:10px;justify-content:center;margin:14px 0" aria-label="${p.s.done % every} of ${every} blocks done">${dots}</div>
    <div class="timer-controls">
      <button type="button" class="icon-btn" data-t="reset" aria-label="Reset timer" style="width:52px;height:52px">${icon('reset', 22)}</button>
      <button type="button" class="btn pomo main" data-t="toggle">${main}</button>
      <button type="button" class="icon-btn" data-t="skip" aria-label="${p.s.phase === 'focus' ? 'Skip to break' : 'Skip to focus'}" style="width:52px;height:52px">${icon('skip', 22)}</button>
    </div>
    <p class="kbd" style="text-align:center;margin-top:16px">${p.s.done} block${p.s.done === 1 ? '' : 's'} done today. Change the rhythm in Settings → Focus timer.</p>`;
}

// ---------------- events ----------------
async function onClick(e) {
  const b = e.target.closest('[data-act], [data-set], [data-addon], [data-pomo-set]');
  if (!b) return;
  unlockAudio();
  const s = app.settings;
  if (b.dataset.addon) {
    s.addons[b.dataset.addon] = !s.addons[b.dataset.addon];
    await saveSettings();
    applyTheme();
    render();
    return;
  }
  if (b.dataset.pomoSet) {
    s.pomo[b.dataset.pomoSet] = !s.pomo[b.dataset.pomoSet];
    await saveSettings();
    render();
    return;
  }
  const act = b.dataset.act;
  const did = b.dataset.did ? Number(b.dataset.did) : null;
  switch (act) {
    case 'tab': app.tab = b.dataset.tab; window.scrollTo(0, 0); render(); break;
    case 'import': importFlow(); break;
    case 'get-desktop': importFlow({ fromDesktop: true }); break;
    case 'send-desktop': sendToDesktop(); break;
    case 'desktop-help': desktopHelp(); break;
    case 'backup': backupNow(); break;
    case 'restore': {
      const replace = await confirmDialog('Replace everything on this phone with the backup? Choose "Merge" to keep cards that aren\'t in the backup.', { ok: 'Replace', cancel: 'Merge' });
      importFlow({ replace });
      break;
    }
    case 'export-all': exportDeck(null); break;
    case 'reset': resetEverything(); break;
    case 'study': openReview(null); break;
    case 'study-deck': openReview(did); break;
    case 'deck-menu': deckMenu(did); break;
    case 'collapse': s.collapsed[did] = !s.collapsed[did]; await saveSettings(); render(); break;
    case 'new-deck': {
      const name = await promptDialog('New deck', '', { ok: 'Create', placeholder: 'e.g. Histology::Connective tissue' });
      if (name && name.trim()) { await app.col.ensureDeck(name); render(); }
      break;
    }
    case 'add': openNoteEditor({}); break;
    case 'edit-note': {
      const note = app.col.notes.get(Number(b.dataset.nid));
      if (note) openNoteEditor({ note, onSaved: () => renderBrowseResults() });
      break;
    }
    case 'browse-chip': {
      ui.browseQuery = b.dataset.q; ui.browseLimit = 100;
      const inp = document.querySelector('[data-browse-q]'); if (inp) inp.value = ui.browseQuery;
      renderBrowseResults();
      break;
    }
    case 'browse-more': ui.browseLimit += 200; renderBrowseResults(); break;
    case 'stats-range': ui.statsRange = Number(b.dataset.r); render(); break;
    case 'timer': openTimerSheet(); break;
    case 'pomo-toggle': app.pomo.toggle(); render(); break;
    case 'pomo-skip': app.pomo.skip(); render(); break;
    case 'exam': app.tab = 'settings'; render(); setTimeout(() => { const el = document.getElementById('examDate'); if (el) { el.scrollIntoView({ block: 'center' }); el.focus(); } }, 50); break;
    case 'skip-day': {
      if (await confirmDialog('Move everything due today to the next three days?', { ok: 'Skip today' })) {
        const n = await app.col.skipDay(null);
        toast(n ? `${n} cards spread over the next 3 days` : 'Nothing due today');
        render();
      }
      break;
    }
    case 'sched': {
      const want = b.dataset.v === 'fsrs';
      if (want !== app.col.fsrs) {
        app.col.meta.fsrs = want;
        await app.col.saveMeta();
        toast(want ? 'FSRS on — intervals now follow your memory model' : 'SM-2 on');
        render();
      }
      break;
    }
    case 'pomo-mode': {
      const k = b.dataset.v;
      const pr = POMO_PRESETS[k];
      Object.assign(s.pomo, { mode: k, focus: pr.focus || s.pomo.focus, short: pr.short, long: pr.long, longEvery: pr.longEvery });
      if (pr.cards) s.pomo.cards = s.pomo.cards || pr.cards;
      app.pomo.cfg = s.pomo;
      await saveSettings();
      render();
      break;
    }
    case 'speed-action': s.speed.action = b.dataset.v; await saveSettings(); render(); break;
    case 'theme': s.theme = b.dataset.v; await saveSettings(); applyTheme(); render(); break;
    default: break;
  }
}

let browseTimer = null;
function onInput(e) {
  if (e.target.matches('[data-browse-q]')) {
    ui.browseQuery = e.target.value;
    ui.browseLimit = 100;
    clearTimeout(browseTimer);
    browseTimer = setTimeout(renderBrowseResults, 180);
  }
  if (e.target.matches('[data-range="textScale"]')) {
    app.settings.textScale = Number(e.target.value);
    applyTheme();
    const lab = document.querySelector('label[for="textScale"]');
    if (lab) lab.textContent = `Card text size · ${Math.round(app.settings.textScale * 100)}%`;
  }
}

async function onChange(e) {
  const s = app.settings;
  const t = e.target;
  if (t.dataset.num) {
    const v = Number(t.value);
    const map = {
      dailyGoal: () => { s.dailyGoal = Math.max(10, v || 150); },
      pomoFocus: () => { s.pomo.focus = Math.max(1, v || 25); },
      pomoShort: () => { s.pomo.short = Math.max(1, v || 5); },
      pomoLong: () => { s.pomo.long = Math.max(1, v || 15); },
      pomoEvery: () => { s.pomo.longEvery = Math.max(2, v || 4); },
      pomoCards: () => { s.pomo.cards = Math.max(10, v || 100); },
      speedQ: () => { s.speed.q = Math.max(0, v || 0); },
      speedA: () => { s.speed.a = Math.max(0, v || 0); },
      backupEvery: () => { s.backupEvery = Math.max(1, v || 7); },
    };
    if (map[t.dataset.num]) { map[t.dataset.num](); app.pomo.cfg = s.pomo; await saveSettings(); }
  }
  if (t.dataset.text) { s[t.dataset.text] = t.value; await saveSettings(); }
  if (t.dataset.range) await saveSettings();
}

boot();
