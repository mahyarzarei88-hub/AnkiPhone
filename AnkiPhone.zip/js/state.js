// Shared app state, settings, library loading, media cache, card mounting.

import * as db from './db.js';
import { defaultPomo } from './pomodoro.js';
import { renderCard, isIoNotetype } from './render.js';

export const ADDONS = [
  { key: 'occlusion', group: 'Study tools', name: 'Image occlusion', desc: 'Hide labels on histology slides and diagrams, then quiz yourself on each one.' },
  { key: 'typein', group: 'Study tools', name: 'Type-in answers', desc: 'Type your answer before flipping and see what you got wrong.' },
  { key: 'scratch', group: 'Study tools', name: 'Scratchpad', desc: 'Draw on top of a card with your finger or Apple Pencil.' },
  { key: 'hints', group: 'Study tools', name: 'Tap-to-reveal hints', desc: 'Hide extra and hint fields until you tap them.' },
  { key: 'speed', group: 'Study tools', name: 'Speed focus', desc: 'Auto-flip, or mark Again, if a card takes longer than you set.' },
  { key: 'exam', group: 'Scheduling', name: 'Exam countdown', desc: 'Set an exam date to see days left and what is due before it.' },
  { key: 'balance', group: 'Scheduling', name: 'Load balancer', desc: 'Spreads reviews more evenly so no single day piles up.' },
  { key: 'vacation', group: 'Scheduling', name: 'Skip-a-day', desc: 'Take a day off without the backlog spiking.' },
  { key: 'heatmap', group: 'Motivation & stats', name: 'Review heatmap & streaks', desc: 'Calendar grid of how much you reviewed each day.' },
  { key: 'goal', group: 'Motivation & stats', name: 'Daily goal ring', desc: 'Pick a card target for the day and watch it fill.' },
  { key: 'tagstats', group: 'Motivation & stats', name: 'Weak-spot report', desc: 'Retention by tag, so you see which lectures need work.' },
  { key: 'gestures', group: 'Feel', name: 'Swipe to answer', desc: 'Swipe left for Again, right for Good, up for Easy.' },
  { key: 'themes', group: 'Feel', name: 'Themes & big text', desc: 'Light, dark and sepia themes, plus larger card text.' },
  { key: 'haptics', group: 'Feel', name: 'Haptics & sounds', desc: 'Light taps on answer buttons and a chime when the timer ends.' },
  { key: 'export', group: 'Your data', name: 'Export back to .apkg', desc: 'Export decks with your progress as .apkg files desktop Anki can open.' },
  { key: 'backup', group: 'Your data', name: 'iCloud backup', desc: 'Reminders and one-tap backups of your whole collection to iCloud Drive.' },
];

export function defaultSettings() {
  return {
    addons: Object.fromEntries(ADDONS.map((a) => [a.key, true])),
    theme: 'auto', textScale: 1,
    pomo: defaultPomo(),
    examDate: '', examName: '',
    dailyGoal: 150,
    speed: { q: 30, a: 20, action: 'again' },
    backupEvery: 7, lastBackup: 0,
    collapsed: {},
    lastReceived: 0,
  };
}

export const app = {
  col: null,
  settings: null,
  pomo: null,
  tab: 'today',
  libs: null,
  mediaUrls: new Map(),
  render: () => {},
};

export function addon(key) { return !!(app.settings && app.settings.addons[key]); }

export async function saveSettings() { await db.kvSet('settings', app.settings); }

// ---------- libraries (loaded on first import/export) ----------
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error('Could not load ' + src));
    document.head.appendChild(s);
  });
}
export async function getLibs() {
  if (app.libs) return app.libs;
  if (!window.JSZip) await loadScript('vendor/jszip.min.js');
  if (!window.initSqlJs) await loadScript('vendor/sql-wasm.js');
  const SQL = await window.initSqlJs({ locateFile: (f) => 'vendor/' + f });
  const fz = await import('../vendor/fzstd.js');
  app.libs = { SQL, JSZip: window.JSZip, zstdDecompress: (u8) => fz.decompress(u8) };
  return app.libs;
}

// ---------- media ----------
const MEDIA_RE = /src=["']?([^"'>\s]+)|\[sound:([^\]]+)\]|url\(\s*["']?([^"')]+)["']?\s*\)/gi;
export function mediaNamesIn(texts) {
  const names = new Set();
  for (const t of texts) {
    let m;
    MEDIA_RE.lastIndex = 0;
    while ((m = MEDIA_RE.exec(t || ''))) {
      let n = (m[1] || m[2] || m[3] || '').trim();
      if (!n || /^(https?:|data:|blob:)/i.test(n)) continue;
      try { n = decodeURIComponent(n); } catch { /* keep */ }
      names.add(n);
    }
  }
  return names;
}
export async function ensureMedia(names) {
  const missing = [...names].filter((n) => !app.mediaUrls.has(n));
  await Promise.all(missing.map(async (n) => {
    const blob = await db.getMedia(n);
    app.mediaUrls.set(n, blob ? URL.createObjectURL(blob) : null);
  }));
}
export function mediaUrl(name) { return app.mediaUrls.get(name) || null; }
export function forgetMediaUrl(name) {
  const u = app.mediaUrls.get(name);
  if (u) URL.revokeObjectURL(u);
  app.mediaUrls.delete(name);
}

// ---------- card mounting (shadow DOM keeps deck CSS from leaking) ----------
const BASE_CARD_CSS = `
:host { display: block; color: var(--ink); }
.card { padding: 30px 20px 28px; font-size: calc(20px * var(--card-scale, 1)); line-height: 1.45; text-align: center; overflow-wrap: anywhere; min-height: 100%; box-sizing: border-box; }
.card { background: transparent !important; }
.card.themed { color: var(--ink) !important; }
img { max-width: 100%; height: auto; }
hr#answer, hr { border: none; border-top: 1px solid var(--line); margin: 18px 0; }
.cloze { font-weight: bold; color: #1F5FBF; }
.nightMode .cloze { color: #8FB4F0; }
.cloze-inactive { }
.typeans-input { width: 100%; max-width: 420px; min-height: 44px; border-radius: 12px; border: 1px solid var(--line); padding: 8px 12px; font: inherit; font-size: 17px; background: var(--surface-2); color: var(--ink); margin-top: 14px; box-sizing: border-box; }
code.typeans { font-family: ui-monospace, Menlo, monospace; font-size: 17px; display: inline-block; text-align: left; padding: 8px 12px; border-radius: 10px; background: var(--surface-2); margin-top: 12px; }
.typeGood { background: #CBEFD5; color: #12401F; }
.typeBad { background: #F7C6C2; color: #5C140F; }
.typeMissed { background: #F3E3B5; color: #4A3300; }
.typearrow { color: var(--muted); }
details.reveal { margin: 12px auto 0; max-width: 520px; border: 1px solid var(--line); border-radius: 12px; padding: 0 12px; text-align: left; }
details.reveal summary { min-height: 44px; display: flex; align-items: center; font-size: 15px; font-weight: 600; color: var(--accent); cursor: pointer; list-style: none; }
details.reveal summary::-webkit-details-marker { display: none; }
details.reveal summary::before { content: "▸"; margin-right: 8px; transition: transform .15s; }
details.reveal[open] summary::before { transform: rotate(90deg); }
details.reveal > div { padding-bottom: 12px; }
a.hint { display: inline-block; min-height: 36px; line-height: 36px; padding: 0 12px; border-radius: 10px; background: var(--accent-soft); color: var(--accent-text); text-decoration: none; font-size: 15px; font-weight: 600; margin: 6px 0; }
.play-sound { width: 44px; height: 44px; border-radius: 22px; border: 1px solid var(--line); background: var(--surface-2); color: var(--ink); font-size: 16px; margin: 4px; }
.missing-field { color: var(--muted); font-size: 14px; }
.io-header { font-weight: 600; margin-bottom: 10px; }
.io { position: relative; display: inline-block; width: 100%; max-width: 900px; line-height: 0; }
.io img { display: block; width: 100%; height: auto; }
.io-mask { position: absolute; box-sizing: border-box; border-radius: 3px; }
.io-mask.active { background: #F08A5D; border: 2px solid #7A2E0B; }
.io-mask.inactive { background: #D5D9E0; border: 1px solid #8A919C; }
.io-mask.revealed { background: transparent; border: 3px solid #F08A5D; }
.io-mask.ellipse { border-radius: 50%; }
.io svg.io-poly { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; }
.io.masks-hidden .io-mask.inactive, .io.masks-hidden svg .inactive { display: none; }
.io-tools { margin-top: 12px; }
.io-tools button { min-height: 40px; padding: 0 14px; border-radius: 10px; border: 1px solid var(--line); background: var(--surface-2); color: var(--ink); font: inherit; font-size: 14px; font-weight: 600; }
.io-extra { margin-top: 12px; }
`;

export function isDarkTheme() { return document.documentElement.dataset.theme === 'dark'; }

export async function prepareCardMedia(note, nt) {
  await ensureMedia(mediaNamesIn([...note.flds, nt.css]));
}

// Render a card side into a host element. Returns the shadow root.
export function mountCard(host, note, nt, card, side, extra = {}) {
  const deck = app.col.decks.get(card.did);
  const r = renderCard(note, nt, card, side, {
    deckName: deck ? deck.name : '', mediaUrl, typed: extra.typed,
    addons: { hints: addon('hints') },
  });
  const root = host.shadowRoot || host.attachShadow({ mode: 'open' });
  const theme = document.documentElement.dataset.theme;
  const themed = theme === 'dark' || theme === 'sepia';
  const night = theme === 'dark';
  let extraHtml = '';
  if (extra.typeBox && !r.hasTypeAnswer && side === 'q') {
    extraHtml = '<input type="text" class="typeans-input" id="typeans" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Type your answer">';
  }
  if (extra.typeCompare && side === 'a') extraHtml = extra.typeCompare;
  root.innerHTML = `<style>${BASE_CARD_CSS}</style><style>${r.css}</style>
    <div class="card ${themed ? 'themed' : ''} ${night ? 'nightMode night_mode' : ''}">${r.html}${extraHtml}</div>`;
  wireCard(root);
  if (isIoNotetype(nt)) hydrateIO(root);
  return { root, hasTypeAnswer: r.hasTypeAnswer };
}

function wireCard(root) {
  root.addEventListener('click', (e) => {
    const hint = e.target.closest('a.hint');
    if (hint) {
      e.preventDefault();
      const body = hint.nextElementSibling;
      if (body) { body.hidden = false; hint.remove(); }
      return;
    }
    const play = e.target.closest('.play-sound');
    if (play) {
      e.preventDefault();
      const a = new Audio(play.dataset.src);
      a.play().catch(() => {});
    }
  });
}

export function hydrateIO(root) {
  for (const io of root.querySelectorAll('.io')) {
    const img = io.querySelector('img');
    if (!img) continue;
    const draw = () => {
      let shapes = [];
      try { shapes = JSON.parse(io.dataset.shapes || '[]'); } catch { shapes = []; }
      const side = io.dataset.side;
      io.querySelectorAll('.io-mask, svg.io-poly').forEach((x) => x.remove());
      const nw = img.naturalWidth || 1, nh = img.naturalHeight || 1;
      const all = shapes.map((s) => Object.values(s.props)).flat().map(Number).filter((x) => !isNaN(x));
      const fractional = all.every((x) => x <= 1.0001);
      const fx = (v) => (fractional ? Number(v) : Number(v) / nw) * 100;
      const fy = (v) => (fractional ? Number(v) : Number(v) / nh) * 100;
      let svg = null;
      for (const s of shapes) {
        const oi = s.props.oi === '1';
        let cls;
        if (s.active) cls = side === 'q' ? 'active' : 'revealed';
        else if (oi) cls = 'inactive';
        else continue;
        if (s.kind === 'rect' || s.kind === 'ellipse') {
          const m = document.createElement('div');
          m.className = `io-mask ${cls} ${s.kind === 'ellipse' ? 'ellipse' : ''}`;
          m.style.left = fx(s.props.left || 0) + '%';
          m.style.top = fy(s.props.top || 0) + '%';
          m.style.width = fx(s.props.width || 0) + '%';
          m.style.height = fy(s.props.height || 0) + '%';
          io.appendChild(m);
        } else if (s.kind === 'polygon' && s.props.points) {
          if (!svg) {
            svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('class', 'io-poly');
            svg.setAttribute('viewBox', '0 0 100 100');
            svg.setAttribute('preserveAspectRatio', 'none');
            io.appendChild(svg);
          }
          const pts = s.props.points.trim().split(/\s+/).map((p) => { const [x, y] = p.split(',').map(Number); return `${fx(x)},${fy(y)}`; }).join(' ');
          const poly = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
          poly.setAttribute('points', pts);
          poly.setAttribute('class', cls);
          const fill = cls === 'active' ? '#F08A5D' : cls === 'inactive' ? '#D5D9E0' : 'none';
          poly.setAttribute('fill', fill);
          poly.setAttribute('stroke', cls === 'revealed' ? '#F08A5D' : '#7A2E0B');
          poly.setAttribute('stroke-width', '0.6');
          svg.appendChild(poly);
        }
      }
    };
    if (img.complete && img.naturalWidth) draw();
    else img.addEventListener('load', draw, { once: true });
  }
  const toggle = root.querySelector('.io-toggle');
  if (toggle) toggle.addEventListener('click', () => root.querySelectorAll('.io').forEach((io) => io.classList.toggle('masks-hidden')));
}

export function applyTheme() {
  const s = app.settings;
  let theme = addon('themes') ? s.theme : 'auto';
  if (theme === 'auto') theme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.setProperty('--card-scale', addon('themes') ? String(s.textScale || 1) : '1');
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = theme === 'dark' ? '#101318' : theme === 'sepia' ? '#F1E8D8' : '#F3F4F6';
}
