// Collection logic: decks, counts, study queue, editing, merge, desktop hand-off, stats.
// No DOM here, so it can be tested under Node.

import { schedule, previewIntervals, resetCard } from './sched.js';
import { dayIndex, newId, newGuid, dayToISO, isoToDay, stripHtml } from './util.js';
import { cardOrdsForNote } from './render.js';
import { defaultConf } from './apkg.js';

const LEARN_AHEAD_MS = 20 * 60000;

export class Collection {
  // data: {meta, notetypes, decks, dconfs, notes, cards, revlog, mediaNames}
  // persist(changes, deletes) -> Promise ; saveMeta(meta) -> Promise
  constructor(data, { persist, saveMeta, clock } = {}) {
    Object.assign(this, data);
    this.mediaNames = data.mediaNames || new Set();
    this.persist = persist || (async () => {});
    this.saveMetaFn = saveMeta || (async () => {});
    this.clock = clock || (() => Date.now());
    this.undoStack = [];
    if (!this.decks.has(1)) this.decks.set(1, { id: 1, name: 'Default', confId: 1 });
    if (!this.dconfs.has(1)) this.dconfs.set(1, defaultConf());
    this.unburyIfNewDay();
  }

  now() { return this.clock(); }
  today() { return dayIndex(this.now()); }
  get fsrs() { return !!this.meta.fsrs; }

  async saveMeta() { await this.saveMetaFn(this.meta); }

  // ---------- decks ----------
  deckByName(name) {
    for (const d of this.decks.values()) if (d.name === name) return d;
    return null;
  }
  // deck id plus all subdecks
  deckFamily(did) {
    const d = this.decks.get(did);
    if (!d) return new Set([did]);
    const ids = new Set([did]);
    const prefix = d.name + '::';
    for (const x of this.decks.values()) if (x.name.startsWith(prefix)) ids.add(x.id);
    return ids;
  }
  confFor(did) {
    const d = this.decks.get(did);
    return this.dconfs.get(d ? d.confId : 1) || this.dconfs.get(1) || defaultConf();
  }
  parentName(name) {
    const i = name.lastIndexOf('::');
    return i < 0 ? null : name.slice(0, i);
  }
  // visible deck list as a tree
  deckTree() {
    const decks = [...this.decks.values()].filter((d) => !(d.id === 1 && !this.deckHasCards(1) && this.decks.size > 1));
    decks.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base', numeric: true }));
    const nodes = new Map(decks.map((d) => [d.name, { deck: d, children: [] }]));
    const roots = [];
    for (const d of decks) {
      const parent = this.parentName(d.name);
      const node = nodes.get(d.name);
      if (parent && nodes.has(parent)) nodes.get(parent).children.push(node);
      else roots.push(node);
    }
    return roots;
  }
  deckHasCards(did) {
    for (const c of this.cards.values()) if (c.did === did) return true;
    return false;
  }
  async ensureDeck(name) {
    name = name.split('::').map((s) => s.trim()).filter(Boolean).join('::') || 'Default';
    let d = this.deckByName(name);
    if (d) return d;
    const parent = this.parentName(name);
    if (parent) await this.ensureDeck(parent);
    d = { id: newId(), name, confId: 1, mod: this.now() };
    this.decks.set(d.id, d);
    await this.persist({ decks: [d] });
    return d;
  }
  async renameDeck(did, newName) {
    const d = this.decks.get(did);
    if (!d) return;
    const old = d.name;
    newName = newName.split('::').map((s) => s.trim()).filter(Boolean).join('::');
    if (!newName || newName === old) return;
    if (this.deckByName(newName)) throw new Error('A deck with that name already exists.');
    const changed = [];
    for (const x of this.decks.values()) {
      if (x.name === old) x.name = newName;
      else if (x.name.startsWith(old + '::')) x.name = newName + x.name.slice(old.length);
      else continue;
      x.mod = this.now();
      changed.push(x);
    }
    const parent = this.parentName(newName);
    if (parent) await this.ensureDeck(parent);
    await this.persist({ decks: changed });
  }
  async deleteDeck(did) {
    const fam = this.deckFamily(did);
    const nids = new Set();
    for (const c of this.cards.values()) if (fam.has(c.did)) nids.add(c.nid);
    for (const nid of nids) await this.deleteNote(nid, true);
    const delDecks = [...fam].filter((id) => id !== 1);
    delDecks.forEach((id) => this.decks.delete(id));
    await this.persist({}, { decks: delDecks });
  }
  async setDeckConf(did, conf) {
    // each deck gets its own preset when edited here
    const d = this.decks.get(did);
    let c = this.dconfs.get(d.confId);
    const shared = [...this.decks.values()].filter((x) => x.confId === d.confId).length > 1;
    if (!c || shared) {
      c = { ...(c || defaultConf()), id: newId(), name: d.name };
      this.dconfs.set(c.id, c);
      d.confId = c.id;
      await this.persist({ decks: [d] });
    }
    Object.assign(c, conf);
    await this.persist({ dconfs: [c] });
  }

  // ---------- burying ----------
  unburyIfNewDay() {
    const t = this.today();
    const changed = [];
    for (const c of this.cards.values()) {
      if (c.buriedDay != null && c.buriedDay < t) {
        delete c.buriedDay;
        changed.push(c);
      }
    }
    if (changed.length) this.persist({ cards: changed });
  }
  isBuried(c, t = this.today()) { return c.buriedDay != null && c.buriedDay >= t; }

  // ---------- counting ----------
  doneToday() {
    // per deck: new introduced and reviews done today
    const start = this.dayStart();
    const res = new Map();
    for (let i = this.revlog.length - 1; i >= 0; i--) {
      const r = this.revlog[i];
      if (r.id < start) break;
      const c = this.cards.get(r.cid);
      if (!c) continue;
      const e = res.get(c.did) || { newDone: 0, revDone: 0, time: 0, count: 0 };
      if (r.type === 0 && r.lastIvl === 0) e.newDone++;
      if (r.type === 1) e.revDone++;
      e.time += r.time; e.count++;
      res.set(c.did, e);
    }
    return res;
  }
  dayStart() {
    // ms at which the current study day began
    const t = this.today();
    let ms = this.now();
    while (dayIndex(ms) === t) ms -= 3600000;
    while (dayIndex(ms) !== t) ms += 60000;
    return ms;
  }

  rawCounts(now = this.now()) {
    // per deck raw counts (not limited)
    const t = dayIndex(now);
    const endOfDay = this.dayStart() + 86400000;
    const raw = new Map();
    const get = (did) => { let e = raw.get(did); if (!e) { e = { n: 0, l: 0, r: 0 }; raw.set(did, e); } return e; };
    for (const c of this.cards.values()) {
      if (c.queue === -1 || this.isBuried(c, t)) continue;
      if (c.queue === 0) get(c.did).n++;
      else if (c.queue === 1) { if (c.dueAt < endOfDay) get(c.did).l++; }
      else if (c.queue === 3) { if (c.dueDay <= t) get(c.did).l++; }
      else if (c.queue === 2) { if (c.dueDay <= t) get(c.did).r++; }
    }
    return raw;
  }

  // limited counts for every deck: Map did -> {n,l,r}
  allCounts(now = this.now()) {
    const raw = this.rawCounts(now);
    const done = this.doneToday();
    const out = new Map();
    const walk = (node) => {
      const d = node.deck;
      const own = raw.get(d.id) || { n: 0, l: 0, r: 0 };
      let n = own.n, l = own.l, r = own.r, dn = (done.get(d.id) || {}).newDone || 0, dr = (done.get(d.id) || {}).revDone || 0;
      for (const ch of node.children) {
        const cc = walk(ch);
        n += cc.n; l += cc.l; r += cc.r; dn += cc.dn; dr += cc.dr;
      }
      const conf = this.confFor(d.id);
      const res = {
        n: Math.max(0, Math.min(n, conf.newPerDay - dn)),
        l,
        r: Math.max(0, Math.min(r, conf.revPerDay - dr)),
        dn, dr,
      };
      out.set(d.id, res);
      return res;
    };
    for (const root of this.deckTree()) walk(root);
    return out;
  }

  totals(now = this.now()) {
    const all = this.allCounts(now);
    let n = 0, l = 0, r = 0;
    for (const root of this.deckTree()) {
      const c = all.get(root.deck.id);
      n += c.n; l += c.l; r += c.r;
    }
    return { n, l, r };
  }

  // ---------- study session ----------
  startSession(did = null) {
    const now = this.now();
    const t = dayIndex(now);
    const deckSet = did == null ? null : this.deckFamily(did);
    const inSet = (c) => !deckSet || deckSet.has(c.did);
    let limits;
    if (did == null) limits = this.totals(now);
    else limits = this.allCounts(now).get(did) || { n: 0, r: 0 };
    const reviews = [], news = [];
    for (const c of this.cards.values()) {
      if (!inSet(c) || c.queue === -1 || this.isBuried(c, t)) continue;
      if (c.queue === 2 && c.dueDay <= t) reviews.push(c);
      else if (c.queue === 0) news.push(c);
    }
    // overdue first, then a stable shuffle so siblings don't sit together
    reviews.sort((a, b) => a.dueDay - b.dueDay || hash(a.id) - hash(b.id));
    news.sort((a, b) => a.pos - b.pos || a.id - b.id);
    const revQ = reviews.slice(0, limits.r).map((c) => c.id);
    const newQ = news.slice(0, limits.n).map((c) => c.id);
    // interleave new cards evenly among reviews
    const mixed = [];
    const ratio = newQ.length ? Math.max(1, Math.floor(revQ.length / newQ.length)) : Infinity;
    let ri = 0, ni = 0;
    while (ri < revQ.length || ni < newQ.length) {
      for (let k = 0; k < ratio && ri < revQ.length; k++) mixed.push(revQ[ri++]);
      if (ni < newQ.length) mixed.push(newQ[ni++]);
      if (ratio === Infinity) break;
    }
    while (ri < revQ.length) mixed.push(revQ[ri++]);
    const session = {
      did, deckSet, mixed, startedAt: now, answered: 0, correct: 0, timeMs: 0,
      total: mixed.length + this.learningIn(deckSet, now, true).length,
      dueCounts: this.reviewLoad(),
    };
    return session;
  }

  learningIn(deckSet, now, includeLater = false) {
    const t = dayIndex(now);
    const endOfDay = this.dayStart() + 86400000;
    const res = [];
    for (const c of this.cards.values()) {
      if (deckSet && !deckSet.has(c.did)) continue;
      if (this.isBuried(c, t)) continue;
      if (c.queue === 1 && (includeLater ? c.dueAt < endOfDay : c.dueAt <= now)) res.push(c);
      else if (c.queue === 3 && c.dueDay <= t) res.push(c);
    }
    res.sort((a, b) => (a.dueAt || 0) - (b.dueAt || 0));
    return res;
  }

  // Next card for the session, or {wait: ms} if only later learning cards remain, or null.
  nextCard(session) {
    const now = this.now();
    const due = this.learningIn(session.deckSet, now);
    if (due.length) return due[0];
    while (session.mixed.length) {
      const c = this.cards.get(session.mixed[0]);
      if (c && c.queue !== -1 && !this.isBuried(c) && (c.queue === 0 || (c.queue === 2 && c.dueDay <= this.today()))) return c;
      session.mixed.shift();
    }
    const later = this.learningIn(session.deckSet, now + LEARN_AHEAD_MS);
    if (later.length) return later[0];
    const rest = this.learningIn(session.deckSet, now, true);
    if (rest.length) return { wait: rest[0].dueAt - now };
    return null;
  }

  remaining(session) {
    const now = this.now();
    const lrn = this.learningIn(session.deckSet, now, true).length;
    let n = 0, r = 0;
    for (const id of session.mixed) {
      const c = this.cards.get(id);
      if (!c) continue;
      if (c.queue === 0) n++; else if (c.queue === 2) r++;
    }
    return { n, l: lrn, r };
  }

  reviewLoad() {
    const m = new Map();
    for (const c of this.cards.values()) if (c.queue === 2) m.set(c.dueDay, (m.get(c.dueDay) || 0) + 1);
    return m;
  }

  schedCtx(extra = {}) {
    const now = this.now();
    return { now, today: dayIndex(now), dayOf: dayIndex, fsrs: this.fsrs, random: Math.random, ...extra };
  }

  intervalsFor(card) {
    return previewIntervals(card, this.confFor(card.did), this.schedCtx());
  }

  async answer(session, card, ease, timeTaken, { loadBalance = false } = {}) {
    const conf = this.confFor(card.did);
    const ctx = this.schedCtx({ timeTaken, loadBalance, dueCounts: session ? session.dueCounts : null });
    const prev = { ...card };
    const { card: next, revlog } = schedule(card, ease, conf, ctx);
    next.pmod = ctx.now;
    // revlog ids must be unique
    const lastRev = this.revlog[this.revlog.length - 1];
    if (lastRev && revlog.id <= lastRev.id) revlog.id = lastRev.id + 1;
    this.cards.set(next.id, next);
    this.revlog.push(revlog);
    if (session) {
      if (session.mixed[0] === card.id) session.mixed.shift();
      else session.mixed = session.mixed.filter((id) => id !== card.id);
      session.answered++;
      if (ease > 1) session.correct++;
      session.timeMs += revlog.time;
      if (prev.queue === 2 && session.dueCounts) session.dueCounts.set(prev.dueDay, Math.max(0, (session.dueCounts.get(prev.dueDay) || 1) - 1));
      if (next.queue === 2 && session.dueCounts) session.dueCounts.set(next.dueDay, (session.dueCounts.get(next.dueDay) || 0) + 1);
    }
    this.undoStack.push({ kind: 'answer', prev, revlogId: revlog.id, sessionCard: session ? card.id : null, ease });
    if (this.undoStack.length > 30) this.undoStack.shift();
    await this.persist({ cards: [next], revlog: [revlog] });
    return next;
  }

  async undo(session) {
    const u = this.undoStack.pop();
    if (!u) return null;
    if (u.kind === 'answer') {
      this.cards.set(u.prev.id, u.prev);
      const i = this.revlog.findIndex((r) => r.id === u.revlogId);
      if (i >= 0) this.revlog.splice(i, 1);
      if (session) {
        session.answered = Math.max(0, session.answered - 1);
        if (u.ease > 1) session.correct = Math.max(0, session.correct - 1);
        if (u.prev.queue === 0 || u.prev.queue === 2) session.mixed.unshift(u.prev.id);
      }
      await this.persist({ cards: [u.prev] }, { revlog: [u.revlogId] });
      return u.prev;
    }
    if (u.kind === 'card') {
      this.cards.set(u.prev.id, u.prev);
      await this.persist({ cards: [u.prev] });
      if (session && (u.prev.queue === 0 || u.prev.queue === 2)) session.mixed.unshift(u.prev.id);
      return u.prev;
    }
    return null;
  }

  // ---------- card actions ----------
  async updateCard(card, patch, undoable = true) {
    const prev = { ...card };
    const next = { ...card, ...patch, mod: this.now(), pmod: this.now() };
    this.cards.set(next.id, next);
    if (undoable) this.undoStack.push({ kind: 'card', prev });
    await this.persist({ cards: [next] });
    return next;
  }
  suspend(card) { return this.updateCard(card, { queue: -1 }); }
  unsuspend(card) {
    const q = card.type === 0 ? 0 : card.type === 2 ? 2 : (card.dueAt ? 1 : 3);
    return this.updateCard(card, { queue: q });
  }
  bury(card) { return this.updateCard(card, { buriedDay: this.today() }); }
  setFlag(card, flag) { return this.updateCard(card, { flags: card.flags === flag ? 0 : flag }); }
  forget(card) {
    const pos = this.nextPos();
    return this.updateCard(card, resetCard(card, pos, this.now()));
  }
  async moveCards(cards, did) {
    const changed = cards.map((c) => ({ ...c, did, mod: this.now(), pmod: this.now() }));
    changed.forEach((c) => this.cards.set(c.id, c));
    await this.persist({ cards: changed });
  }
  async setDueDate(card, daysFromToday) {
    return this.updateCard(card, { type: card.type === 0 ? 2 : card.type, queue: 2, dueDay: this.today() + daysFromToday, ivl: Math.max(card.ivl || 0, Math.max(1, daysFromToday)), factor: card.factor || 2500 });
  }

  nextPos() {
    let max = this.meta.nextPos || 0;
    if (!max) for (const c of this.cards.values()) if (c.type === 0 && c.pos > max) max = c.pos;
    this.meta.nextPos = max + 1;
    this.saveMeta();
    return this.meta.nextPos;
  }

  // ---------- notes ----------
  async addNote(ntId, did, flds, tags) {
    const nt = this.notetypes.get(ntId);
    const now = this.now();
    const note = { id: newId(), guid: newGuid(), mid: ntId, mod: now, pmod: now, tags: [...tags], flds: [...flds], src: 'phone' };
    while (note.flds.length < nt.flds.length) note.flds.push('');
    const ords = cardOrdsForNote(note, nt);
    const cards = ords.map((ord) => ({
      id: newId(), nid: note.id, did, ord, mod: now, pmod: now, type: 0, queue: 0, pos: this.nextPos(),
      dueAt: 0, dueDay: 0, ivl: 0, factor: 0, reps: 0, lapses: 0, left: 0, flags: 0, s: null, d: null, lastReview: 0,
    }));
    this.notes.set(note.id, note);
    cards.forEach((c) => this.cards.set(c.id, c));
    await this.persist({ notes: [note], cards });
    return { note, cards };
  }

  async updateNote(note, flds, tags) {
    const nt = this.notetypes.get(note.mid);
    const next = { ...note, flds: [...flds], tags: [...tags], mod: this.now(), pmod: this.now() };
    this.notes.set(next.id, next);
    // add cards for newly non-empty templates / new cloze numbers
    const have = new Set([...this.cards.values()].filter((c) => c.nid === note.id).map((c) => c.ord));
    const sample = [...this.cards.values()].find((c) => c.nid === note.id);
    const added = [];
    for (const ord of cardOrdsForNote(next, nt)) {
      if (have.has(ord)) continue;
      const c = { id: newId(), nid: note.id, did: sample ? sample.did : 1, ord, mod: this.now(), pmod: this.now(), type: 0, queue: 0, pos: this.nextPos(), dueAt: 0, dueDay: 0, ivl: 0, factor: 0, reps: 0, lapses: 0, left: 0, flags: 0, s: null, d: null, lastReview: 0 };
      this.cards.set(c.id, c);
      added.push(c);
    }
    await this.persist({ notes: [next], cards: added });
    return next;
  }

  async deleteNote(nid, skipDeckCleanup = false) {
    const cids = [...this.cards.values()].filter((c) => c.nid === nid).map((c) => c.id);
    cids.forEach((id) => this.cards.delete(id));
    this.notes.delete(nid);
    if (!this.meta.deletedNotes) this.meta.deletedNotes = [];
    this.meta.deletedNotes.push(nid);
    await this.persist({}, { notes: [nid], cards: cids });
    if (!skipDeckCleanup) await this.saveMeta();
  }

  cardsOfNote(nid) { return [...this.cards.values()].filter((c) => c.nid === nid).sort((a, b) => a.ord - b.ord); }

  // ---------- search (Anki-like subset) ----------
  search(query) {
    const terms = tokenize(query || '');
    const tests = terms.map((t) => this.termTest(t));
    const res = [];
    for (const c of this.cards.values()) {
      const n = this.notes.get(c.nid);
      if (!n) continue;
      if (tests.every((fn) => fn(c, n))) res.push(c);
    }
    return res;
  }
  termTest(term) {
    let neg = false;
    if (term.startsWith('-') && term.length > 1) { neg = true; term = term.slice(1); }
    const t = this.today();
    const lower = term.toLowerCase();
    let fn;
    const colon = lower.indexOf(':');
    const key = colon > 0 ? lower.slice(0, colon) : '';
    const val = colon > 0 ? term.slice(colon + 1) : '';
    const glob = (pattern) => new RegExp('^' + pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/_/g, '.') + '$', 'i');
    if (key === 'deck') {
      const re = glob(val);
      fn = (c) => { const d = this.decks.get(c.did); return !!d && (re.test(d.name) || d.name.toLowerCase().startsWith(val.toLowerCase().replace(/\*$/, '') + '::') && !val.includes('*')); };
    } else if (key === 'tag') {
      const re = glob(val);
      fn = (c, n) => n.tags.some((tg) => re.test(tg) || tg.toLowerCase().startsWith(val.toLowerCase() + '::'));
    } else if (key === 'is') {
      const v = val.toLowerCase();
      fn = (c) => ({
        due: (c.queue === 2 || c.queue === 3) && c.dueDay <= t || c.queue === 1,
        new: c.type === 0, learn: c.type === 1 || c.type === 3, review: c.type === 2 || c.type === 3,
        suspended: c.queue === -1, buried: this.isBuried(c, t),
      })[v] || false;
    } else if (key === 'flag') {
      const f = Number(val);
      fn = (c) => (c.flags || 0) === f;
    } else if (key === 'note') {
      const re = glob(val);
      fn = (c, n) => { const nt = this.notetypes.get(n.mid); return !!nt && re.test(nt.name); };
    } else if (key === 'prop' && /^ivl/.test(val)) {
      const m = val.match(/^ivl(<=|>=|<|>|=)(\d+)/);
      fn = m ? (c) => ({ '<': c.ivl < +m[2], '>': c.ivl > +m[2], '<=': c.ivl <= +m[2], '>=': c.ivl >= +m[2], '=': c.ivl === +m[2] })[m[1]] : () => true;
    } else if (key === 'rated') {
      const days = Number(val) || 1;
      const since = this.dayStart() - (days - 1) * 86400000;
      const rated = new Set(this.revlog.filter((r) => r.id >= since).map((r) => r.cid));
      fn = (c) => rated.has(c.id);
    } else if (key === 'added') {
      const days = Number(val) || 1;
      const since = this.dayStart() - (days - 1) * 86400000;
      fn = (c) => c.nid >= since || c.id >= since;
    } else if (key === 'nid') {
      const ids = new Set(val.split(',').map(Number));
      fn = (c) => ids.has(c.nid);
    } else if (key && this.notetypeFieldExists(key)) {
      const re = glob(val);
      fn = (c, n) => { const nt = this.notetypes.get(n.mid); const i = nt.flds.findIndex((f) => f.toLowerCase() === key); return i >= 0 && re.test(stripHtml(n.flds[i])); };
    } else {
      const needle = term.replace(/^"|"$/g, '').toLowerCase();
      fn = (c, n) => n.flds.some((f) => stripHtml(f).toLowerCase().includes(needle)) || n.tags.some((tg) => tg.toLowerCase().includes(needle));
    }
    return neg ? (c, n) => !fn(c, n) : fn;
  }
  notetypeFieldExists(name) {
    for (const nt of this.notetypes.values()) if (nt.flds.some((f) => f.toLowerCase() === name)) return true;
    return false;
  }

  // ---------- add-on helpers ----------
  // Skip-a-day: spread everything due today over the next three days
  async skipDay(did = null) {
    const t = this.today();
    const fam = did == null ? null : this.deckFamily(did);
    const due = [...this.cards.values()].filter((c) => (!fam || fam.has(c.did)) && (c.queue === 2 || c.queue === 3) && c.dueDay <= t);
    due.sort((a, b) => a.dueDay - b.dueDay);
    const changed = due.map((c, i) => ({ ...c, dueDay: t + 1 + (i % 3), mod: this.now(), pmod: this.now() }));
    changed.forEach((c) => this.cards.set(c.id, c));
    await this.persist({ cards: changed });
    return changed.length;
  }

  examLoad(examDay) {
    const t = this.today();
    let reviews = 0, news = 0;
    for (const c of this.cards.values()) {
      if (c.queue === -1) continue;
      if (c.queue === 0) news++;
      else if ((c.queue === 2 || c.queue === 3) && c.dueDay <= examDay) reviews++;
      else if (c.queue === 1) reviews++;
    }
    return { days: examDay - t, reviews, news };
  }

  // ---------- stats ----------
  stats() {
    const t = this.today();
    const byDay = new Map();
    let todayCount = 0, todayTime = 0;
    for (const r of this.revlog) {
      const d = dayIndex(r.id);
      byDay.set(d, (byDay.get(d) || 0) + 1);
      if (d === t) { todayCount++; todayTime += r.time; }
    }
    let streak = 0;
    let d = byDay.has(t) ? t : t - 1;
    while (byDay.has(d)) { streak++; d--; }
    const since = this.dayStart() - 29 * 86400000;
    let rev = 0, pass = 0;
    const tagStats = new Map();
    for (const r of this.revlog) {
      if (r.id < since || r.type !== 1) continue;
      rev++; if (r.ease > 1) pass++;
      const c = this.cards.get(r.cid);
      const n = c && this.notes.get(c.nid);
      if (!n) continue;
      for (const tg of n.tags.length ? n.tags : ['(untagged)']) {
        const e = tagStats.get(tg) || { n: 0, pass: 0 };
        e.n++; if (r.ease > 1) e.pass++;
        tagStats.set(tg, e);
      }
    }
    const forecast = [];
    for (let i = 0; i < 30; i++) forecast.push(0);
    let fNew = 0, fLearn = 0, young = 0, mature = 0, susp = 0;
    for (const c of this.cards.values()) {
      if (c.queue === -1) { susp++; continue; }
      if (c.type === 0) fNew++;
      else if (c.type === 1 || c.type === 3) fLearn++;
      else if (c.ivl >= 21) mature++; else young++;
      if (c.queue === 2) {
        const i = Math.max(0, c.dueDay - t);
        if (i < 30) forecast[i]++;
      }
    }
    const weak = [...tagStats.entries()].filter(([, e]) => e.n >= 3)
      .map(([tag, e]) => ({ tag, n: e.n, pct: e.pass / e.n }))
      .sort((a, b) => a.pct - b.pct || b.n - a.n);
    return { byDay, streak, todayCount, todayTime, retention: rev ? pass / rev : null, retentionN: rev, forecast, weak, counts: { new: fNew, learn: fLearn, young, mature, suspended: susp } };
  }

  // ---------- merging an imported package ----------
  // Latest change wins for each note and card. Returns a summary.
  async merge(pkg, { onProgress } = {}) {
    const sum = { notesAdded: 0, notesUpdated: 0, cardsAdded: 0, cardsUpdated: 0, revlogAdded: 0, media: 0, conflicts: 0, decks: 0 };
    const changes = { notetypes: [], decks: [], dconfs: [], notes: [], cards: [], revlog: [] };
    const deletes = { notes: [], cards: [] };
    const firstImport = this.cards.size === 0;
    if (firstImport && !this.meta.lastSent) this.meta.lastSent = this.now();
    if (!this.meta.crt || firstImport) this.meta.crt = pkg.crt;
    if (firstImport) this.meta.fsrs = !!pkg.fsrs;
    const unsentSince = this.meta.lastSent || 0;

    for (const nt of pkg.notetypes) {
      const cur = this.notetypes.get(nt.id);
      if (!cur || (nt.mod || 0) >= (cur.mod || 0)) { this.notetypes.set(nt.id, nt); changes.notetypes.push(nt); }
    }
    for (const c of pkg.dconfs) {
      if (!this.dconfs.has(c.id) || c.id !== 1 || firstImport) { this.dconfs.set(c.id, c); changes.dconfs.push(c); }
    }
    // decks: match by id, else by name
    const deckMap = new Map();
    for (const d of pkg.decks) {
      if (this.decks.has(d.id)) { const cur = this.decks.get(d.id); cur.name = d.name; cur.confId = this.dconfs.has(d.confId) ? d.confId : cur.confId; changes.decks.push(cur); deckMap.set(d.id, d.id); continue; }
      const byName = this.deckByName(d.name);
      if (byName) { deckMap.set(d.id, byName.id); continue; }
      const nd = { ...d, confId: this.dconfs.has(d.confId) ? d.confId : 1 };
      this.decks.set(nd.id, nd); changes.decks.push(nd); deckMap.set(d.id, d.id); sum.decks++;
    }
    // notes: by id, else by guid (a note made on the phone that came back from desktop)
    const byGuid = new Map();
    for (const n of this.notes.values()) byGuid.set(n.guid, n);
    const noteIdMap = new Map();
    for (const n of pkg.notes) {
      let cur = this.notes.get(n.id);
      if (!cur && byGuid.has(n.guid)) {
        // re-key the phone note and its cards to the desktop ids
        const old = byGuid.get(n.guid);
        this.notes.delete(old.id); deletes.notes.push(old.id);
        noteIdMap.set(old.id, n.id);
        for (const c of [...this.cards.values()]) {
          if (c.nid !== old.id) continue;
          const incoming = pkg.cards.find((x) => x.nid === n.id && x.ord === c.ord);
          this.cards.delete(c.id); deletes.cards.push(c.id);
          if (!incoming) { const moved = { ...c, nid: n.id }; this.cards.set(moved.id, moved); changes.cards.push(moved); }
          else if (c.mod > incoming.mod) {
            const moved = { ...c, id: incoming.id, nid: n.id };
            this.cards.set(moved.id, moved); changes.cards.push(moved);
          }
        }
        cur = { ...old, id: n.id };
      }
      if (!cur) { const nn = { ...n, src: 'pkg' }; this.notes.set(n.id, nn); changes.notes.push(nn); sum.notesAdded++; }
      else if ((n.mod || 0) > (cur.mod || 0)) { const nn = { ...n, src: cur.src || 'pkg', sentAt: cur.sentAt }; this.notes.set(n.id, nn); changes.notes.push(nn); sum.notesUpdated++; }
      else if (cur.id === n.id && !this.notes.has(n.id)) { this.notes.set(cur.id, cur); changes.notes.push(cur); }
    }
    let i = 0;
    for (const c0 of pkg.cards) {
      const c = { ...c0, did: deckMap.get(c0.did) || (this.decks.has(c0.did) ? c0.did : 1) };
      const cur = this.cards.get(c.id);
      if (!cur) { this.cards.set(c.id, c); changes.cards.push(c); sum.cardsAdded++; }
      else if ((c.mod || 0) > (cur.mod || 0)) {
        if (cur.mod > unsentSince && unsentSince) sum.conflicts++;
        const merged = { ...cur, ...c, lastReview: Math.max(cur.lastReview || 0, c.lastReview || 0) };
        delete merged.pmod;
        delete merged.buriedDay;
        this.cards.set(c.id, merged); changes.cards.push(merged); sum.cardsUpdated++;
      }
      if (onProgress && ++i % 2000 === 0) onProgress(i / pkg.cards.length);
    }
    const haveRev = new Set(this.revlog.map((r) => r.id));
    for (const r of pkg.revlog) {
      if (haveRev.has(r.id)) continue;
      this.revlog.push(r); changes.revlog.push(r); sum.revlogAdded++;
    }
    this.revlog.sort((a, b) => a.id - b.id);
    // keep lastReview in sync with history
    const last = new Map();
    for (const r of this.revlog) last.set(r.cid, r.id);
    for (const c of changes.cards) if (last.has(c.id) && (c.lastReview || 0) < last.get(c.id)) c.lastReview = last.get(c.id);
    await this.persist(changes, deletes);
    await this.saveMeta();
    return sum;
  }

  // ---------- desktop hand-off ----------
  // Everything changed on the phone since the last hand-off.
  buildProgress() {
    const since = this.meta.lastSent || 0;
    const now = this.now();
    const t = this.today();
    const cards = [];
    for (const c of this.cards.values()) {
      if ((c.pmod || 0) <= since) continue;
      const n = this.notes.get(c.nid);
      const d = this.decks.get(c.did);
      cards.push({
        id: c.id, nid: c.nid, noteGuid: n ? n.guid : null, ord: c.ord, deck: d ? d.name : 'Default',
        type: c.type, queue: c.buriedDay != null && c.buriedDay >= t ? c.queue : c.queue,
        dueDate: c.queue === 2 || c.queue === 3 || (c.queue === -1 && c.type === 2) ? dayToISO(c.dueDay) : null,
        dueAt: c.queue === 1 || (c.queue === -1 && c.dueAt) ? c.dueAt : null,
        pos: c.pos || 0, ivl: c.ivl, factor: c.factor, reps: c.reps, lapses: c.lapses, left: c.left,
        flags: c.flags || 0, s: c.s, d: c.d, mod: c.mod,
      });
    }
    const revlog = this.revlog.filter((r) => r.id > since);
    const notes = [];
    for (const n of this.notes.values()) {
      if ((n.pmod || 0) <= since) continue;
      const nt = this.notetypes.get(n.mid);
      const anyCard = this.cardsOfNote(n.id)[0];
      notes.push({
        id: n.id, guid: n.guid, notetype: nt ? nt.name : '', notetypeId: n.mid,
        notetypeDef: nt && n.src === 'phone' && nt.src === 'phone' ? { name: nt.name, kind: nt.kind, flds: nt.flds, tmpls: nt.tmpls, css: nt.css } : null,
        deck: anyCard ? (this.decks.get(anyCard.did) || {}).name || 'Default' : 'Default',
        fields: n.flds, tags: n.tags, mod: n.mod, isNew: n.src === 'phone' && !n.sentAt,
      });
    }
    const deleted = (this.meta.deletedNotes || []).filter(Boolean);
    return {
      format: 'ankiphone-progress', version: 1, created: now, since,
      todayISO: dayToISO(t), rolloverHours: 4,
      cards, revlog, notes, deletedNotes: deleted, media: [],
    };
  }
  phoneMade(c) {
    const n = this.notes.get(c.nid);
    return !!n && n.src === 'phone' && !n.sentAt;
  }
  async markSent(progress) {
    this.meta.lastSent = progress.created;
    this.meta.deletedNotes = [];
    const changed = [];
    for (const pn of progress.notes) {
      const n = this.notes.get(pn.id);
      if (n && pn.isNew) { n.sentAt = progress.created; changed.push(n); }
    }
    await this.persist({ notes: changed });
    await this.saveMeta();
  }
  unsentCount() {
    const since = this.meta.lastSent || 0;
    let n = 0;
    for (let i = this.revlog.length - 1; i >= 0 && this.revlog[i].id > since; i--) n++;
    return n;
  }
  mediaReferencedBy(notes) {
    const names = new Set();
    const re = /src=["']?([^"'>\s]+)|\[sound:([^\]]+)\]/gi;
    for (const n of notes) for (const f of n.fields || n.flds) {
      let m; re.lastIndex = 0;
      while ((m = re.exec(f))) {
        const name = (m[1] || m[2] || '').trim();
        if (name && !/^(https?:|data:|blob:)/i.test(name)) { try { names.add(decodeURIComponent(name)); } catch { names.add(name); } }
      }
    }
    return names;
  }
}

function hash(x) {
  // small deterministic shuffle key
  let h = Number(x % 2147483647) ^ 0x5bd1e995;
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h = Math.imul(h ^ (h >>> 12), 0x297a2d39);
  return (h ^ (h >>> 15)) >>> 0;
}

export function tokenize(q) {
  const out = [];
  const re = /-?"[^"]*"|-?[^\s"]+(?::"[^"]*")?/g;
  let m;
  while ((m = re.exec(q))) out.push(m[0].replace(/:"([^"]*)"$/, ':$1').replace(/^(-?)"([^"]*)"$/, '$1$2'));
  return out;
}

export { isoToDay };
