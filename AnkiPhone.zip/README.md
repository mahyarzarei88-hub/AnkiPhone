# AnkiPhone

A flashcard app for iPhone that opens Anki `.apkg` files, schedules like Anki (SM-2 or FSRS), and has a built-in Pomodoro timer and the add-ons you picked. It installs to your home screen and works offline.

## 1. Put it online (one time, about 5 minutes, free)

The app is a set of web files. It needs a home on the web so your iPhone can install it. GitHub Pages is free:

1. Make a free account at github.com (on your computer).
2. Click **+ → New repository**. Name it `ankiphone`, set it to **Public**, and click **Create repository**.
3. Click **uploading an existing file**. Drag in **everything inside this folder** (index.html, the `js`, `css`, `vendor` and `icons` folders, sw.js, manifest.webmanifest). Click **Commit changes**.
4. Go to **Settings → Pages**. Under "Branch", pick **main** and **/ (root)**, then **Save**.
5. After a minute the page shows your address, like `https://yourname.github.io/ankiphone/`.

Your cards are never uploaded there. They stay in the app's storage on your phone.

## 2. Install on your iPhone

1. Open your address in **Safari**.
2. Tap **Share → Add to Home Screen → Add**.
3. Open **AnkiPhone** from the home screen. From now on it works without internet.

## 3. Bring in your decks

- Tap **Import** and pick an `.apkg` from Files, iCloud Drive or Downloads. Both older and current Anki export formats work, including images, sounds, cloze and image occlusion cards.

## 4. Connect desktop Anki (optional)

1. In desktop Anki: **Tools → Add-ons → Install from file…**, pick `ankiphone_companion.ankiaddon`, then restart Anki.
2. It creates an **AnkiPhone** folder in iCloud Drive (on Windows, install iCloud for Windows first; you can choose another folder under Tools → AnkiPhone).
3. **Desktop → phone:** close Anki on your computer. It saves `AnkiPhone-desktop.apkg` in that folder. On the phone tap **Get from desktop** and pick it.
4. **Phone → desktop:** tap **Send to desktop → Save to Files → AnkiPhone folder**. The next time desktop Anki opens, it applies your phone reviews and then syncs to AnkiWeb as usual.

If a card changed in both places, the newer change wins. Notes deleted on the phone are only tagged `AnkiPhone::deleted-on-phone` on desktop, so nothing is lost by accident.

## Good to know

- **Back up** from Settings now and then and save it to iCloud Drive. If you delete the home-screen app, iOS deletes its storage too.
- Card templates that rely on JavaScript (some shared decks' fancy templates) show their content but scripts don't run.
- Haptics need iOS 18 or newer.
