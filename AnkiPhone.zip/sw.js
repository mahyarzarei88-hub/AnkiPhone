// Offline support: cache the app shell, serve it cache-first, refresh in the background.
const CACHE = 'ankiphone-v1.0.0';
const SHELL = [
  './', 'index.html', 'manifest.webmanifest', 'css/app.css',
  'js/app.js', 'js/apkg.js', 'js/col.js', 'js/db.js', 'js/editor.js', 'js/handoff.js', 'js/pomodoro.js',
  'js/proto.js', 'js/render.js', 'js/review.js', 'js/sched.js', 'js/state.js', 'js/ui.js', 'js/util.js',
  'vendor/sql-wasm.js', 'vendor/sql-wasm.wasm', 'vendor/jszip.min.js', 'vendor/fzstd.js',
  'icons/icon-180.png', 'icons/icon-192.png', 'icons/icon-512.png',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => {
      const fresh = fetch(req).then((res) => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => hit);
      return hit || fresh;
    })
  );
});
